# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/).

## [Unreleased]

### Summary
Clearer screenshot tools, more reliable clipboard history and Command Bar answers, and better monitoring and headphone detection.

### Changed
- Command Bar accepts British unit spellings and spaced fluid-ounce names.
- The window switcher's icon row, previews and hints use Liquid Glass when available and enabled.

### Fixed
- The cleaner leaves system log files out of app leftovers.
- Command Bar handles extreme date offsets without crashing and keeps tiny non-temperature unit conversions from reading as zero.
- Clipboard history ignores marked temporary content and restores the previous copy without another notice, while preserving ordinary copies and sensitive-text filtering.
- Pinned GPU, temperature and fan menu bar readings follow the selected System monitor update interval.
- Dynamic Island's full-screen hiding recognizes games whose windows cover the desktop without entering a separate full-screen space.
- Volume mixer recognizes headphones from their Core Audio device information, including models whose names do not say headphones.
- Screenshot area selection keeps its crosshair over other apps, and card shadows follow the captured window's own rounded corners.

### Contributors
Thanks to @0miicr0n, @DigitalWestern, @hash00, @Jacob-9909, @JB-OD, @JeanBaeez, @Likheet, @muratozturk5, @raymondchins and @stors789.

## [3.4.2] - 2026-10-21

### Summary
A cleaner Dynamic Island, clearer updates, more flexible screenshots and clipboard history, and smoother everyday controls. This release also improves AI Agents, recordings and window switching, with many fixes.

### Added
- After an update, What's New shows changes for the features you use, followed by the support page. Settings → About → Updates.
- Dynamic Island can show the keyboard input source when it changes. Settings → Dynamic Island → Activity → Indicators.
- Dynamic Island can open and close with a keyboard shortcut. Settings → Dynamic Island → Behavior → Opening.
- Dynamic Island set to Hidden until hover can appear for activities, indicators and notifications, then hide again. Settings → Dynamic Island → Behavior → Opening → Show activity and indicators.
- Dynamic Island can find covers for YouTube and YouTube Music in Firefox, Zen and other Firefox-based browsers. Cover lookups stop when disabled and ignore outdated replies. Settings → Dynamic Island → Content → Music → Find covers for Firefox and Zen.
- AI Agents can show limits for each separate Codex account. Settings → Dynamic Island → Content → AI Agents.
- The screenshot editor adds Spotlight, canvas expansion and editable images pasted with Command-V; previews can copy text when Copy text from screen is installed.
- Clipboard history can remove old items after a set number of days while keeping pinned items. Settings → Clipboard history → Keep items for.
- The window switcher can limit how many items fit in a row. Settings → Window switcher → Options → Maximum columns.
- Window layout can snap windows moved with the modifier drag when Snap windows at screen edges is on. Settings → Window layout → Window dragging.
- The scratchpad shows Markdown task lists as checkboxes, and Shift-Return continues a list.
- App Updates can exclude any app, including one with no update showing. Settings → App updates → Update exceptions.

### Changed
- Dynamic Island has a simpler layout, a compact music player and page controls beside the camera. Pin, Settings and Close move to the context menu.
- Dynamic Island's clipboard page opens on the last copy, keeps search behind a button and can show compact entries. Settings → Dynamic Island → Content → Clipboard.
- Dynamic Island closes when a file or link is dragged out of its Shelf, making room for the drop destination; a pinned island stays open.
- AI Agents reads Claude's limits through Claude Code when installed, including use on other Macs.
- Command Bar opens and searches faster, with smoother opening inside Dynamic Island.
- Clipboard history's sensitive-text filter is off by default, including after upgrading, and no longer rejects ordinary commands, output or links just for words such as "token" or "password". Confidential copies and ignored apps stay out. Settings → Clipboard history.
- Volume mixer sliders follow perceived loudness while preserving saved levels, and the headphone-disconnect setting can now silence the speakers.
- Settings → Features uses Install and Uninstall buttons instead of switches.
- Release notes shown before updating can be turned off. Settings → About → Updates.

### Fixed
- Quit Protection lets macOS Command-Tab handle Q for the selected app, and sends confirmed quit shortcuts through to remote desktop and virtual machine sessions.
- Quit on close keeps apps running when windows are minimized or floating controls, slideshows or Open dialogs remain.
- The window switcher, Dock Preview and Watch pause captures when macOS takes too long to check screen access, reducing the risk of a logout under heavy load. Thumbnails also pause while the display sleeps or the screen is locked.
- The window switcher, Dock Preview and Command Bar omit closed windows and helper entries, and selecting a window brings only that window forward.
- The window switcher includes apps such as Xcode's Device Hub and can show fullscreen windows from other desktops when Show fullscreen windows is on.
- The window switcher gives Command-Tab back to macOS while secure input is active, so the shortcut keeps working.
- Dock clicks and Dock Preview target the correct instance of an app with multiple processes, and hovering the Dock no longer waits on a frozen neighboring app.
- Window switcher, Dock Preview, mouse features and Window layout recognize programs added by path, including Java runtimes used by games.
- Smooth scrolling stays in its original window or scroll area, and Focus follows mouse keeps address bar suggestions and other pop-ups open.
- Mouse navigation handles rapid Back and Forward clicks and leaves unsupported clicks to the app.
- Mouse features leave Launchpad alone when Launchpad or the Dock is listed under Apps to leave alone.
- Cleaning Mode keeps middle click and debounce suspended, and input taps stopped for permission cleanup or shutdown stay stopped.
- Dynamic Island fits the physical notch when the menu bar is taller, with Hide gap below notch off by default, and opens on hover on displays without a notch when hidden in full screen.
- Dynamic Island keeps playing music ahead of the idle companion and selectable beside AI activity, finds lyrics across more catalog variations and shows the playing app's icon when a cover is missing.
- Dynamic Island's scratchpad shortcut opens and closes it reliably, shortcuts to other pages expand active capture controls, and timed screenshot previews close as expected.
- Volume keys handle coarse steps and show the correct output icon, and Volume mixer controls mute at 0% without crashing on invalid microphone readings.
- Volume mixer sliders keep their latest value, AirPlay pauses and resumes with playback, and Studio Pro 8 stays outside audio routing.
- Paste as plain text and snippets cancel after a newer copy, and snippets remove their whole trigger in address bars with autocomplete.
- Clipboard history, Dynamic Island, Command Bar, snippets and Quick Launcher accept numeric keypad shortcuts.
- Command Bar preserves hidden apps and text spacing, reads more browser selections, finds Xcode tools and copies script results reached through partial names or shortcuts.
- Command Bar handles leap days, invalid dates and large calculator results without losing meaningful digits.
- Screenshots keep selection drags and the dimmed overlay working across capture modes, and the editor keeps every tool reachable in short windows.
- Single-window recordings capture only that app's sound, including when a browser starts playback during recording.
- Recordings fall back to H.264 when HEVC rejects the size, start and export more smoothly, and save or copy long recordings as GIFs without excessive memory use.
- AI Agents follows OpenCode 2, keeps edited Codex conversations together with their reviews and subagents, and improves Claude renewal estimates.
- Display brightness ignores stale monitor replies and keeps controls for mirrored displays; Extra Brightness preserves windows in Mission Control's desktop thumbnails.
- System monitor reads CPU temperature from the hottest M4 Pro cores, updates battery readings promptly and can show accessory batteries without their menu bar item.
- App Updates avoids false updates from incompatible version numbering, compares beta and rc numbers correctly, and opens destinations without freezing.
- The uninstaller handles iPhone and iPad apps and rejects apps nested inside another app; Disk Image Installer ignores Homebrew's cached installers.
- The Settings window no longer freezes or jumps while scrolling Monitor or installing features, and Wallpaper's file pickers open in front on the first click.

### Contributors
Thanks to @2-Chengs, @69grcv8vfm-sys, @AB-boi, @Acronyxxx, @Adridot, @ahmedabdullah-o, @akune, @Alpaka05, @andrewgribben, @baacon, @bebricoOOOOOOf, @becastellani, @beckhauser, @benjcrich, @bharathvbcr, @brtkdev, @capozz03, @carltonking, @cdbrandt729-code, @chadfidev, @Chubi01, @claude, @COMEBACKISREAL, @cprecioso, @CSkjolden, @DanyRodier, @DigitalWestern, @Dusk-afk, @eioz, @emreertunc, @Ep0chalypse, @EtienneLescot, @EugeneCarldotme, @fandiyi047, @galpressman, @georgeat8, @gustavoramalho, @Hackmodford, @Hongsheng-Y, @iancenry, @iltonandrew, @jainnam-1993, @JeanBaeez, @JoeC-Dev, @jonathanrparis, @joshrad-dev, @juanra, @kit101, @LechTheMitch, @Likheet, @LoBot9, @louisboii747, @luantedesco, @ManuLorenzzo, @marianhoenscheid, @Memphizzz, @mendozal, @mikeknight85, @mmoradi97, @Mohamed-Elshesheny, @mohammadhprp, @morhaf-ko, @mr-tco, @mschoeffmann, @N-o-c-t-i-s, @Narangor, @nateships, @ncesar, @Noelia09, @npcmail010, @oecer, @oskarsss, @pedro-fontinele, @PerretWilliam, @PHSM22, @PratikPawar1401, @rgndxzzk, @rhukster, @RKeyProg, @RoccoRakete, @rohanod, @root-daemon, @runxel, @samanyudas, @Samuel61904, @schematicdnb, @skiner68, @StudioKeys, @suhrudsh, @thitiwats, @Timothy-ZhangYF, @tyfoan, @ucrbuffalo, @unfilet, @voljumet, @webipsum, @webuildfabian, @Werkezeugs, @xftvl, @Yahddyyp, @yuzu-octopus, @ywu73, @zepeng-jin, @zhanghk2001 and @Zvzdov.
Feedback: Brain.

## [3.4.2-beta.2] - 2026-10-20

### Summary
Clipboard history that can expire old items and a hidden Dynamic Island that still shows activity, plus fixes for AirPlay, displays, battery updates and more.

### Highlights
- **A hidden island that still shows activity.** Dynamic Island set to Hidden until hover can come into view for activities, indicators and notifications, then hide again. Settings → Dynamic Island → Behavior → Opening → Show activity and indicators.
- **Clipboard history that expires.** Items can be removed after a set number of days, while pinned items stay. Settings → Clipboard → Keep items for.
- **⌘Tab under secure input.** When the window switcher replaces macOS ⌘Tab, the shortcut no longer goes dead while another app has secure input on, as password fields do.

### Added
- Clipboard history can remove items after a set number of days, while pinned items stay. Settings → Clipboard → Keep items for.
- Dynamic Island set to Hidden until hover can still come into view for activities, indicators and notifications, then hide again. Settings → Dynamic Island → Behavior → Opening → Show activity and indicators.

### Changed
- Dynamic Island closes when a file or link is dragged out of its Shelf, so it no longer covers browser tabs or other places to drop it. A pinned island stays open.

### Fixed
- Dynamic Island's Now Playing page shows the Explore button again when Explore is not a floating button, and can grow a little to fit it while a song plays. The System page shows it too where it had no top row, such as on displays without a notch.
- Dock Preview avoids waiting on a frozen neighboring app when hovering the uncovered Dock.
- Mirrored displays stay listed with their own display brightness controls and power button, including the built-in screen.
- Battery readings update promptly when connecting or disconnecting power, including when background monitoring uses a longer interval.
- Screen capture's dimmed overlay keeps covering the display when switching between screenshot, recording and color picker.
- Volume mixer controls show their own tooltips, with the reorder hint kept on each app's icon and name.
- Command Bar keeps meaningful digits in large calculator results and reused expressions while still hiding small rounding noise.
- App names in the Settings window, clipboard history and Dynamic Island's player no longer end in ".app" when the Finder shows all filename extensions.
- The volume mixer's AirPlay stream pauses once routed apps go quiet, so iPhones and HomePods stop showing the Mac as playing, and sound comes back after pausing from the phone.
- Command Bar copies a script's output and closes when the script row was reached by part of its name or opened from its shortcut.
- Settings says when the chosen display keeps Dynamic Island off displays without a notch, such as a monitor beside a MacBook, and offers All displays. Settings → Dynamic Island → Layout → Displays without a notch.
- Focus follows mouse keeps Chrome's address bar suggestions and other pop-ups open when the pointer moves between them and their window.
- App Switcher, Dock Preview and Watch pause window captures while macOS is slow to check the app's permission to see the screen, which could log you out under heavy load. Thumbnails also stop updating while the displays sleep or the screen is locked.
- App Updates stops showing false updates for apps numbered differently in the public catalog, such as Private Internet Access, Sonos, Sublime Text and Positron, and lists apps it can't compare, such as Unified Remote and Android Studio, under Versions not compared.
- A custom Dynamic Island width applies to Controls, Now Playing and Timer again, and the Layout preview shows the island at the size it opens. Settings → Dynamic Island → Layout → Size.
- On a display without a notch, Dynamic Island hidden by Hide content in full screen opens on hover, not only with its shortcut.
- A timed screenshot preview on Dynamic Island set to Hidden until hover closes on its own again while the mouse moves.
- When the window switcher replaces macOS ⌘Tab, the shortcut no longer goes dead while another app has secure input on, as password fields do. macOS's switcher answers until it turns off, and Window switcher settings say why.
- Text Snippets and Command Bar settings no longer claim to know which app holds secure input. They name the app that was active when it turned on, never Vorssaint itself.
- Quit Protection in Screen Sharing and other remote desktop or virtual machine apps passes a ⌘Q confirmed by holding it or pressing it twice on to the other computer instead of quitting the app itself.
- Smooth scrolling keeps its glide in the window or scroll area where it started instead of carrying into the one under the pointer.
- Quit on close no longer quits an app when you minimize its window, as Premiere Pro did.
- Extra Brightness no longer leaves only the wallpaper in Mission Control's desktop thumbnails.

### Contributors
Thanks to @andrewgribben, @baacon, @bebricoOOOOOOf, @becastellani, @bharathvbcr, @cdbrandt729-code, @Chubi01, @Dusk-afk, @emreertunc, @iltonandrew, @jainnam-1993, @juanra, @Likheet, @marianhoenscheid, @mendozal, @mikeknight85, @mmoradi97, @mschoeffmann, @pedro-fontinele, @RKeyProg, @rohanod, @root-daemon, @StudioKeys, @suhrudsh, @ucrbuffalo, @webipsum, @Yahddyyp and @Zvzdov.
Feedback: Brain.

## [3.4.2-beta.1] - 2026-10-18

### Summary
A cleaner Dynamic Island, a What's New window that shows what changed in the features you use, and new screenshot editor tools. Also a faster Command Bar, better AI Agents, recordings and window switcher, and many fixes.

### Highlights
- **What's New for the features you use.** After an update, a window shows what changed in the features you use, and the release notes before updating can be turned off. Settings → About → Updates.
- **A cleaner Dynamic Island.** The open island drops page titles and the ⋯ menu, keeps each page's controls beside the camera and plays music in a compact Now Playing player.
- **New screenshot editor tools.** The editor adds a Spotlight tool, canvas expansion and image layers pasted with Command-V.
- **AI Agents for every Codex account.** Limits show for each separate Codex account, and Claude's limits come through Claude Code, so use on other Macs counts. Settings → Dynamic Island → Content → AI Agents.

### Added
- Dynamic Island can show the keyboard input source when it changes. Settings → Dynamic Island → Activity → Indicators.
- Dynamic Island can open and close with a keyboard shortcut. Settings → Dynamic Island → Behavior → Opening.
- Dynamic Island can find covers for YouTube and YouTube Music playing in Firefox, Zen and other Firefox-based browsers. Settings → Dynamic Island → Content → Music → Find covers for Firefox and Zen.
- AI Agents can show limits for each separate Codex account. Settings → Dynamic Island → Content → AI Agents.
- After an update, What's New shows what changed in the features you use. The release notes before updating can be turned off. Settings → About → Updates.
- The screenshot editor adds a Spotlight tool, canvas expansion and image layers pasted with Command-V.
- Screenshot previews can copy the text in a capture when Copy text from screen is installed.
- The window switcher can limit how many items fit in a row. Settings → Window switcher → Options → Maximum columns.
- With Snap windows at screen edges on, a window moved with the modifier drag also snaps.
- The scratchpad shows Markdown task lists as checkboxes, and Shift-Return continues a list.
- App Updates can leave out any app, including one with no update showing. Settings → App updates → Update exceptions.

### Changed
- The open Dynamic Island drops page titles, the ⋯ menu and the companion, keeps each page's controls beside the camera and has a compact Now Playing player. Pin, Settings and Close are a secondary click away.
- Dynamic Island's clipboard page opens on the last copy, keeps search behind a button and can show compact entries. Settings → Dynamic Island → Content → Clipboard.
- AI Agents reads Claude's limits through Claude Code when it is installed, so use on other Macs counts.
- Command Bar opens and searches faster.
- Clipboard history's sensitive-text filter is now off by default, also after upgrading. Copies marked as confidential and ignored apps stay out. Settings → Clipboard.
- Volume mixer sliders follow perceived loudness, and saved levels keep how loud each app plays.
- The Volume mixer can lower the speakers to silence when headphones disconnect, and 0% also mutes them.
- Recording a single window captures only that app's sound, and Save as GIF and Copy as GIF work for recordings of any length.
- With Show only the current desktop on, the window switcher still lists fullscreen windows from other desktops while Show fullscreen windows is on.
- The menu bar panel's Super key row names its mapping while the key is on.
- The Power card can list accessory batteries without the menu bar item. Settings → Monitor → Power.
- Settings → Features installs and uninstalls each feature with a button instead of a switch.

### Fixed
- Dynamic Island no longer runs below the physical notch when the menu bar is taller than it, and Hide gap below notch is now off by default. Settings → Dynamic Island → Layout → Notch fit.
- Dynamic Island hides its focus ring until you use the keyboard, keeps slider levels off the top row and shows the playing app's icon for songs without a cover.
- Dynamic Island's home and Tools pages fit their tiles at small custom sizes instead of cutting off a column.
- Playing music takes the idle companion's place in Dynamic Island and stays selectable beside AI activity.
- The island scratchpad's shortcut opens and closes it every time.
- Clipboard, Scratchpad, Quick Launcher and Shelf shortcuts expand the island's capture controls instead of opening the island after the capture.
- With the capture controls in Dynamic Island, a selection drag that starts on the desktop draws a selection.
- Lyrics are found for more songs whose titles, albums or artist credits differ between catalogs.
- Volume keys keep moving on outputs that only take coarse steps, and 0% from the menu bar panel, Command Bar or a volume key also mutes the output.
- Volume feedback shows the selected headphones or AirPods icon, also when muted.
- Audio controls no longer crash with microphones that report an invalid volume, such as the Insta360 Link 2C Pro.
- The mixer treats Studio Pro 8 as a DAW and leaves its audio routing alone.
- The window switcher, Dock Preview and Command Bar no longer list windows a hidden app already closed or blank helper entries, and choosing a window brings only that window forward.
- The window switcher lists apps that macOS reports without a process ID, such as Xcode's Device Hub, with their windows.
- Window switcher and Dock Preview can pause thumbnails in programs that are not apps, such as the Java behind Minecraft, and mouse features and Window Layout recognize such programs added by path.
- Window switcher settings explain why replacing macOS app shortcuts locks some choices.
- Dock clicks and Dock Preview act on the right instance of an app that runs as several processes.
- Mouse navigation handles quick switches between Back and Forward and gives side clicks back to apps without Back or Forward commands.
- Mouse features leave Launchpad alone when Launchpad or the Dock is listed under Apps to leave alone.
- Cleaning Mode keeps middle click and debounce suspended, and input taps stopped for permission cleanup or shutdown no longer restart.
- Clipboard history's optional sensitive-text filter no longer rejects commands, terminal output or links just for mentioning words such as "token" or "password".
- Paste as plain text and snippets cancel when a newer copy replaces the clipboard first.
- Snippets no longer leave the trigger's first character in address bars that complete what you type.
- Number shortcuts in Clipboard history, the island's clipboard page, Command Bar, the snippet list and Quick Launcher also work with the numeric keypad.
- Command Bar keeps an app hidden after its shortcut hides it, reads more browser selections and keeps spaces and line breaks when changing letter case.
- Command Bar finds the tools inside Xcode, such as Simulator and Instruments, and handles February 29 and impossible dates such as April 31.
- The uninstaller removes iPhone and iPad apps, refuses apps that live inside another app and says why it refuses one.
- App Updates opens destinations without freezing and treats beta10 and rc10 as newer than beta9 and rc9.
- Disk Image Installer ignores Homebrew's cached installers.
- The screenshot editor keeps every tool reachable in short windows.
- Recordings and exports fall back to H.264 when HEVC cannot encode their size, starting a recording no longer freezes the interface and exporting makes it stutter less.
- Window recordings keep only their app's sound after a browser starts a video mid-recording.
- AI Agents follows OpenCode 2, keeps an edited Codex conversation working as one task with its reviews and subagents, and estimates Claude renewals safely after long gaps.
- CPU temperature on Apple M4 Pro reads its hottest cores, so alerts and fan curves react in time.
- Display brightness ignores stale DDC replies from other monitor controls.
- Settings → Features no longer jumps or goes blank when a feature is installed or removed while scrolled down.
- Port Manager shows ports and PIDs without thousands separators.
- Quit on close keeps apps running while they still show something, such as a floating control bar, a slideshow or an Open dialog.

### Contributors
Thanks to @2-Chengs, @69grcv8vfm-sys, @AB-boi, @Acronyxxx, @Adridot, @ahmedabdullah-o, @akune, @Alpaka05, @beckhauser, @benjcrich, @brtkdev, @capozz03, @carltonking, @chadfidev, @claude, @COMEBACKISREAL, @cprecioso, @CSkjolden, @DanyRodier, @DigitalWestern, @eioz, @Ep0chalypse, @EtienneLescot, @EugeneCarldotme, @fandiyi047, @galpressman, @georgeat8, @gustavoramalho, @Hackmodford, @Hongsheng-Y, @iancenry, @iltonandrew, @JeanBaeez, @JoeC-Dev, @jonathanrparis, @joshrad-dev, @juanra, @kit101, @LechTheMitch, @Likheet, @LoBot9, @louisboii747, @luantedesco, @ManuLorenzzo, @Mohamed-Elshesheny, @mohammadhprp, @morhaf-ko, @Narangor, @nateships, @ncesar, @noctisyuan123-lgtm, @Noelia09, @npcmail010, @oecer, @oskarsss, @PerretWilliam, @PHSM22, @PratikPawar1401, @rgndxzzk, @rhukster, @RoccoRakete, @runxel, @samanyudas, @Samuel61904, @schematicdnb, @skiner68, @thitiwats, @Timothy-ZhangYF, @tyfoan, @unfilet, @voljumet, @webuildfabian, @Werkezeugs, @xftvl, @yuzu-octopus, @ywu73, @zepeng-jin and @zhanghk2001.

## [3.4.1] - 2026-10-08

### Summary
Dynamic Island now works on Macs and displays without a notch, on every display at once and on the Lock Screen. It adds a companion, Watch for any window, more AI agents, and new music, audio and calendar controls, while using much less battery. Window layout gets configurable snap areas, screenshots can go to the Shelf or a temporary link, and many bugs are fixed.

### Dynamic Island
- Floats as a capsule on Macs and displays without a notch, can show on every display at once and appears on the Lock Screen.
- A companion rests beside the camera, reacts to what happens and can carry the Command Bar out of the island. Settings → Dynamic Island → Companion.
- Watch turns part of any window, like a progress bar, into a live activity. Settings → Dynamic Island → Content → Watch.
- AI Agents adds OpenCode and GitHub Copilot, a choice of which limit to show and Codex banked resets.
- Music adds shuffle, hover controls, browser and video playback, and opens your music app when nothing plays. Controls add a microphone fader and a keyboard light slider.
- Calendar adds countdowns to the events you choose, the time left in the current event, week numbers and a choice of calendars.
- Animations use much less GPU and battery, and timer and countdown digits roll to each new value.

### Added
- Window layout snap areas: each edge and corner can use any placement, an edge can split into up to four areas, and windows snap across the edge two displays share.
- Screenshots can go straight to the Shelf, upload as temporary links, blur or erase only the text in an area and capture the full screen from the selection. Recordings can copy as GIFs.
- On macOS 27 and later, the Volume mixer can send one app to an AirPlay speaker.
- Command Bar previews and converts colors and remembers your app and emoji choices.
- A custom menu bar icon, linear scrolling, a fixed Spaces order, per-core CPU load, network speeds in bits and Focus follows mouse without raising windows.

### Changed
- The menu bar panel lists tools one line each, Keep Awake starts with one click, and the Settings sidebar can be hidden.
- Clipboard history opens as a resizable list or a shelf of cards that shows where each copy came from.
- New features wait on the Features page instead of installing themselves on update.

### Fixed
- Bug fixes in Dynamic Island, including music and lyrics, notices, hover and closing, AI Agents timing, battery and volume keys.
- Bug fixes in the window switcher, Dock Preview, window layout and focus follows mouse, including lag, stutter and placement across displays.
- Bug fixes in screenshots, recordings and the volume mixer, including quiet audio on outputs with many channels and lost pen strokes.
- Bug fixes in Clipboard history, paste as plain text, Command Bar, Cleaner, Uninstaller, Settings and the menu bar panel, including a freeze while scrolling the Features page.

### Contributors
Thanks to @0mgABear, @0miicr0n, @1119350264, @69grcv8vfm-sys, @AB-boi, @abdulshahid1, @acicovic, @Acronyxxx, @adam8833, @adhvikrayaprolu, @adnn-alc, @ahfornitani, @akune, @AlirezaBs, @arsarsars1, @Aryan-Saini, @ashishsnair, @ashwanthbalakrishnan5, @asim-sde, @Babelfisch, @Bald-M, @bebricoOOOOOOf, @benjaminbelloeil, @benjaminbrtrd, @bmrtfm, @Borisserz, @bravest-cat, @bweh, @cedigang, @claude, @daniel-dosiper, @dc0dr, @djc041006-bot, @dreammissnot, @elliotnev27, @emilianorobles, @emreertunc, @EugeneCarldotme, @fakepooh, @Ffinnis, @frieddeli, @Frozen0wl, @fuck713, @georgebnov, @Goonwb, @gorillasuti, @gxlactuss, @Harshul23, @hartra344, @HirschiK, @I-Have-No-Idea-What-Im-Doing-Right-Now, @iamprasad88, @IanHollow, @ilim-cell, @iltonandrew, @itsalexcoman, @iva-zhu, @JamesOBrien2, @jd4386, @JeanBaeez, @JoaoPedroSedrez, @Kernel-Hunter, @kushalvora, @LeChaEgg, @leekunwu, @liambennett1223-jpg, @luantedesco, @marjue12255, @massisenergy, @MaximilianMauroner, @MehmetHuseyinDelipalta, @mgailius, @mikeknight85, @mugurc, @muhammad-p, @muskecan, @mynameisluke, @naes993, @Narangor, @nickciava98, @nik2k-7, @niukanen1, @nkudrin713, @npcmail010, @NRanjan-17, @nzc0der, @odeioabacate, @oecer, @oskarsss, @ozanuslan, @PathGao, @PeshangALO, @Polovinkin, @priyanshuvishnoi, @Qarru, @raulpop8, @rebdeg, @renan-tiberio, @Retr0MrWave, @rhymeswithjazz, @rodalpho, @ruvelro, @sagnikonly, @samanyudas, @samueltpoj, @sarat03, @schnyders, @scream1ng, @Shlok-gupta08, @shlok1806, @sigwrench, @sim-pez, @slantie, @soguy, @suhrudsh, @tbills08, @tenbux, @theafox, @theguru789, @ThelloD, @thitiwats, @tobyadams87, @trac3r00, @tyteachestech, @veged, @velit, @Void1-1, @wenujacodes, @wuast94, @Yahddyyp, @yasinozmeen, @yuzu-octopus, @ywu73, @zecarreira, @zxedacus, alexandrejs, Barbel Design, Brain, Bureka, DeWalt Brushless, Emanuele Frasca, Emirhan, Gabriel, ItsMoses, Martimm500, Pinea, Shiro, the/master and yellow.

## [3.4.1-beta.5] - 2026-10-08

### Summary
The resizable Clipboard list is back, alongside improvements to music controls, search, downloads and audio routing.

### Highlights
- Clipboard history opens as a resizable list again, with room for a preview and selection actions on smaller screens. The card layout remains available in Settings → Clipboard → History layout.
- Command Bar remembers your app and emoji choices after a restart. Use Forget learned ranking in Settings to clear them.
- When nothing is playing, click the cover or playback controls in Dynamic Island to open your music app. Choose the app in Settings → Dynamic Island → Content → Music. Opening it does not start playback.

### Changed
- AI Agents is a separate choice when installing Dynamic Island. Updates preserve existing settings. Its frequent log checks pause when there are no active sessions or recent logs.
- Clicking a completed download's name or icon opens it in its default app. Finder and Shelf actions remain available.
- The Settings sidebar can be hidden and shown from the toolbar or with Control-Command-S, including in full screen.

### Fixed
- Screenshots taken with Freeze screen on include Dynamic Island when Show in screenshots and videos is enabled. Capture controls and previews stay out.
- Safari downloads show progress and completion notices, including quick downloads.
- Command Bar takes keyboard focus when its drop animation finishes.
- The calculator handles expressions such as `100 - 20 - 30` and `8 / 2 / 2` without treating dates or times as calculations.
- Watch reads the complete percentage, including values above 999%, spaces between thousands and negative signs.
- Dynamic Island recognizes tracks from mpv launched in Terminal when it reports playback to macOS.
- Cleaner no longer lists an installed app's preferences as leftovers. Cleaner and Uninstaller also avoid confusing unrelated apps with shared components.
- Uninstalling the last copy of an app clears its Command Bar shortcuts, aliases, pins and hidden entries.
- Paste as plain text preserves images, videos and files, including when assigned to Command-V.
- Brightness keys keep their press and release together when displays reconnect or the pointer changes displays.
- The menu bar panel opens on the next click after closing, without the delay that could swallow that click.
- Scrolling through Dock previews no longer jumps back to the hovered window.
- Per-app audio output choices stay in effect at 100% volume. Changing the output for all apps also reroutes apps that were still using the previous device.
- Switching to Wine apps no longer sends the extra mouse press that could leave a button stuck in games.

### Contributors
Thanks to @bmrtfm, @Harshul23, @JeanBaeez, @MaximilianMauroner, @Narangor, @oskarsss and @yasinozmeen. Feedback: alexandrejs, Barbel Design, Brain, Bureka, Emirhan and Gabriel.

## [3.4.1-beta.3] - 2026-10-08

### Summary
Dynamic Island adds audio controls, music shortcuts and battery warnings while using less GPU and power. Window layout gains configurable snap areas, Clipboard history presents copied items as a shelf of cards, and screenshots can go straight to the Shelf.

### Dynamic Island
- Tools uses the quick panel's wand icon, so it is easier to tell apart from the sections button.
- When hover opens Dynamic Island, you can set how long it waits before closing, from 0.10 to 2 seconds. Settings → Dynamic Island → Behavior → Closing time.
- Controls can show a keyboard light slider next to Volume and Brightness, and its icon turns the light off and on. Settings → Dynamic Island → Content → Controls.
- The mixer puts a microphone fader beside the output, with mute and an editable percentage on supported devices.
- The music page can switch shuffle beside the playback controls for players that offer it. The first press asks for Automation permission.
- Up next says when the player does not share its upcoming songs, instead of showing an empty queue.
- The volume indicator stays hidden while headphones like AirPods Pro adjust their own level. Volume keys still show it.
- With Hide timer countdown on, the closed island shows the timer when time is up and keeps it until you dismiss it.
- The music bars and AI agent animations use much less GPU and battery, most of all on 120 Hz displays.
- Switching between Timer, Pomodoro and Stopwatch animates as changing pages does, instead of the island jumping to its new size.
- Now Playing follows music and videos from browsers and other apps on its own, and a paused video stays instead of switching to paused music. Settings → Dynamic Island → Content → Music → Automatically include videos and other apps.
- Gestures open and close the island with shorter swipes and quick flicks.
- The calendar month can number its weeks. Settings → Dynamic Island → Content → Calendar → Week numbers.
- AI Agents stops counting a Claude Code turn once the Mac has been offline for about 20 seconds, unless a shell command is still running.
- Opening lyrics or Up next no longer changes the size of the player above them.
- The companion hides in the island by default when nothing is going on and comes out to visit and react. You can turn this off to keep it beside the camera. Settings → Dynamic Island → Companion → Hide when idle.
- Hovering over the cover in the closed island shows the song and artist. Hovering over the music bars reveals a play and pause button.
- In the Layout editor, the button of a section turned off in Content now looks dimmed, since the island leaves it out until the section is back on.
- Options that need an uninstalled feature, like Lyrics, Gestures or Command Bar in the island, now read off and grayed, with a button to Features.
- At rest keeps a choice that can't show just now, dimmed, with a link to what brings it back.
- Hide gap below notch closes the thin strip of wallpaper beneath the island and is on by default. Settings → Dynamic Island → Layout → Notch fit.
- The resting battery icon follows the charge and shows when the Mac is plugged in. It can turn red when low, warn in amber first, and use the same colors in the menu bar. Settings → Dynamic Island → Activity → At rest → Battery.

### Added
- The screenshot editor's Pixelate tool is now Blur, and it can pixelate, blur or erase a whole area or only the text inside it.
- Window layout snaps to the edge two displays share once you slow down there, and a quick drag still carries the window to the other display.
- Each edge and corner that snaps a dragged window can use any placement, like a third or two thirds, and an edge can be split into up to four areas. Settings → Window layout → Window dragging.
- Network speeds can show in bits per second. Settings → System monitor → Network speed unit.
- Connected Devices opens from the System section of the menu and from the island's System page, without its menu bar widget.
- Tapping CPU in the System section of the menu shows the load of each core, grouped by core type. Settings → System monitor → CPU → Per core.
- In the Clipboard history window, the preview lays out copied JSON one value per line, and a picture's preview can copy the text in it.
- The screenshot editor can add its result to the Shelf, an image on the Shelf opens in the editor from its right-click menu, and every capture can go to the Shelf on its own. Settings → Screen capture → Add to the shelf automatically.

### Changed
- Clear unpinned asks first everywhere and says how many items it removes. Anything copied while it asks is kept.
- The Clipboard history window is a shelf of cards along the bottom of the screen, and each card shows the app the copy came from.
- Pressing an app's Command Bar shortcut while its window is in front hides the app, and the next press brings it back.

### Fixed
- Editing or discarding a screenshot, or turning off temporary links, prevents a late upload from copying a link to the original capture. Links returned after cancellation are revoked when the server can be reached.
- Watch stays stopped when an earlier area selection or capture preparation finishes late.
- Displays checks the connected screens again before turning one off, so unplugging another screen during the operation does not leave the last usable display disabled.
- AI Agents finishes only the Claude Code command named by a tool result, even when its output mentions other commands.
- Installing Developer no longer removes older official Vorss or Vorssaint Utils apps.
- The Clean button stays reachable in compact Cleaner panels in Dynamic Island, the menu and the quick launcher.
- Screen recordings release their audio-device monitoring when they stop, and cancelling startup no longer tries to release the same audio tap twice.
- The Empty the Trash confirmation opens above Dynamic Island and accepts mouse and keyboard input.
- In the Clipboard history window, a new copy no longer moves the highlight, so Return pastes the entry you picked.
- The screenshot editor no longer misses lines of text in very large and scrolling captures.
- Pen drawings in the screenshot editor no longer disappear when the stroke returns to its starting point.
- Focus follows mouse no longer flickers toward the window behind an open sheet or dialog, like a file list in System Settings.
- With Click the Dock icon to hide on, clicking a frontmost app that has no windows opens a new window instead of hiding it.
- The power reading in the menu bar follows the chosen update interval while the panel is closed.
- The Command Bar calculator and unit conversions accept both decimal separators where thousands are grouped with a space or an apostrophe, reject misplaced grouping separators and never read a number that starts with 0 as thousands.
- Automatic Clean URL leaves a copy alone when it carries more than the link, like several items or a picture, or a different link target. It preserves case-sensitive paths and leaves a newer copy untouched if it arrives while the previous one is still being read.
- The manual Clean URL result follows the link and rules as you edit them, and switching a site off keeps the names you added.
- Holding an extra mouse button to use the radial menu now highlights and picks slices.
- The screenshot editor keeps all its controls inside the window for small captures.
- Vorssaint no longer stops responding at launch while macOS is slow to report Launch at Login.
- Removing an app with the Uninstaller frees its Command Bar shortcut for another app.
- The mute key no longer lowers the volume when the output loses its mute control right after the press.
- In the Volume mixer, an app set below or above 100% no longer turns much quieter on outputs with four to eight channels, like a TV over HDMI or an audio interface.
- Screen recordings no longer capture the Mac's sound much quieter on outputs with four to eight channels, like a TV over HDMI or an audio interface. The island's live music bars also compensate for the quieter signal.

### Contributors
Thanks to @AB-boi, @Acronyxxx, @adam8833, @Babelfisch, @dc0dr, @djc041006-bot, @emilianorobles, @georgebnov, @gorillasuti, @gxlactuss, @iamprasad88, @JamesOBrien2, @JeanBaeez, @luantedesco, @massisenergy, @mgailius, @mugurc, @mynameisluke, @naes993, @Narangor, @nik2k-7, @niukanen1, @nkudrin713, @odeioabacate, @oskarsss, @PathGao, @Polovinkin, @priyanshuvishnoi, @samanyudas, @samueltpoj, @sarat03, @suhrudsh, @ThelloD, @velit, @wuast94, @ywu73 and @zecarreira. Feedback: Barbel Design, Brain and Martimm500.

## [3.4.1-beta.2] - 2026-10-06

### Summary
This beta gives Dynamic Island a companion that rests beside the camera, reacts to what happens and carries the Command Bar out of the island. Watch turns any part of a window into a live activity, and AI Agents now follows OpenCode and GitHub Copilot. On macOS 27, one app can play through an AirPlay speaker.

### Highlights
- **A companion in the island.** It rests beside the camera and comes out to react to music, timers, AI agents, downloads and more. Settings → Dynamic Island → Companion.
- **The Command Bar drops out of the island.** The companion becomes its face and takes it back when it closes. Settings → Dynamic Island → Companion → Command Bar in the island.
- **Watch any window.** Pick part of a window, like a progress bar or a score, and the closed island shows what it reads. Settings → Dynamic Island → Content → Watch.
- **More AI agents.** AI Agents follows OpenCode and GitHub Copilot next to Claude Code and Codex. Settings → Dynamic Island → Content → AI Agents.
- **One app on AirPlay.** On macOS 27 and later, the Volume mixer can send a single app to an AirPlay speaker. Settings → Volume mixer.
- **Screenshots as links.** A new shortcut uploads the latest screenshot as a temporary link and copies it. Settings → Screen capture → Temporary links.

### Dynamic Island
- A companion can live in the island, resting beside the camera and reacting to music, timers, AI agents, downloads and more. Betas install it if you use the Command Bar with the island. Settings → Dynamic Island → Companion.
- The Command Bar shortcut can drop the bar out of the island with the companion as its face, or open it inside the island. Typing as it drops shows the bar right away, and closing it sends the drop back. Settings → Dynamic Island → Companion → Command Bar in the island.
- Watch turns part of any window into a live activity and speaks up when it changes or shows a text or number you set. Nothing leaves the Mac. Settings → Dynamic Island → Content → Watch.
- AI Agents follows OpenCode and GitHub Copilot next to Claude Code and Codex, reading only what changed since the last launch. Settings → Dynamic Island → Content → AI Agents.
- The closed island can show the Session or Week limit instead of the one closest to running out. Settings → Dynamic Island → Content → AI Agents → Limit to show.
- The closed island can hide the timer countdown while the timer keeps running. Settings → Dynamic Island → Content → Timer → Hide timer countdown.
- The timer remembers the last duration you set, and its finished notice keeps the timer's orange.
- The Notifications page can clear its inbox from the header, after confirmation.
- Notices beside the camera take only the room they need on each side, and level notices ease to a new width instead of jumping.
- The capsule sits centered in the menu bar and grows around its content on hover. Capsule fit's Width and Height now rest in the middle at 0, capped at 40 and 4. Settings → Dynamic Island → Layout → Capsule fit.
- The Now Playing page is calmer, with plain controls, times beside the position bar and clear next steps when there are no lyrics or queue.
- Up next shows song covers and no longer blanks out on next or previous.
- Switching activities in the closed island slides the highlight and changes the strip in place, and play and pause react at once.
- An event countdown paired with music or AI agents takes only the width it needs, and clicking it opens that event on the Calendar page.
- The camera mirror fills the island's page, with Stop camera over the image.
- On the Clipboard page, Return pastes the first entry right away, as the history window does.
- The Downloads page without a folder explains what it does and offers a Choose Folder… button.
- Long pages and rows fade at their edges on macOS 15 and later.
- Menus opened from the island's buttons use its dark look.
- On the Lock Screen, the padlock island matches the music strip, and the player and activities leave with the lock screen as the Mac unlocks.

### Added
- Window layout accepts pointer shortcuts made only of modifiers, and Maximize with Margin has an adjustable margin.
- An optional fixed Spaces order stops macOS from rearranging desktops by recent use.
- Port Manager rows can copy their port, PID or address and open TCP listeners in a browser.
- App usage lists offer Force Kill when Kill Process is installed.
- Return or Enter copies the selected color and closes the color picker.
- The recording editor can copy the edited recording as an animated GIF.
- The screenshot confirmation preview can be hidden or kept from 1 to 10 seconds or until dismissed. Settings → Screen capture → Screenshot → More options.
- A new shortcut, off by default (⌃⌥⌘U), uploads the latest screenshot as a temporary link and copies it, never an edited or discarded capture. Settings → Screen capture → Temporary links.
- The screenshot selection has a Full screen button for the display under the pointer.
- On macOS 27 and later, the Volume mixer can send one app to an AirPlay speaker while the rest keeps playing where it was. Choose AirPlay in the app's output menu.
- Clipboard searches highlight the matching words, and Control-N and Control-P move through the history.
- Option-Up and Option-Down move lines in Scratchpad and the snippet editor.
- Focus follows mouse can focus a window without raising it, with a hover delay from 100 ms to 3 seconds.

### Changed
- The switcher is named Window switcher, and screens are consistently called displays.
- Monitor settings put each reading's options beside its label, and history graphs show their scale.
- The Settings sidebar groups tools like the Features page.
- With Group dependencies on, Homebrew lists dependency updates under the packages that need them.
- Pasting or copying an entry from Clipboard history moves it to the top. Pinned entries keep their place.
- Deleting a Radial Menu profile asks for confirmation.

### Fixed
- Displays switched off in Vorssaint keep their power-on control, and a different monitor on the same connection is not switched on in their place.
- Clipboard history reopens at the top, searches large histories faster and keeps copied lists of links intact. Clipboard settings has one Clear unpinned button.
- URL cleaning removes tracking parameters without rewriting the rest of the link.
- Quick pointer passes no longer leave Dynamic Island enlarged or open, header buttons hide again when the pointer leaves, and Expand on hover opens directly.
- A click at the top edge while the island grows opens it, and Keyboard navigation no longer leaves a focus ring around the camera.
- Dynamic Island keeps the current song while a web player loads the next one, switches to a browser that starts playing and shows play and pause as the player reports them.
- Lyrics are found for songs without an album, and their timing buttons are easier to click.
- Dynamic Island mutes the output when its volume keys reach zero, and after sleep the volume and mute keys start from the real level.
- Brightness keys and shortcuts ease the display to each level, and brightness and volume keys with Option, Command or Control reach macOS again.
- On a Mac with a notch, Show outline no longer hides behind the camera, and page titles too long for the space beside it move to a row below.
- The Combine menu names each pair in the order the island shows it.
- AI Agents shows the 5-hour session renewing on time, reads the Codex limit of Business accounts and ends a Claude Code turn when a tool finishes it.
- Checking or using a banked Codex reset no longer refreshes plugin marketplaces.
- The Command Bar's Kill Process rows follow the page's sort, and its Actions list includes Uninstall Application, Emoji and Kill Process.
- Searching a feature in the Command Bar lists its switch first, and app shortcuts there can take over a macOS shortcut.
- Window switcher stays responsive while preparing previews, keeps showing busy apps and no longer raises a window twice after a Space switch.
- Window captures keep sheets and dialogs when the window spans two displays.
- Maximize no longer restores the old size of a window moved from another display.
- With Snap windows at screen edges on, dragging inside apps such as Logic Pro no longer stutters, and Move and resize by dragging no longer stalls other input.
- Dock Preview keeps its gaps with Large and Extra large cards and stays in place when the Dock hides automatically.
- With three-finger drag on, a four-finger press works as a middle click, and the setting says when no readable trackpad is available.
- Confirming Quit Protection for Steam quits it instead of only closing its window.
- Keep Awake can use helper apps inside another app as triggers, and a running session brings back the hidden app icon.
- The Shelf keeps its edge peek after a drop while the source app delivers the file.
- With the adapter connected but charging paused, the battery shows the bolt and the Mac is described as plugged in.
- The system monitor moves sizes and rates to the next unit at the boundary, and odd SMART or accessory battery values no longer crash the app.
- App Updates no longer offers the installed release again when only its letter case differs.
- Settings backups keep capture folders and the music app path on each Mac.
- Fast magnifier zoom crosses its range in a few wheel notches.
- Cancelling a GIF export no longer leaves an empty file behind.
- The Uninstaller and its Command Bar list offer only apps it can remove, and `Tools/uninstall.sh` now removes the password-free closed-lid rule.
- Cleaner no longer treats renamed screenshots as untouched captures.
- When Launch at login waits for approval, General settings says so and links to System Settings.
- Radial Menu settings say when a profile has nothing that opens it, and a mouse button opens only one wheel.

### Contributors
Thanks to @0mgABear, @69grcv8vfm-sys, @acicovic, @adhvikrayaprolu, @adnn-alc, @akune, @AlirezaBs, @ashwanthbalakrishnan5, @asim-sde, @Bald-M, @bebricoOOOOOOf, @benjaminbelloeil, @benjaminbrtrd, @bmrtfm, @Borisserz, @bravest-cat, @claude, @dc0dr, @dreammissnot, @elliotnev27, @emreertunc, @EugeneCarldotme, @fakepooh, @Ffinnis, @frieddeli, @Frozen0wl, @fuck713, @georgebnov, @gorillasuti, @hartra344, @IanHollow, @ilim-cell, @iltonandrew, @itsalexcoman, @iva-zhu, @JamesOBrien2, @jd4386, @JoaoPedroSedrez, @kushalvora, @LeChaEgg, @leekunwu, @liambennett1223-jpg, @marjue12255, @MehmetHuseyinDelipalta, @mikeknight85, @nickciava98, @niukanen1, @NRanjan-17, @nzc0der, @oecer, @oskarsss, @ozanuslan, @PathGao, @PeshangALO, @Qarru, @raulpop8, @renan-tiberio, @Retr0MrWave, @rodalpho, @ruvelro, @sagnikonly, @samanyudas, @sarat03, @schnyders, @Shlok-gupta08, @shlok1806, @sigwrench, @sim-pez, @soguy, @tbills08, @tenbux, @theafox, @theguru789, @thitiwats, @tobyadams87, @trac3r00, @wenujacodes, @Yahddyyp, @yuzu-octopus and @ywu73. Feedback: Barbel Design, Emanuele Frasca, Pinea and the/master.

## [3.4.1-beta.1] - 2026-09-29

### Summary
This beta takes Dynamic Island beyond the notch. It floats as a capsule on displays without one, can show on every display at once and now also appears on the Lock Screen. The menu bar panel gets a cleaner layout and opens centered again on macOS 14 and 15, and Siri AI on macOS 27 no longer opens Vorssaint's Settings.

### Highlights
- **A floating capsule.** On external monitors and Macs without a notch, Dynamic Island floats in the middle of the menu bar and opens from it, like a phone's island. Settings → Dynamic Island → Layout → Displays without a notch.
- **Every display at once.** The island can show on all your displays, and a click on any of them opens it right there. Settings → Dynamic Island → Behavior → Display → All displays.
- **On the Lock Screen.** Music gets a player you can seek, and the timer, AI agents, downloads and your next event share a line under the clock. On a display with a notch, a padlock opens as the Mac unlocks. Settings → Dynamic Island → Activity → Lock Screen.
- **Countdowns to the events you choose.** Right-click an upcoming event on the island's Calendar page and choose Add Countdown. The island can also show the time left in the event in progress and pair a countdown with music, a timer, a download or an AI agent. Settings → Dynamic Island → Content → Calendar.
- **Keep Awake at a glance.** A running Keep Awake session shows the time it has left in the closed island. Settings → Dynamic Island → Content → Controls.
- **Rolling digits.** Timer and countdown digits roll to each new value, unless Reduce Motion is on.
- **A cleaner menu bar panel.** Utilities, Controls and Quick toggles share one card, one line per tool.
- **Colors in Command Bar.** Type a color to preview it, then convert it with "to hex", "to rgb", "to hsl" or "to swift".

### Dynamic Island
- On displays without a notch, such as external monitors, the island floats as a capsule in the middle of the menu bar and opens from it, as a phone's island does. A song shows its title for a few seconds as it starts, then only its cover and sound bars. To keep the simulated notch, choose Notch in Settings → Dynamic Island → Layout → Displays without a notch. Capsule fit, on the same tab, makes the capsule wider, taller or lower.
- The island can show on every display at once. The one under the pointer responds, the others show what it shows closed, and a click on any of them opens it there. Choose All displays in Settings → Dynamic Island → Behavior → Display.
- The island can follow the pointer between displays, so files dropped on it on one display can be dragged out on another. Choose Follow pointer in Settings → Dynamic Island → Behavior → Display.
- The island can appear on the Lock Screen. Music gets a player you can seek, in Liquid Glass on macOS 26 and later. The timer, AI agents, downloads and the next event share a line under the clock. On a display with a notch, a padlock opens as the Mac unlocks. Turn on Show on the Lock Screen, and optionally Lock and unlock sounds, in Settings → Dynamic Island → Activity → Lock Screen.
- The closed island can show a running Keep Awake session with the time it has left. Turn it on in Settings → Dynamic Island → Content → Controls.
- Right-click an upcoming event on the island's Calendar page and choose Add Countdown to count down to just that event. The option appears while Event countdown, which counts down to every timed event, is off in Settings → Dynamic Island → Content → Calendar.
- The event countdown can be paired with a timer, music, a download or working AI agents from the Combine menu, which appears when the pointer rests on the closed island while more than one activity is running.
- The island can count down the last hour of the calendar event in progress, alongside or instead of the countdown to the next one. Turn on Time left in current event in Settings → Dynamic Island → Content → Calendar.
- Choose which calendars appear, grouped by account, in Settings → Dynamic Island → Content → Calendar → Calendars shown. Hiding a calendar clears its events right away.
- The island's Controls page shows a running timer's clock and your next appointment on their shortcuts.
- Microphone mute and unmute notices show in the closed island in place of the separate popup. They can be turned off with Microphone in Settings → Dynamic Island → Activity → Indicators.
- The island can keep opening on the page chosen in When reopening while music, a timer or another activity is showing. Turn off Open the visible activity in Settings → Dynamic Island → Behavior → Opening.
- The island can be fitted to the notch's width and height on Macs where an edge of the notch shows around it. Use Notch fit in Settings → Dynamic Island → Layout.
- The open island can use a translucent background while Liquid Glass is off. Turn on Translucent background in Settings → Dynamic Island → Layout → Size.
- The AI Agents page adds a Resets card for Codex that shows how many banked resets you have and when the next one expires, and uses one after you confirm. Show or hide it in Settings → Dynamic Island → Content → AI Agents → Cards.
- The Recent captures page can clear the whole history from its header, as the menu bar panel already could.
- Timer and event countdown digits roll to each new value, unless Reduce Motion is on. In the closed island only the minutes roll, which saves energy.
- Notification banners fit their message instead of always using the same wide strip, and keep one width while several messages arrive in a row.
- On macOS 27, Hide the system banner, formerly Dismiss the system banner, takes the original off screen as soon as the island shows the message instead of closing it about a second later. Its sound plays to the end and it still goes to Notification Center. The option is in Settings → Dynamic Island → Content → Notifications.
- Screen capture controls start compact, open while the pointer rests on them and close when it leaves. Open, they place their title and buttons in the top row, beside the camera when they fit, and away from the island's edges, so less of the screen is covered.
- Escape steps back one level, closing the mixer options, month grid, lyrics or queue, or leaving a detail opened inside the island, before it closes the island.

### Added
- Command Bar previews a color typed on its own and converts it with "to hex", "to rgb", "to hsl" or "to swift". Return copies it.
- The Vorssaint menu bar icon can be replaced with a symbol from a gallery, or with any SF Symbol typed by name. Settings → Menu bar → Menu bar icon.
- Scratchpad adds a formatting toolbar in both the floating pad and Dynamic Island, opened from its Formatting button, and native text search with Command-F. Its text size is set in Settings → Scratchpad → Text size.
- The Shelf shortcut can add the files selected in Finder. Turn on Add the Finder selection with the shortcut in Settings → Shelf.
- App Updates can skip one version of an app or stop checking an app altogether, so it stays out of update results and alerts. Right-click the app in Settings → App updates or in the menu bar panel. Choices can be undone under Update rules on the same page.
- App Switcher can browse apps with a mouse wheel or trackpad while it is open, with precise wheel movement and consistent scroll direction.
- Optional linear scrolling moves a fixed distance per wheel notch, with a separate list of apps to leave alone. Install it from Settings → Features → Mouse and keyboard, then adjust Lines per step in Settings → Linear scrolling.
- Brightness keys and display brightness shortcuts can move in half or quarter steps. Choose Brightness key steps in Settings → Displays → More options, shown while Control displays is on.
- When several installed features were never turned on, the Features page offers to uninstall them, with Undo, or to keep them. Settings → Features → Never turned on.

### Changed
- The menu bar panel lists Utilities, Controls and Quick toggles one line per tool in a single card. Descriptions move to tooltips and edit mode, while permission notes, status and side effects such as a Finder restart stay on the row.
- New features wait on the Features page instead of installing themselves on update, starting with linear scrolling.
- App Switcher and Dock Preview each keep their own list of apps where window previews pause, in Settings → App switcher → Window thumbnails and Settings → Dock Preview → Window thumbnails. The switcher's list starts as a copy of the one they shared.
- Keep Awake starts with one click from duration chips or an end time in the menu bar panel. The switch and shortcut restart the last choice, and the panel explains when battery protection prevents a session.

### Fixed
- Dynamic Island no longer closes when you click or point at a popover that extends past its edge, such as the Keep Awake end time picker.
- The activity chosen in the closed Dynamic Island stays chosen when a song changes or an agent pauses between turns, instead of switching back to the timer.
- Dynamic Island keeps the current song on screen while a player loads the next one, instead of briefly showing an empty music page and changing size. With the New track indicator on, the compact island keeps the previous song until the indicator shows the next one.
- Clicking the Now Playing cover in Dynamic Island, or the radial menu's Now Playing card, brings the playing app to the front instead of doing nothing, and shows its window again when it was closed.
- Volume keys play the macOS feedback click again while Dynamic Island shows the volume, following the system's Play feedback when volume is changed setting and Shift.
- Setting the volume from Command Bar no longer adds a floating confirmation under the volume notice in Dynamic Island.
- Dynamic Island stops the Claude Code timer as soon as its session is quit or its terminal closes in the middle of a task, instead of counting for up to ten more minutes.
- AI Agents no longer keeps Vorssaint busy for minutes after launch on Macs with a long Codex history.
- Dynamic Island accessory alerts no longer show a connection notice when a phone, tablet or computer connects to the Mac over Bluetooth.
- Dynamic Island's Tools page no longer scrolls by itself while the pointer rests on a tool away from the center, so tools stay put and are easy to click.
- Dynamic Island's Fan Control page is as tall as its card, instead of opening a tall, mostly empty page even with the Compact size.
- On Macs without a battery, Dynamic Island settings no longer offer Battery at rest or among its indicators, and an island already set to show the battery at rest stays empty instead of showing a battery icon with no charge.
- Some Mac mini, Mac Studio and iMac models no longer show an empty Battery card in Dynamic Island, or battery readings, alerts and settings they cannot use.
- Holding or dragging an icon in the Dock no longer opens the Shelf, in Dynamic Island or in the menu bar drop zone.
- Text fields in Dynamic Island, the menu bar panel and Quick Launcher yield Esc to input method composition, so it cancels the text being composed in Chinese, Japanese and Korean instead of closing the island, the panel or the open utility, or discarding a Volume Mixer percentage being typed.
- The menu bar panel opens centered under its icon again, without a gray band along its top and right edges on macOS 14 and 15, and tall tabs no longer open it beside the icon.
- Opening or using Siri AI on macOS 27 no longer opens Vorssaint's Settings or menu bar panel.
- Closing the menu bar panel returns focus to the previous app without switching desktops.
- Esc in Settings no longer closes the menu bar panel open beside it, so it clears a search or closes a sheet there. A confirmation or popover opened from the panel now closes before the panel does.
- The menu bar panel shows the Controls tab when Focus follows mouse is the only installed control, so its switch is no longer out of reach.
- VoiceOver reads the name of every menu bar panel tab instead of its symbol.
- Expanding a weekly Automatic cleanup in the Cleaner no longer cuts off the edges of the menu bar panel or Quick Launcher. The weekday moves to its own row when it does not fit beside the time.
- Scrolling the Features page in Settings no longer stutters or freezes the app.
- The Features page shows that App Switcher and Super key also listen to the mouse, and that the music app blocker listens to the keyboard, as does Brightness when its key options are on.
- App Switcher no longer lags while stepping through apps with Tab, and activating an app no longer stalls Vorssaint while its window previews warm up.
- Dock Preview, App Switcher and Command Bar list every window of an app that was hidden and shown again, not only its front window.
- Dock Preview's Panel background slider, which has no effect on Liquid Glass, is turned off while Liquid Glass is on and points to System Settings → Appearance instead.
- Window Layout edge snapping remains available when displays share Spaces and macOS tiling controls are unavailable.
- Mouse side buttons go back and forward again in Safari, Finder and other apps on keyboard layouts such as German and French.
- Keyboard and mouse debounce now honor the configured interval on Apple silicon, and scrolling features use consistent event timing.
- Radial menu profiles refuse a shortcut that another profile or feature already uses, and other shortcut settings now warn when a combination belongs to a radial menu profile.
- The Keyboard Shortcuts page lists the shortcuts radial menu profiles use and links to the Radial menu page to change them, instead of showing an outdated shortcut whose changes had no effect.
- Extra Brightness no longer hides purchase confirmations in the system app store or administrator password prompts.
- Clipboard History search reuses prepared text while typing in long histories, reducing repeated processing.
- Scratchpad warns in both views when notes cannot be saved and shows a warning if the final save fails while closing.
- Homebrew commands and app update checks use proxy and mirror settings exported by the user's shell, allowing package operations on networks where direct access is blocked.

### Contributors
Thanks to @0mgABear, @0miicr0n, @abdulshahid1, @ahfornitani, @arsarsars1, @Aryan-Saini, @ashishsnair, @bebricoOOOOOOf, @bweh, @cedigang, @daniel-dosiper, @Ffinnis, @Frozen0wl, @Goonwb, @gorillasuti, @HirschiK, @I-Have-No-Idea-What-Im-Doing-Right-Now, @IanHollow, @ilim-cell, @iva-zhu, @Kernel-Hunter, @muhammad-p, @muskecan, @npcmail010, @PathGao, @renan-tiberio, @rhymeswithjazz, @ruvelro, @sarat03, @scream1ng, @shlok1806, @slantie, @trac3r00, @tyteachestech, @veged, @Void1-1, @Yahddyyp and @zxedacus. Feedback: Brain, DeWalt Brushless, ItsMoses, Pinea, Shiro and yellow.

## [3.4.0] - 2026-09-27

### Summary
Dynamic Island brings music, live activities and everyday tools together at the top of your screen, including a dedicated view of your AI agents. Version 3.4.0 also expands window management, capture and clipboard tools, adds automatic audio device switching, and improves everyday reliability and performance.

If you use Extra Brightness on 3.3.5, turn it off before updating so it cannot cover the administrator password prompt.

### Dynamic Island
- An optional, experimental island for Macs with or without a camera cutout, with customizable layouts, click or hover opening, gestures and keyboard navigation.
- Control music with seeking, synchronized lyrics and the player's queue. Follow music apps automatically or choose a playback source; online lyric lookup requires separate consent.
- Keep timers, focus cycles and a stopwatch within reach, browse your calendar, and preview or revisit notifications.
- Choose which activity stays visible beside the camera, or combine a timer with music, a download or a working AI agent.
- Follow local AI agent activity, plan limits, API value and usage history, with alerts for completed tasks and usage limits. Usage data stays on your Mac.
- Reach Clipboard History, Shelf, Scratchpad, the volume mixer and device controls without leaving the island. Drag in files for storage or media tools, and manage captures from its header.
- Arrange sections and shortcuts with a live preview, choose where the island reopens, and customize its outline, Liquid Glass, display and full-screen behavior.

### Added
- Screenshots gain custom watermarks, sharing, pinning and editor shortcuts. Screenshot and recording editors offer adjustable blur strength, and recordings can export at speeds from 0.25× to 4×.
- Clipboard History gains a resizable window, image editing and color swatches. Shelf keeps pinned items across restarts and accepts complete attachments dragged from other apps.
- Window Layout adds quarter rows and columns, vertical thirds, app exceptions and width cycling. New shortcuts help move windows and the pointer between displays, including stacked monitors.
- App Switcher adds filtering by the pointer's display and optional instant selection. Dock Preview gains an experimental option to keep an auto-hidden Dock visible while browsing.
- Audio device priority switches to the highest-ranked connected output or microphone. The volume mixer adds microphone volume, pinned apps and a saved custom order.
- Display controls add extra dimming for supported external monitors, custom brightness shortcuts and optional built-in display dimming with the lid closed. Keyboard brightness is adjustable from the panel.
- Command Bar adds scientific calculations, emoji skin tones and up to 64 custom shortcuts.
- Keep Awake adds separate Duration and Until modes and stricter automation conditions. Fan Control can optionally resume a manual speed or curve after restart or sleep.
- An optional wallpaper gallery in the menu panel.
- Slovak and Ukrainian translations throughout the app.

### Changed
- Settings gains grouped navigation, Back and Forward buttons and clearer feature setup. Newly installed features start their main behavior unless a previous choice was saved.
- Package management offers direct installation from search and groups dependencies; Cleaner and Uninstaller scans can be cancelled.
- Lower temporary memory use in the screenshot editor.

### Fixed
- Bug fixes in App Switcher, Dock Preview and multi-display behavior, including window focus, unwanted resizing, slow previews and panel placement.
- Bug fixes in screenshots and recordings, including image sharpness, scrolling captures, audio synchronization, saving and capture shortcuts during a recording.
- Bug fixes in Clipboard History and audio controls, including recovery after clipboard service restarts or stalled playback, and clearer handling of failed copies and microphone changes.
- Reliability fixes for permission resets, keyboard input, sleep restoration, cleaning, uninstalling and menu bar icon recovery, with clearer reporting when an operation cannot finish.

### Contributors
Thanks to @1119350264, @adnn-alc, @akeslo, @akune, @anandghegde, @ancoesat, @aniruddhaadak80, @archieamas11, @bebricoOOOOOOf, @Borisserz, @brandom, @cdbrandt729-code, @celltower, @cjscld, @COMEBACKISREAL, @dajiaohuang, @DarkEden-coding, @delfu, @DiogoDuart3, @DocEmmetBrown, @drybx, @EdenRochmanSharabi, @ethanbeau, @EugeneCarldotme, @fakepooh, @fermincasagrande, @frixaco, @Frozen0wl, @GabrielDazzi, @georgebnov, @GolamRafi27oo, @ilim-cell, @iltonandrew, @integral-llc, @iva-zhu, @JashRashne, @justin-chiam, @Kernel-Hunter, @kirolos-esmat, @KumarSashank, @kxnstandin, @loburets, @Logimon, @MakhBeth, @maodijim, @marcelharinck, @MaximilianMauroner, @MrDXTR, @muskecan, @naveenkrdy, @NongKnot, @npcmail010, @overstock718, @owendaw, @PathGao, @pergioa, @rado9904, @ranak8811, @rkrkrkk, @root800080, @ruvelro, @samanyudas, @Samuel61904, @samueljim, @santi-ug, @sarat03, @shlok1806, @stephansann, @tenbux, @trac3r00, @tuttopassastudios, @Yahddyyp, @Yash121l, @ywu73, @zamai, @zeuslcf, @zorahrel, Azelance, Brain, DucemMortis, Jets, Monolithic capacitor, Mower, Pinea and Slipshady.

## [3.4.0-beta.7] - 2026-09-26

### Summary
External monitors gain extra dimming, and Clipboard History gains a resizable window. Dynamic Island lets you choose the activity to display or combine a timer with another activity, and improves clipboard access and full-screen controls. Screen capture is more responsive, and the volume mixer can recover stalled audio.

### Added
- External monitors with readable brightness control offer optional Extra dimming in Settings. The lower part of the slider dims the picture below the monitor's hardware minimum, while the rest keeps using hardware brightness.
- Clipboard History's separate window resizes by dragging an edge or corner, and remembers the chosen size.
- Dynamic Island's Clipboard page pastes the first nine entries with ⌘1–⌘9, as the separate window does, and shows the shortcuts while the island has the keyboard.
- App Switcher can skip highlight, scrolling and panel resize animations while browsing, with smooth selection still the default.
- Dynamic Island's fan card opens Fan Control with its manual speed and curve controls, and still shows each fan's speed when the fan helper is unavailable.
- When several activities are active, hovering over the closed Dynamic Island reveals named choices. Select one activity on its own, or use Combine to show a timer beside music, a working agent or a download; the choice lasts while that activity remains available.

### Changed
- AI agent usage reads large logs with less temporary memory and avoids unnecessary display updates. Alerts queued by a stopped session no longer appear after restarting the feature.
- The closed Dynamic Island gently grows on hover before a click or a configured hover opening, while respecting Reduce Motion and available menu bar space.
- On displays without a camera cutout, Dynamic Island stays visible through app and display focus changes when Show over the menus is enabled, including at rest. With that option off, it uses measured free space only after finding menu geometry on the chosen display.
- With Hide content in full screen enabled, Dynamic Island keeps a black, clickable cutout over the camera in full screen, and clicking, hovering or a shortcut opens its tools. A simulated cutout stays hidden until a shortcut opens it.
- Unavailable cards in Dynamic Island settings open the feature, island section or Displays setting they need. After updating, island users whose brightness feedback waits for Control displays are invited once to turn it on.
- Liquid Glass has separate switches for Dynamic Island and for other windows and panels. The island keeps its current look after updating.
- Command Bar shortcuts allow up to 64 bindings, enough for every letter and other commands.
- The mouse extra-click filter shows its window directly in Settings and can be tuned in 1 ms steps.
- Quit on Close's Settings warns that apps such as screen recorders may keep working after their last window closes, and points to Exceptions to prevent an unwanted quit.

### Fixed
- Scrolling screenshots respond faster to wheel, keyboard and scrollbar movement, preserve completed content after later capture failures and avoid transparent seams. The screenshot preview releases focus before opening the editor.
- Long window titles in App Switcher and Dock previews stay still when Reduce Motion is enabled.
- Dynamic Island stays off external monitors in closed-lid mode when Built-in display is selected, and returns to the laptop display when it becomes available again. While hidden it does no background work, and a finished timer rings once the island is back. Macs without a built-in display keep the island on the main display.
- Dynamic Island sends a player's supported Play or Pause command when available, improving control of radio streams.
- Temperature alerts show their limits and notifications in the selected temperature unit.
- With inactive apps hidden, the volume mixer shows an app as soon as it starts playing.
- Volume mixer detects audio processing that stalls after initially working and attempts recovery without requiring a reset or restart. Adjusting an app's volume also checks its audio path.
- Clipboard History no longer refreshes the whole list when the pointer moves between entries.
- Turning off automatic copy for screenshots also stops the after-capture Copy action, so captures no longer reach the clipboard. Save and copy becomes Save.
- Screenshot, text and color shortcuts work during a recording when their capture menu is turned off, and leave the recording running. With the menu on, they still wait for the recording to end.

### Contributors
Thanks to @1119350264, @EugeneCarldotme, @loburets, @ranak8811, @ruvelro, @Samuel61904 and @stephansann.

## [3.4.0-beta.6] - 2026-09-25

### Summary
Settings is easier to navigate and highlights linked sections together. New Dynamic Island setups start compact with their sections turned on, and the island adds an optional outline, animated compact music and better play/pause for video players. Features installed from the Features hub now start working right away.

### Added
- Dynamic Island can show an optional outline, white at rest and orange around a compact timer, including in the layout preview.

### Changed
- A new Dynamic Island setup starts compact, opens by click, keeps the app panel in its own window and installs its extensions, with lyrics, queue, notifications, agents, downloads and activity indicators turned on. Islands already set up keep their current behavior.
- Installing a feature from its Features hub row, a preset or the first-run picker turns on its main behavior unless an earlier choice was saved, so tools such as Quit on Close work right away. Install all only makes features available.
- The compact timer strip fits its wings to the reading and companion, places their content at the island's ends, and resizes when the reading or working agents change.
- Settings groups the sidebar into sections, opens tool options in focused pages, and makes the Features catalog and navigation easier to use. Linked settings receive one outline around the whole section, and display brightness shortcuts show an icon.
- Compact music stays visible while the island retracts, fades into another activity, and yields to new playback. Reduce Motion skips the animation.

### Fixed
- Dynamic Island play/pause works with the active video player even when its media session has no item identifier.
- Homebrew search results offer a direct install button in Dynamic Island and the menu panel, and reflect the installed state after a package changes.
- Clipboard History keeps recording after the macOS pasteboard service restarts, instead of silently stopping until Vorssaint is relaunched.

### Contributors
Thanks to @npcmail010 and @zorahrel.

## [3.4.0-beta.5] - 2026-09-25

### Summary
Dynamic Island gains optional calendar and music indicators, room for a timer beside music or a working agent, and a spring animation. This beta also adds audio device priority, more window layouts, screenshot sharing, pinned Shelf items, and Slovak and Ukrainian. It fixes focus and permission-reset issues while reducing background work and screenshot editor memory use.

### Added
- An optional calendar indicator counts down the hour before the next timed event; a separate, optional New track indicator briefly shows each song. Both are off by default.
- A running timer can share the closed island with music or a working agent. An option can hide the menu bar icon while Dynamic Island is available; the icon returns when the island is off and still appears for updates or a muted microphone.
- Clipboard History images can open in the Screenshot Editor without replacing the clipboard, and copied color values show a swatch.
- The screenshot preview can pin a capture, and the preview and editor can share it through the macOS Share menu. The editor adds a separate text size and adjustable blur strength for screenshots and recordings.
- Window Layout adds quarter rows and columns, vertical thirds, an Ignore apps list, and an optional cycle through side widths. Repeating Top or Bottom Half can move a window to a stacked display. Maximize windows can keep the native full screen button in chosen apps; a shortcut can move the pointer to the next display.
- Audio device priority can rank outputs and microphones and switch to the highest-ranked connected device. It is off until installed from the Features hub. The menu bar can also count connected external USB devices.
- Shelf items can be pinned across uses and restarts. Its menu bar drop zone can appear as a top-center badge, and its settings offer the same Dynamic Island or separate window choice as the island settings.
- Fan Control can resume a manual speed or curve after restart or sleep, and closed-lid mode can dim the built-in display. Both options are off by default. A keyboard light slider is available in the menu panel and Settings.
- The menu panel can apply still wallpapers from a new, optional Wallpaper section. Smooth scrolling adds an optional Coast slider, and a radial menu can open with a four-finger tap when that gesture is free.
- Command Bar scripts can run directly from their global shortcut when enabled. Settings adds Back and Forward buttons, and Monitor can show available or used disk space instead of a percentage.
- The Cleaner can list forgotten screenshots as an unchecked category, subject to its age setting. Slovak and Ukrainian are now available throughout the app.

### Changed
- Settings lists tools directly in the sidebar and gives Dock Preview and Dock clicks their own page. App Switcher and Dock Preview keep separate preview sizes.
- App Switcher separates apps without open windows. Its minimized-window preference also applies to apps hidden with Cmd+H by default, with a new switch to exclude them. The App shortcuts table can be sorted by any column.
- The chosen replacement for Music can start playing when Play/Pause opens it, after Automation access is granted. Play after opening replacement is on by default and can be turned off. The menu panel uses the native macOS popover animation.
- Dynamic Island uses narrower music and download indicators, keeps a download's name and progress bar when space allows, and shows clearer connection notices. It adds a spring animation for opening and closing, and floating buttons that match Liquid Glass. Notices shrink into the island as they close.
- Homebrew's Installed list groups dependencies under their parent packages, with a switch to restore the flat list. Port Manager marks listeners available on every network interface.

### Fixed
- Dynamic Island stays in place across desktops, full screen and a hidden menu bar, steps aside in Mission Control, and remains open when hovered from another display. The menu bar icon returns while the island is hidden in full screen.
- Dynamic Island keeps its glass dark during transitions, its playback controls steady while checking access, and its search and settings controls usable in narrow windows. Lyrics now match Apple Music singles and EPs.
- Dynamic Island keeps Open available for notifications from closed apps. Clipboard search selects results with the arrow keys and activates one with Return; Reduce Motion no longer flashes page content during opening.
- Brightness keys from external keyboards reach Dynamic Island and the overlay. When the island is hidden, turning off its brightness indicator leaves the system indicator in charge.
- Extra Brightness stays active while Vorssaint's own controls are in use and comes down before an update's administrator prompt. External-monitor brightness keys keep a level just set with a slider.
- Clipboard History loads image previews in the background, keeps pinned entries within its storage limit, and reports when a quick paste cannot reach its target. Command Bar reports failed copies and changes brightness on the display under the pointer.
- App Switcher preserves focus order and avoids a second focus attempt after a window is already in front. It and Dock Preview no longer hit controls at the top-left of a window they activate; minimal Dock previews no longer leave empty bands.
- Panels, captures and window drops follow the pointer's display even at its top edge. Floating panels stay out of tiling window managers.
- A mouse wheel now scrolls sideways lists, such as the Dynamic Island mixer and App Switcher, when nothing around them scrolls vertically.
- A window capture includes a sheet on macOS 27. Shelf files in Dynamic Island respond to the first click and can be dragged out; the screenshot preview responds to Command-W.
- Settings search keeps keyboard focus. The capture tool picker and Dynamic Island settings fit narrow windows, and the Features hub and menu panel improve VoiceOver labels and explanations.
- The Cleaner and Uninstaller can cancel a scan. Permission reset, complete uninstall, settings export, automatic cleanup, Super key access and partial microphone mute failures report when they could not finish. Permission reset now stops before revoking access if sleep restoration or system-service detachment fails.
- Homebrew uninstall refuses stale confirmations. Mic Mute restores each input channel's own level, and switching to an already-active output no longer reports failure.
- Closed-lid dimming applies immediately when enabled with the lid already closed. CPU readings recover after a long pause, and refreshing AI usage totals while an agent works uses about a quarter of its previous CPU. Bluetooth power is queried only when a restore is owed.
- Wallpaper scans and thumbnail preparation wait until its gallery opens, and screenshot pixelation keeps small sampled mosaics instead of full-size copies for each strength.
- Fan Control stops redrawing its curve editor after the menu panel closes, which kept CPU use high. App Updates no longer reports an update when the installed version only adds a leading v, such as v2.0.11.1.
- Window Layout shortcuts continue while Disk Image Installer alerts are open, and its Settings page no longer shows an empty row.

### Contributors
@ancoesat, @aniruddhaadak80, @archieamas11, @celltower, @delfu, @DiogoDuart3, @DocEmmetBrown, @drybx, @ethanbeau, @frixaco, @Frozen0wl, @GabrielDazzi, @georgebnov, @ilim-cell, @integral-llc, @iva-zhu, @Kernel-Hunter, @kirolos-esmat, @KumarSashank, @MakhBeth, @maodijim, @MaximilianMauroner, @npcmail010, @overstock718, @PathGao, @rado9904, @root800080, @ruvelro, @samanyudas, @samueljim, @sarat03, @shlok1806, @tenbux, @Yahddyyp, @zamai and @zeuslcf. Feedback: Azelance, Brain, DucemMortis, Jets, Monolithic capacitor, Mower, Pinea and Slipshady.

## [3.4.0-beta.4] - 2026-09-23

### Summary
Dynamic Island adds an AI Agents section for Claude Code and Codex, lets you choose the playback source and can hide in full screen, with clearer lists, controls and settings. App Switcher and Dock Preview no longer resize the windows they bring forward.

### Added
- Dynamic Island adds an AI Agents section that follows Claude Code and Codex from the logs they keep on this Mac: plan limits and when they renew, API value, live work, models, projects and a 13-week activity map. A working agent can show beside the camera, and notices report long tasks finishing and limits running low or renewing. The section is off by default and your usage stays on the Mac; prices come from a public list that ships with the app and can refresh daily.
- Dynamic Island lets you choose the playback source, such as a browser while a music app is playing, or return to Automatic.
- Dynamic Island can hide while an app is in full screen on its selected display. The option is off by default.

### Changed
- Dynamic Island's Content settings list sections with checkboxes and drag to reorder, show the chosen section's options and preview the island live. Settings also explain unavailable indicators, pages and Controls shortcuts, and Scratchpad joins the opening destinations, opening in the island by default.
- Dynamic Island shows compact activity over crowded menus by default, unless you turned it off. Thanks to @Yahddyyp.
- Dynamic Island uses tighter compact strips and narrower volume, brightness and keyboard backlight indicators, and places navigation and titles beside the camera when there is room. Update controls adapt to narrow headers in every language. Thanks to Pinea for the feedback.
- Dynamic Island restores vertical calendar and clipboard lists, and long event titles can wrap. Explore shows three rows of sections in the Compact and Spacious layouts and scrolls one row at a time, with dots beside the grid to jump between rows. Shortcut and Tools rows fill in reading order and center a short last row, and arrow keys follow the same order.
- The Dynamic Island mixer aligns its faders, enlarges volume controls and click targets, shows the output device name and uses a speaker icon for its floating button.
- Dynamic Island lists visible files and folders from the selected Downloads folder, newest first, including images saved directly from a browser.
- The Dynamic Island layout editor previews the real home page at scale, with the cards and shortcuts you have configured.
- With Liquid Glass enabled, the expanded Dynamic Island uses clear glass with a dark top that fades toward the lower edge, and it looks active as soon as it opens. Resting and compact strips stay black, and Reduce Transparency keeps the solid surface.

### Fixed
- Dynamic Island opens on the first hover after closing under the pointer, such as after pressing Escape or clicking its header.
- Dynamic Island keeps floating buttons clear of the menu bar and inside short windows, lets empty areas between controls take clicks and scrolling, and no longer closes unexpectedly when clicked inside.
- Dynamic Island keeps clipboard and mixer actions visible in short layouts, fits the camera mirror at 4:3 with its stop button and keeps horizontal scrollbars off controls. System fills balanced rows that leave room for cards to grow on hover, and the clipboard page focuses its search field.
- Dynamic Island keeps artwork through play/pause updates and while the next cover loads, shows volume and brightness in its open header, and gives battery alerts more padding. Thanks to @Yahddyyp.
- Dynamic Island keeps the artist visible while a song plays, keeps expanded playback controls visible while player access is being set up, and lets the artwork glow fade into its margins.
- Dynamic Island's resting strips match the camera cutout's height and corners, so no dark line shows under the notch, and keep the battery icon and percentage, including `100%`, clear of the curved edges.
- Dynamic Island's calendar and notification times follow the system's region and 12/24-hour clock, while day and month names stay in the app's language.
- Dynamic Island keeps accessory notices compact, with device icons that do not suggest an incorrect battery level.
- Dynamic Island leaves persistent native alerts open when replacing notifications, so mirroring an alarm does not dismiss it.
- Dialogs opened from Dynamic Island, such as importing lyrics, choosing the Downloads folder, saving media or archives, renaming, closing and saving a Scratchpad, and confirmations in its tools, appear above it without changing its size, appearance or keyboard focus.
- Screenshot preview actions stay in the Dynamic Island header above the image, with compact buttons that leave room for the title.
- Dynamic Island opens and closes cleanly inside Mission Control, and animates its dismissal on displays without a camera cutout when the menu bar has no room for it to rest.
- App Switcher and Dock Preview bring the selected window forward without resizing it toward the top-left corner of the screen.
- Window captures skip decorative borders that other apps draw around windows, and the recording editor shows the full picture while you choose a zoom focus. Thanks to @Yahddyyp.
- The recording editor drops a zoom or blur selection that undo removed, so choosing a focus point or drawing a blur area no longer does nothing.
- Cleaning Mode waits for mouse buttons held during unlock to be released before closing. Thanks to @bebricoOOOOOOf.

## [3.4.0-beta.3] - 2026-09-20

### Summary
This beta focuses on Dynamic Island, with a horizontal layout in place of the vertical stack and updated music, notifications, timers and controls. Dock Preview also gains an experimental option to keep an auto-hidden Dock visible while you browse previews.

### Changed
- Dynamic Island adopts a horizontal layout, with side-by-side cards, a redesigned mixer, compact calendar and timer controls, and an embedded Scratchpad.
- Dynamic Island can be shorter, down to 260 points, with content that adapts to the available space. Opening it during music, a timer, a download or a notification goes straight to that activity.
- App Switcher shows more window previews when space allows, including two side by side.

### Added
- Dynamic Island previews notification messages on hover, with actions to open, dismiss or browse the inbox.
- Dynamic Island gains a stopwatch and optional music bars that follow playback. Music bars require system audio permission.
- Dynamic Island can show compact activity over menu bar items, off by default under At rest in settings.
- Dock Preview can experimentally keep an auto-hidden Dock visible while you browse window previews. Enable it under More options; it is off by default.
- Screen recordings export video, GIFs and shared links at custom speeds from 0.25× to 4×, with pitch-preserving audio.
- The mixer adds microphone volume control on supported devices, plus pinned apps and a saved custom order.
- Command Bar adds scientific calculations and emoji skin tones.
- Keep Awake offers separate Duration and Until modes and can require all selected automation conditions to remain active.
- Clipboard History can show the latest copied content beside the menu bar icon.

### Fixed
- Dynamic Island more reliably identifies playing media, avoids flickering on displays without a camera cutout, and stays out of tiling window managers.
- Dynamic Island uses clear on/off switches for Mac sound and microphone when selecting a screen recording.
- Keep Awake restores lid sleep after timers, battery cutoffs and quitting.
- Command Bar no longer requests Keychain access for query learning. Query-specific learning now lasts only until the app quits; general usage ranking remains saved.
- A missing menu bar icon can recover automatically after an update. Manual recovery points to Allow in the Menu Bar in macOS settings when the app is blocked.
- Clearing permissions now stops input listeners, preventing keyboard freezes.

### Contributors
Thanks to @muskecan, @ywu73, @GolamRafi27oo, @Borisserz, @justin-chiam, @marcelharinck, @tenbux, @sarat03, @DarkEden-coding, @cjscld, @ruvelro, @owendaw, @iva-zhu, @adnn-alc, @MrDXTR, @Yash121l, @kxnstandin, @JashRashne, @EdenRochmanSharabi, @pergioa, @naveenkrdy, @EugeneCarldotme, @samanyudas, @PathGao, @NongKnot, @shlok1806, @iltonandrew, @tuttopassastudios, @brandom, @COMEBACKISREAL, @Yahddyyp, @rkrkrkk, @akune, @dajiaohuang and @akeslo.

## [3.4.0-beta.2.1] - 2026-09-16

### Summary
Dynamic Island can hide until you hover, reopen where you choose and keep capture controls out of the way while you select. This beta also adds screenshot watermarks, makes screenshots and recordings sharper, and fixes Dock previews, timers, music, alerts and recording audio.

### Hotfix
- Dynamic Island shows an Update button only while open.

### Added
- Dynamic Island can stay completely hidden and appear only when you move the pointer to the top of the screen.
- Dynamic Island can reopen on the page you left or always on a section you choose.
- Dragging images or a video onto Dynamic Island lets you choose between the shelf and the media tools.
- The screenshot editor can add your own text or image as a watermark, with position, size, transparency and rotation. Thanks to @Logimon.
- Image conversion can name results with a menu of placeholders and save batches in their own subfolder. Thanks to @ruvelro.

### Changed
- Capture controls in Dynamic Island collapse while you select and after a few idle seconds, and come back with a click or hover.
- You can choose how long the pointer needs to stay on Dynamic Island before it opens.
- Dynamic Island matches each display's menu bar height and shows the track name on screens without a camera cutout. Thanks to @ruvelro.
- Timers longer than an hour now show hours and minutes wherever the time appears.
- Compact timers have more room beside the camera and stay there when menu space changes, including in full screen.
- Recordings in Balanced quality keep the full screen resolution, so text stays as sharp as in the system recorder.

### Fixed
- Dock Preview and App Switcher keep windows from other desktops available, with an optional Dock filter and no empty flashes during desktop changes.
- Dynamic Island stays in place when the desktop is revealed after opening on hover.
- Dynamic Island shows the right headphone icons, keeps device alerts readable and no longer shows a wrong volume alert when switching outputs.
- Dynamic Island no longer shows playing music at rest when you turned that off, while the music controls remain available.
- Displays without a camera cutout get a simulated cutout inside the menu bar that keeps its shape when opening. Thanks to @Yahddyyp.
- Screen captures start on the first drag and keep the selector and magnifier smooth while the controls are in Dynamic Island. Thanks to @ruvelro.
- Saved, copied and shared screenshots open at their real size and stay as sharp as system screenshots.
- Screenshot previews take the keyboard when they appear, so ⌘C and ⌘S work right after a capture, with a switch in More options.
- Screen recordings no longer fail to save when the microphone or system audio changes format while recording.
- Image conversion applies the chosen watermark transparency and centers previews. Thanks to @ruvelro.

## [3.4.0-beta.2] - 2026-09-16

### Summary
Dynamic Island can hide until you hover, reopen where you choose and keep capture controls out of the way while you select. This beta also adds screenshot watermarks, makes screenshots and recordings sharper, and fixes Dock previews, timers, music, alerts and recording audio.

### Added
- Dynamic Island can stay completely hidden and appear only when you move the pointer to the top of the screen.
- Dynamic Island can reopen on the page you left or always on a section you choose.
- Dragging images or a video onto Dynamic Island lets you choose between the shelf and the media tools.
- The screenshot editor can add your own text or image as a watermark, with position, size, transparency and rotation. Thanks to @Logimon.
- Image conversion can name results with a menu of placeholders and save batches in their own subfolder. Thanks to @ruvelro.

### Changed
- Capture controls in Dynamic Island collapse while you select and after a few idle seconds, and come back with a click or hover.
- You can choose how long the pointer needs to stay on Dynamic Island before it opens.
- Dynamic Island matches each display's menu bar height and shows the track name on screens without a camera cutout. Thanks to @ruvelro.
- Timers longer than an hour now show hours and minutes wherever the time appears.
- Compact timers have more room beside the camera and stay there when menu space changes, including in full screen.
- Recordings in Balanced quality keep the full screen resolution, so text stays as sharp as in the system recorder.

### Fixed
- Dock Preview and App Switcher keep windows from other desktops available, with an optional Dock filter and no empty flashes during desktop changes.
- Dynamic Island stays in place when the desktop is revealed after opening on hover.
- Dynamic Island shows the right headphone icons, keeps device alerts readable and no longer shows a wrong volume alert when switching outputs.
- Dynamic Island no longer shows playing music at rest when you turned that off, while the music controls remain available.
- Displays without a camera cutout get a simulated cutout inside the menu bar that keeps its shape when opening. Thanks to @Yahddyyp.
- Screen captures start on the first drag and keep the selector and magnifier smooth while the controls are in Dynamic Island. Thanks to @ruvelro.
- Saved, copied and shared screenshots open at their real size and stay as sharp as system screenshots.
- Screenshot previews take the keyboard when they appear, so ⌘C and ⌘S work right after a capture, with a switch in More options.
- Screen recordings no longer fail to save when the microphone or system audio changes format while recording.
- Image conversion applies the chosen watermark transparency and centers previews. Thanks to @ruvelro.

## [3.4.0-beta.1] - 2026-09-15

### Summary
Dynamic Island is the focus of this update, bringing music, timers, calendar, notifications, downloads, files and everyday controls beside the camera. Improvements also cover App Switcher, clipboard, captures, recordings and cleaning.

### Dynamic Island
- An optional island for Macs with or without a camera cutout, with customizable layouts, hover expansion, gestures and trackpad feedback.
- Music controls include seeking, synchronized lyrics and the player's queue, with music apps taking priority over browser videos.
- Drag floating shortcuts beside or below the island, and reach its sections through a searchable gallery and keyboard navigation.
- Timers and configurable focus cycles stay accurate through sleep, with repeating sound alerts for up to five minutes.
- Browse appointments by month and mirror new notifications, with an optional inbox that clears when the Mac locks.
- Follow downloads from a chosen folder, organize shelf files, create ZIP archives, convert media and open the camera mirror.
- Volume, brightness, keyboard light and accessory alerts share a black surface that stays consistent across appearances.
- Online lyric lookup needs separate consent and sends only the title, artist, album and duration, never audio.

### Added
- Dynamic Island brings music, timers, calendar, notifications, downloads, files and controls beside the camera, off until you turn it on in Settings.
- Shelf accepts attachments dragged from other apps, preserving complete files and original names. Thanks to @Borisserz.
- Display brightness gains optional custom shortcuts for the primary display or the display under the pointer. Thanks to @EugeneCarldotme.
- App Switcher can show only windows on the display under the pointer, staying closed on empty displays. Thanks to @EugeneCarldotme.
- Scratchpad tabs can be created with Command-T and closed with Command-W, keeping confirmation for notes with text. Thanks to @Borisserz.
- Screenshot gains custom editor shortcuts and optional keyboard focus for previews. Thanks to @santi-ug.

### Changed
- The App Switcher opens more smoothly when many windows are open. Thanks to @bebricoOOOOOOf.

### Fixed
- Clipboard History skips expired copies, reports failed writes and avoids automatic paste after failure. Thanks to @MaximilianMauroner.
- Fan Control keeps trying to take over stopped fans on Macs that lack the firmware unlock key. Thanks to @Yash121l.
- Power keeps the system reading legible beside its graph while editing the panel. Thanks to @COMEBACKISREAL.
- Screenshots respect editor and pinned-image visibility when switching capture tools, while recordings keep capture windows hidden. Thanks to @anandghegde.
- App Updates clears missing-source warnings only when the catalog can verify the app, preserving incomplete checks otherwise. Thanks to @iltonandrew.
- App Switcher keeps its icon row steady and selected windows visible during searches and window closures. Thanks to @shlok1806.
- Uninstaller reports completed removals accurately, counts recovered space once and keeps real failures visible. Thanks to @Borisserz.
- Screen recordings keep video, audio, cursor effects and typing zooms aligned through startup and pauses, without blank openings. Thanks to @EugeneCarldotme and @fakepooh.
- Menu bar icon recovery waits for placement, preserves full-size content and avoids overlapping attempts. Thanks to @Borisserz.
- Panels and App Switcher stay open when typing with the Accessibility Keyboard, including the first use. Thanks to @fermincasagrande.
- Quit on close keeps incoming calls connected when their app has no open window. Thanks to @Borisserz.
- Cleaner preserves installed customizations and localization folders during manual and scheduled cleanup. Thanks to @EugeneCarldotme and @ywu73.
- App Switcher keeps newly opened windows focused and makes more apps available in crowded window lists. Thanks to @akune.
- The App Switcher no longer shows blank entries for hidden helper windows that apps keep out of window cycling. Thanks to @EugeneCarldotme.
- The menu bar panel keeps one continuous background up to the small arrow at its top. Thanks to @iltonandrew.

## [3.3.5] - 2026-09-06

### Summary
Hotfix update for Dock actions, window focus, video presets, temperature readings and the menu bar icon. Extra brightness can now be toggled from the Displays panel, and the full feature update is included below.

### Changed
- Extra brightness can be switched on and off directly from the Displays panel.

### Fixed
- Dock previews and click actions work while recording the screen or using overlays that let pointer input pass through.
- Focus follows mouse keeps working through recording overlays while respecting windows that actually receive input.
- Video editor presets restore added images with their position, size and opacity for the whole video, independently of the original recording.
- CPU temperature readings are back on Macs where the System panel had stopped showing them.
- The menu bar icon stays visible after updating and keeps the spot you arranged.

### Everything from 3.3.3
Window controls, recording tools and everyday shortcuts gain more options, with less background work and stronger protection for saved content. This stable release brings together the improvements since 3.3.2, including the full beta cycle and the final reliability fixes.

### Performance
- Dock previews: 50% shorter default opening wait, from 400 to 200 ms; 60% shorter app-switching wait, from 250 to 100 ms.
- CPU: less repeated work in window previews, mouse controls, search and cleaning; Quit on close stops causing excess CPU use in watched apps.
- Memory and graphics: fewer retained images and icons, more efficient recording effects, and less repeated work when adjusting watermarks or extra brightness.
- Background activity: fewer unnecessary checks and history writes; unused keyboard and mouse listeners are released when features turn off.

The Dock figures describe configured waits, not total loading time. Battery-life gains and overall CPU, memory or GPU savings have not been measured against 3.3.2.

### Feature highlights
- Protect against accidental quitting and closing, arrange windows with pointer gestures, and drag Dock previews to move windows.
- Blur private details in recordings, add picture overlays, and compress videos or GIFs to a chosen file size.
- Automate Keep Awake for selected apps, switch Bluetooth off during sleep, and customize fan speeds on supported Macs.
- Find more app updates, manage app shortcuts in one place, and create separate radial menus for different tasks.

### Safety and reliability
- Safer saves preserve recordings, captures and notes when operations fail; personal content uses private storage, and cleanup reports files left behind.
- Fixes for unresponsive typing, scrolling, window switching and display controls, plus clearer text and selection in light and dark appearances.

### Details
The selected changes below cover new options and fixes that affect everyday use. Small cosmetic adjustments, tour changes and build-only maintenance are omitted.

### Added
- Quit Protection guards Command Q and Command W with a hold, double press or extra modifier, configurable per app. Thanks to @RuanMD and @PathGao.
- Window Layout offers eight-direction pointer placement, adjustable gaps, selectable snap areas and centered half-width windows. Thanks to @Bald-M, @marcelharinck, @levelupimprovement and @Borisserz.
- Drag Dock previews to move windows, including minimized windows and windows on other desktops. Thanks to @PathGao.
- Dock Preview and App Switcher offer minimal previews; middle-clicking a card closes its window.
- Dock Preview can quit an app from its close button, with an adjustable opening delay. Thanks to @arefshal and @PathGao.
- App Switcher offers screen selection, appearance delay and minimized or fullscreen window visibility options. Thanks to @noahjstewart, @yasinozmeen and @itsofirk.
- Recording tools add timed blur, picture overlays with nine positions, and filmstrip scrubbing with drag-to-cut selection. Thanks to @saminton.
- Video and GIF compression can target a file size you choose. Thanks to @FlowSync0.
- Capture tools offer separate shortcuts, optional mode menus, adjustable magnification and precise keyboard pixel selection. Thanks to @wiidede, @PathGao, @RecoilGaming, @EugeneCarldotme and @ruvelro.
- Recent captures can open directly with a shortcut; recognized text can be joined into one paragraph. Thanks to @ywu73.
- Keep Awake can run for selected apps and pause while the Mac is locked. Thanks to @Borisserz and @Advaith3600.
- Bluetooth on sleep disconnects sleeping Macs from accessories and restores Bluetooth on wake only if it turned it off. Thanks to @marcfusch.
- Mouse controls add acceleration disabling, worn-button click filtering and button-drag gestures for desktops and window overviews. Thanks to @CrowKiller and @iltonandrew.
- Super key supports right-side modifiers, input-source switching and exceptions for selected apps. Thanks to @JoanLaRosa, @BenjaminD2023 and @Borisserz.
- Keyboard shortcuts can adjust keyboard backlight brightness one step at a time. Thanks to @EugeneCarldotme.
- App shortcuts, aliases and pinned favorites have one searchable management page.
- Command Bar adds compact mode, argument-free script shortcuts and an app restart command. Thanks to @kobebrylant, @rhukster and @CSkjolden.
- Radial Menu adds custom profiles, themes, triggers, an interactive editor and a Now Playing card. Thanks to @ruvelro and @PathGao.
- Clipboard history supports 10,000 items or unlimited retention, multiple-item deletion and clearing unpinned items with confirmation. Thanks to @ElPotara and @CSkjolden.
- Text snippets offer a visual date and time builder with timezones and live previews. Thanks to @tenbux.
- Shelf adds file sharing, media thumbnails and optional clearing on close. Thanks to @tenbux and @bilalnoork.
- Kill Process can find, restart or end processes and their children, with confirmation before ending them. Thanks to @naveenkrdy.
- Battery temperature alerts, disk ejection exceptions and a visible-screen Cleaning Mode offer more control. Thanks to @ywu73 and @PathGao.
- Liquid Glass effects can be switched off on macOS 26 and later; the app icon supports system appearance styles. Thanks to @divisionseven.

### Changed
- Fan Control adds continuous manual speeds and editable temperature curves, with current and target fan speeds on supported Macs.
- Power brings battery charge, health, history, temperature, accessories and energy-consuming apps together; System adds compressed memory and cached files.
- App Updates checks publisher feeds and a public catalog, preserves partial results and identifies apps that could not be fully checked.
- Uninstaller and Cleaner find more verified leftovers and clearly identify files they could not remove. Thanks to @PathGao.
- Clean URL offers editable site-specific tracking rules and shows what it removed. Thanks to @PathGao.
- Sound Mixer groups devices, can hide inactive apps and offers finer keyboard volume steps. Thanks to @ruvelro.
- Command Bar remembers choices, tolerates short typos and expands emoji search; Settings search opens matching sections. Thanks to @MaximilianMauroner and @pergioa.
- Window Layout maximizes at the top edge and moves windows between displays when left or right shortcuts repeat.
- Smooth scrolling offers adjustable speed and response across standard and high-refresh displays.
- Window switching, Dock previews, recording effects, cleaning and file organization avoid repeated work. Thanks to @PathGao.
- Quit on close avoids elevated CPU use in watched apps. Thanks to @iltonandrew.
- Clipboard and Shelf show richer image previews; Shelf waits briefly before expanding during a drag.
- Personal clipboard content, Shelf files, recordings and share records use private storage. Thanks to @ThomasWaldmann.
- Scratchpad notes use private storage, stay out of settings backups and preserve unreadable originals. Thanks to @CSkjolden.
- Settings backups preserve local exceptions without exporting machine-specific paths. Thanks to @iltonandrew.
- Disk image installation shows progress and offers to remove the download after installing.

### Fixed
- Typing and shortcuts stay responsive while App Switcher collects windows from slow apps. Thanks to @MaximilianMauroner.
- Clipboard operations no longer freeze Command Bar or quick tools when copied content stalls. Thanks to @PathGao and @atomsbaza.
- Clicks and scrolling stay responsive with mouse controls enabled; focus follows mouse respects held keys, buttons and excluded apps. Thanks to @khichinho.
- Input features step aside during account switching and recover afterward. Thanks to @PathGao and @iltonandrew.
- App Switcher handles more window types, restores native shortcuts after crashes and keeps reverse switching reliable. Thanks to @PathGao, @BenjaminD2023, @owendaw and @justin-chiam.
- App Switcher and Dock previews discard closed windows and show alternate icons consistently. Thanks to @atomsbaza, @iltonandrew, @EugeneCarldotme and @hash00.
- Dock actions bring restored windows forward, stay on the current desktop and respect fullscreen apps. Thanks to @pboucher, @PathGao and @iltonandrew.
- Quit on close detects windows created late; moving windows between displays preserves their size. Thanks to @iltonandrew and @DiogoDuart3.
- Super key preserves held modifiers, restores its source key after crashes and sends Escape correctly. Thanks to @victoraraujo01, @gatzifratzi, @PathGao and @hash00.
- Shortcut recording respects keyboard layouts, detects conflicts and accepts native switcher combinations. Thanks to @PathGao, @alexis-morain, @arsarsars1, @jtprogru and @owendaw.
- Clipboard and snippet searches support input-method composition; multiline snippets preserve every line and rich clipboard content. Thanks to @PathGao and @fermincasagrande.
- Clipboard keyboard navigation stays stable, large previews remain responsive and stored history stays readable. Thanks to @andreisuslov and @naveenkrdy.
- Shelf preserves saved items when its list cannot be fully read. Thanks to @PathGao.
- Capture history preserves images when its list cannot be read or saved.
- Recording saves preserve existing files if export fails or is canceled, and reject incomplete edits or damaged pointer data.
- Recordings avoid doubled mixer audio; stopping while typing no longer risks a crash. Thanks to @PathGao.
- Recording trim handles work from the start; other capture shortcuts leave active recordings alone. Thanks to @lmilojevicc.
- Window captures include dialogs and cross-display windows; scrolling captures avoid repeated footers. Thanks to @iltonandrew.
- Screenshot editing uses full-resolution copied images, and quick previews leave keyboard focus alone. Thanks to @iltonandrew.
- Capture guides stay readable and color picking matches the sampled pixel. Thanks to @nik-2002, @I-Have-No-Idea-What-Im-Doing-Right-Now, @PathGao and @MaksimEgorov.
- Temporary capture links stop appearing available after expiring during sleep. Thanks to @PathGao.
- Sound Mixer recognizes helper audio and prevents stale-audio stutters. Thanks to @PathGao.
- Display controls avoid freezes and restore brightness to the correct monitor after reconnection. Thanks to @ozimosko, @bayujo, @PathGao and @iltonandrew.
- Network readings recover without false spikes; speed tests report server errors and Wi-Fi commands stay responsive. Thanks to @mugurc.
- Memory, processor temperature and per-app resource readings are more accurate. Thanks to @pergioa and @PathGao.
- App installation opens the installed copy; stalled package jobs no longer freeze controls. Thanks to @PathGao.
- Automatic cleaning leaves protected files alone and reports failures; uninstalling restores closed-lid sleep. Thanks to @PathGao and @mugurc.
- Cut files can move into protected folders with system approval; cancellation preserves unfinished moves. Thanks to @aesophor.
- Mouse acceleration settings survive reconnection, and app exceptions recognize more running programs. Thanks to @iltonandrew.
- Keep Awake handles rapid closed-lid changes and more account names. Thanks to @Tr1meputiNe, @iltonandrew and @dhruvsaxena1998.
- Scratchpad reports save failures; Settings and floating panels keep usable sizes and readable controls. Thanks to @AB-boi and @PathGao.
- Light-mode selection, regional numbers, search and translations are clearer across supported languages. Thanks to @PathGao and @watain666.
- Restarting reliably reopens the app, and login settings explain when automatic startup is disabled. Thanks to @PathGao and @wenujacodes.

## [3.3.3] - 2026-09-06

### Summary
Window controls, recording tools and everyday shortcuts gain more options, with less background work and stronger protection for saved content. This stable release brings together the improvements since 3.3.2, including the full beta cycle and the final reliability fixes.

### Performance
- Dock previews: 50% shorter default opening wait, from 400 to 200 ms; 60% shorter app-switching wait, from 250 to 100 ms.
- CPU: less repeated work in window previews, mouse controls, search and cleaning; Quit on close stops causing excess CPU use in watched apps.
- Memory and graphics: fewer retained images and icons, more efficient recording effects, and less repeated work when adjusting watermarks or extra brightness.
- Background activity: fewer unnecessary checks and history writes; unused keyboard and mouse listeners are released when features turn off.

The Dock figures describe configured waits, not total loading time. Battery-life gains and overall CPU, memory or GPU savings have not been measured against 3.3.2.

### Feature highlights
- Protect against accidental quitting and closing, arrange windows with pointer gestures, and drag Dock previews to move windows.
- Blur private details in recordings, add picture overlays, and compress videos or GIFs to a chosen file size.
- Automate Keep Awake for selected apps, switch Bluetooth off during sleep, and customize fan speeds on supported Macs.
- Find more app updates, manage app shortcuts in one place, and create separate radial menus for different tasks.

### Safety and reliability
- Safer saves preserve recordings, captures and notes when operations fail; personal content uses private storage, and cleanup reports files left behind.
- Fixes for unresponsive typing, scrolling, window switching and display controls, plus clearer text and selection in light and dark appearances.

### Details
The selected changes below cover new options and fixes that affect everyday use. Small cosmetic adjustments, tour changes and build-only maintenance are omitted.

### Added
- Quit Protection guards Command Q and Command W with a hold, double press or extra modifier, configurable per app. Thanks to @RuanMD and @PathGao.
- Window Layout offers eight-direction pointer placement, adjustable gaps, selectable snap areas and centered half-width windows. Thanks to @Bald-M, @marcelharinck, @levelupimprovement and @Borisserz.
- Drag Dock previews to move windows, including minimized windows and windows on other desktops. Thanks to @PathGao.
- Dock Preview and App Switcher offer minimal previews; middle-clicking a card closes its window.
- Dock Preview can quit an app from its close button, with an adjustable opening delay. Thanks to @arefshal and @PathGao.
- App Switcher offers screen selection, appearance delay and minimized or fullscreen window visibility options. Thanks to @noahjstewart, @yasinozmeen and @itsofirk.
- Recording tools add timed blur, picture overlays with nine positions, and filmstrip scrubbing with drag-to-cut selection. Thanks to @saminton.
- Video and GIF compression can target a file size you choose. Thanks to @FlowSync0.
- Capture tools offer separate shortcuts, optional mode menus, adjustable magnification and precise keyboard pixel selection. Thanks to @wiidede, @PathGao, @RecoilGaming, @EugeneCarldotme and @ruvelro.
- Recent captures can open directly with a shortcut; recognized text can be joined into one paragraph. Thanks to @ywu73.
- Keep Awake can run for selected apps and pause while the Mac is locked. Thanks to @Borisserz and @Advaith3600.
- Bluetooth on sleep disconnects sleeping Macs from accessories and restores Bluetooth on wake only if it turned it off. Thanks to @marcfusch.
- Mouse controls add acceleration disabling, worn-button click filtering and button-drag gestures for desktops and window overviews. Thanks to @CrowKiller and @iltonandrew.
- Super key supports right-side modifiers, input-source switching and exceptions for selected apps. Thanks to @JoanLaRosa, @BenjaminD2023 and @Borisserz.
- Keyboard shortcuts can adjust keyboard backlight brightness one step at a time. Thanks to @EugeneCarldotme.
- App shortcuts, aliases and pinned favorites have one searchable management page.
- Command Bar adds compact mode, argument-free script shortcuts and an app restart command. Thanks to @kobebrylant, @rhukster and @CSkjolden.
- Radial Menu adds custom profiles, themes, triggers, an interactive editor and a Now Playing card. Thanks to @ruvelro and @PathGao.
- Clipboard history supports 10,000 items or unlimited retention, multiple-item deletion and clearing unpinned items with confirmation. Thanks to @ElPotara and @CSkjolden.
- Text snippets offer a visual date and time builder with timezones and live previews. Thanks to @tenbux.
- Shelf adds file sharing, media thumbnails and optional clearing on close. Thanks to @tenbux and @bilalnoork.
- Kill Process can find, restart or end processes and their children, with confirmation before ending them. Thanks to @naveenkrdy.
- Battery temperature alerts, disk ejection exceptions and a visible-screen Cleaning Mode offer more control. Thanks to @ywu73 and @PathGao.
- Liquid Glass effects can be switched off on macOS 26 and later; the app icon supports system appearance styles. Thanks to @divisionseven.

### Changed
- Fan Control adds continuous manual speeds and editable temperature curves, with current and target fan speeds on supported Macs.
- Power brings battery charge, health, history, temperature, accessories and energy-consuming apps together; System adds compressed memory and cached files.
- App Updates checks publisher feeds and a public catalog, preserves partial results and identifies apps that could not be fully checked.
- Uninstaller and Cleaner find more verified leftovers and clearly identify files they could not remove. Thanks to @PathGao.
- Clean URL offers editable site-specific tracking rules and shows what it removed. Thanks to @PathGao.
- Sound Mixer groups devices, can hide inactive apps and offers finer keyboard volume steps. Thanks to @ruvelro.
- Command Bar remembers choices, tolerates short typos and expands emoji search; Settings search opens matching sections. Thanks to @MaximilianMauroner and @pergioa.
- Window Layout maximizes at the top edge and moves windows between displays when left or right shortcuts repeat.
- Smooth scrolling offers adjustable speed and response across standard and high-refresh displays.
- Window switching, Dock previews, recording effects, cleaning and file organization avoid repeated work. Thanks to @PathGao.
- Quit on close avoids elevated CPU use in watched apps. Thanks to @iltonandrew.
- Clipboard and Shelf show richer image previews; Shelf waits briefly before expanding during a drag.
- Personal clipboard content, Shelf files, recordings and share records use private storage. Thanks to @ThomasWaldmann.
- Scratchpad notes use private storage, stay out of settings backups and preserve unreadable originals. Thanks to @CSkjolden.
- Settings backups preserve local exceptions without exporting machine-specific paths. Thanks to @iltonandrew.
- Disk image installation shows progress and offers to remove the download after installing.

### Fixed
- Typing and shortcuts stay responsive while App Switcher collects windows from slow apps. Thanks to @MaximilianMauroner.
- Clipboard operations no longer freeze Command Bar or quick tools when copied content stalls. Thanks to @PathGao and @atomsbaza.
- Clicks and scrolling stay responsive with mouse controls enabled; focus follows mouse respects held keys, buttons and excluded apps. Thanks to @khichinho.
- Input features step aside during account switching and recover afterward. Thanks to @PathGao and @iltonandrew.
- App Switcher handles more window types, restores native shortcuts after crashes and keeps reverse switching reliable. Thanks to @PathGao, @BenjaminD2023, @owendaw and @justin-chiam.
- App Switcher and Dock previews discard closed windows and show alternate icons consistently. Thanks to @atomsbaza, @iltonandrew, @EugeneCarldotme and @hash00.
- Dock actions bring restored windows forward, stay on the current desktop and respect fullscreen apps. Thanks to @pboucher, @PathGao and @iltonandrew.
- Quit on close detects windows created late; moving windows between displays preserves their size. Thanks to @iltonandrew and @DiogoDuart3.
- Super key preserves held modifiers, restores its source key after crashes and sends Escape correctly. Thanks to @victoraraujo01, @gatzifratzi, @PathGao and @hash00.
- Shortcut recording respects keyboard layouts, detects conflicts and accepts native switcher combinations. Thanks to @PathGao, @alexis-morain, @arsarsars1, @jtprogru and @owendaw.
- Clipboard and snippet searches support input-method composition; multiline snippets preserve every line and rich clipboard content. Thanks to @PathGao and @fermincasagrande.
- Clipboard keyboard navigation stays stable, large previews remain responsive and stored history stays readable. Thanks to @andreisuslov and @naveenkrdy.
- Shelf preserves saved items when its list cannot be fully read. Thanks to @PathGao.
- Capture history preserves images when its list cannot be read or saved.
- Recording saves preserve existing files if export fails or is canceled, and reject incomplete edits or damaged pointer data.
- Recordings avoid doubled mixer audio; stopping while typing no longer risks a crash. Thanks to @PathGao.
- Recording trim handles work from the start; other capture shortcuts leave active recordings alone. Thanks to @lmilojevicc.
- Window captures include dialogs and cross-display windows; scrolling captures avoid repeated footers. Thanks to @iltonandrew.
- Screenshot editing uses full-resolution copied images, and quick previews leave keyboard focus alone. Thanks to @iltonandrew.
- Capture guides stay readable and color picking matches the sampled pixel. Thanks to @nik-2002, @I-Have-No-Idea-What-Im-Doing-Right-Now, @PathGao and @MaksimEgorov.
- Temporary capture links stop appearing available after expiring during sleep. Thanks to @PathGao.
- Sound Mixer recognizes helper audio and prevents stale-audio stutters. Thanks to @PathGao.
- Display controls avoid freezes and restore brightness to the correct monitor after reconnection. Thanks to @ozimosko, @bayujo, @PathGao and @iltonandrew.
- Network readings recover without false spikes; speed tests report server errors and Wi-Fi commands stay responsive. Thanks to @mugurc.
- Memory, processor temperature and per-app resource readings are more accurate. Thanks to @pergioa and @PathGao.
- App installation opens the installed copy; stalled package jobs no longer freeze controls. Thanks to @PathGao.
- Automatic cleaning leaves protected files alone and reports failures; uninstalling restores closed-lid sleep. Thanks to @PathGao and @mugurc.
- Cut files can move into protected folders with system approval; cancellation preserves unfinished moves. Thanks to @aesophor.
- Mouse acceleration settings survive reconnection, and app exceptions recognize more running programs. Thanks to @iltonandrew.
- Keep Awake handles rapid closed-lid changes and more account names. Thanks to @Tr1meputiNe, @iltonandrew and @dhruvsaxena1998.
- Scratchpad reports save failures; Settings and floating panels keep usable sizes and readable controls. Thanks to @AB-boi and @PathGao.
- Light-mode selection, regional numbers, search and translations are clearer across supported languages. Thanks to @PathGao and @watain666.
- Restarting reliably reopens the app, and login settings explain when automatic startup is disabled. Thanks to @PathGao and @wenujacodes.

## [3.3.3-beta.4] - 2026-09-03

### Summary
Vorssaint adds protections for Command Q and Command W, a pause on lock option for Keep Awake, pointer and stray click controls for mice, blur in the recording editor, sharing from the Shelf, and new options across capture, clipboard, Super key, App Switcher, Dock Preview and Window Layout. It also makes the Command Bar, App Switcher, Dock Preview, radial menu and cleaning faster, widens app update and leftover discovery, and fixes input, window switching, clipboard, capture, app installation and audio behavior throughout.

### Added
- Optional protections for Command Q and Command W, with a hold, a double press or an extra modifier, per app and following your keyboard layout. Thanks to @RuanMD and @PathGao.
- Keep Awake can pause while the Mac is locked and resume the rest of the session on unlock. Thanks to @Advaith3600.
- The recording editor can blur any area of the picture for as long as you choose, keeping private details unreadable inside zooms.
- The capture magnifier, optionally on by default, shows a pixel grid with the pointer's color, steps a pixel at a time with the arrow keys and copies the color with C. Thanks to @ruvelro.
- Mouse settings can turn off pointer acceleration for connected mice and restore your previous setting when switched off. Thanks to @CrowKiller.
- Mouse settings can filter the rapid extra clicks of a worn primary, secondary or middle button.
- Mouse button shortcuts can switch Spaces or open Mission Control and App Exposé by holding an extra button and dragging. Thanks to @iltonandrew.
- Super key can use Caps Lock or a right side Command, Option, Control or Shift key. Thanks to @JoanLaRosa.
- Text snippets include a visual builder for date and time variables, with formats, timezones and live previews. Thanks to @tenbux.
- Window Layout can keep a preset gap between snapped windows and the screen edge. Thanks to @marcelharinck.
- The App Switcher can open on the screen under the pointer, the one with the menu bar or the one with the active window. Thanks to @noahjstewart.
- The App Switcher appearance delay is adjustable from 0 to 500 ms. Thanks to @yasinozmeen.
- Dock Preview can quit an app from a thumbnail's × button instead of closing only that window. Thanks to @arefshal.
- Clipboard history can delete a multiple selection at once, with Command Delete and Option Delete. Thanks to @ElPotara.
- Clipboard history can clear all unpinned items from the Command Bar after a confirmation. Thanks to @CSkjolden.
- Clipboard history offers retention limits of 10,000 items and unlimited storage.
- Shelf can clear every item when you use its close button, while hiding and collapsing keep them. Thanks to @bilalnoork.
- Shelf can share its files with any app or person the Mac offers, from a button in its footer or the right-click menu.
- Copy Text from Screen can join recognized lines into a single paragraph with script aware spacing. Thanks to @ywu73.
- Cleaning Mode can keep the screen visible with a discreet corner indicator instead of blacking it out.
- Eject all disks can leave chosen drives mounted, so backup and permanent storage stay connected. Thanks to @PathGao.
- The disk image installer shows progress while it copies and verifies an app, then offers to trash the download and reveal the app, remembering both answers.
- The Command Bar can restart Vorssaint. Thanks to @CSkjolden.
- Radial menu settings include an interactive wheel preview that lets you drag to swap actions, click to configure, and navigate submenus.

### Changed
- Dragging a window to the top edge of the screen now maximizes it, and the update highlights tour covers Window Layout, Quit Protection, and recording blur.
- Smooth scrolling feels consistent on standard and high-refresh displays, with adjustable speed and response and no lost wheel distance.
- The recording editor's filmstrip scrubs as you drag across it. Hold Shift to pick a stretch to cut out, and cut stretches go dark. Thanks to @saminton.
- Settings search and the Command Bar group results under their main page, navigate with arrow keys and deep link to exact sections. Thanks to @pergioa.
- App Updates finds newer versions through a privacy preserving public catalog and opens each app so its own updater stays in control.
- The Uninstaller finds more support files, containers, preference panes and plugins through verified identifiers and signed ownership, and opens every result in Finder. Name related finds start unchecked.
- Cleaner leftover scans cover more preference panes and plugin folders while refusing nested app data, version folders, links and other ambiguous paths.
- Repeating the left or right Window Layout shortcut carries the window to the display on that side, landing on the half it came in through.
- The docked shelf needs a brief hover over its collapsed pill before expanding, so fast drags across the menu bar no longer open it.
- The disk space readout shows available and physical used space, with purgeable capacity when present.
- Process breakdowns normalize per app CPU against active cores and cap grouped GPU and energy at 100%. Thanks to @pergioa.
- The menu panel's Settings button opens the page of whichever utility is on screen. Thanks to @andreisuslov.
- The screenshot editor drag out handle uses a dedicated icon instead of a preview thumbnail. Thanks to @Yahddyyp.
- Simplified Chinese terminology now matches native macOS wording for copying, saving, app names and confirmations. Thanks to @PathGao.
- The Command Bar prepares its rows once while opening and reads battery and memory in the background, so typing stays responsive. Thanks to @PathGao.
- Dock Preview does less work on every mouse move. Thanks to @PathGao.
- Window Layout shortcuts find the app owning the focused window directly instead of scanning every running app. Thanks to @PathGao.
- Long recordings prepare pointer and zoom effects more efficiently before preview and export. Thanks to @PathGao.
- Minimizing a window right after switching to it stops reading window state once the previous app is back, so the keyboard stays responsive. Thanks to @PathGao.
- Window controls, Dock clicks and mouse exceptions share the same on screen window parsing. Thanks to @PathGao.
- Quit on close reads an app's windows once per switch, so apps with many windows cost less to leave. Thanks to @PathGao.
- The App Switcher and window previews skip Accessibility calls for windows they already collected. Thanks to @PathGao.
- Ending a process tree reads the running process list once instead of looking up children one by one. Thanks to @PathGao.
- The downloads organizer checks whether a file stays on the same disk before filing it and skips a second integrity read on a rename. Thanks to @PathGao.
- Cleaning checks which apps are still installed once per run, and not at all when no leftover is selected. Thanks to @PathGao.
- GPU sampling no longer leaves a system resource behind on Macs with more than one graphics processor, and extra brightness does less work per refresh. Thanks to @PathGao.
- The radial menu checks only which extra button opens a wheel, instead of loading every wheel and icon on each event. Thanks to @PathGao.

### Fixed
- An app installed from a disk image now opens from Applications instead of a hidden read-only copy, so large apps start correctly.
- Stopping a recording while you type no longer risks a crash or misplaced typing moments. Thanks to @PathGao.
- Screen recordings capture the Mac's sound once, so apps turned down in the Volume Mixer no longer come back doubled.
- Adding points to a custom cooling curve keeps every sensor and saves without crashing.
- Paste as plain text no longer freezes when the app you copied from is slow to hand the content over. Thanks to @PathGao.
- A Homebrew job that stops responding no longer freezes the panel, while a slow download or build is still allowed to finish. Thanks to @PathGao.
- Keyboard, mouse and media key features step aside during fast user switching, so the active account no longer stalls. Thanks to @PathGao.
- Mouse navigation, button shortcuts and middle click step aside outside the active login session or once Accessibility access is removed.
- Smooth Scroll and Scroll Inverter step aside during fast user switching and resume on return. Thanks to @iltonandrew.
- The radial menu releases its mouse tap and closes any open wheel when accounts switch, so extra button clicks no longer stall. Thanks to @PathGao.
- Cleaning Mode ends when its login session leaves the screen, so its input lock never reaches another user.
- Turning features on and off repeatedly no longer leaves unused keyboard and mouse listeners behind. Thanks to @PathGao.
- Automatic cleaning leaves protected items in place instead of asking for a password while unattended, and reports what it could not move. Thanks to @PathGao.
- Uninstalling verifies that sleep was restored and asks for authorization if it was not, so the Mac never keeps sleeping disabled with the lid closed. Thanks to @mugurc.
- Uninstaller and Cleaner scans accept two part bundle identifiers, so apps with short domain names can be cleaned.
- Uninstalling a feature removes it from Command Bar pins.
- Update, uninstall, migration and relaunch helpers run detached, so they finish even when the app is being closed. Thanks to @PathGao.
- Local builds verify their signing identity and unlock its keychain first, so a rebuild no longer loses system permissions. Thanks to @PathGao.
- The permission guide can start over when an entry from an earlier build is stuck in System Settings, and offers a relaunch once Screen Recording is granted. Thanks to @andreisuslov.
- The App Switcher, Dock icon restore and the process list bring the chosen app to the front instead of behind the one you were using. Thanks to @pboucher and @PathGao.
- The App Switcher lists windows in the background, so shortcuts and typing stay responsive when apps answer slowly. Thanks to @MaximilianMauroner.
- The App Switcher lists windows from apps that draw their own title bar or use borderless windows. Thanks to @PathGao.
- The App Switcher recognizes floating and undescribed workspace windows from professional media apps.
- The App Switcher rejects stale hidden Space surfaces without hiding real fullscreen windows elsewhere. Thanks to @naveenkrdy.
- The App Switcher can take over the matching macOS switcher shortcuts, with crash recovery and a fallback for apps without windows. Thanks to @BenjaminD2023.
- Middle clicking the App Switcher closes only the card under the pointer.
- Adaptive app icons no longer flicker their light artwork while you navigate the App Switcher in dark mode. Thanks to @EugeneCarldotme.
- Dock icon window cycling stays on the active Space instead of switching desktops. Thanks to @PathGao.
- Dock click actions and previews stay behind fullscreen content and handle high rate pointer movement without overloading. Thanks to @iltonandrew.
- Dock previews follow the screen edge when an auto-hiding Dock slides away instead of floating detached. Thanks to @iltonandrew.
- Quit on close now sees windows an app creates after launch, so apps that load their windows late still quit with their last window.
- Quit on close retries when Accessibility first reports no windows, so apps still quit with their last window. Thanks to @iltonandrew.
- Moving a window to another display keeps its size and edge insets instead of scaling. Thanks to @DiogoDuart3.
- Focus follows mouse leaves chosen apps alone and waits for every held button to be released before changing focus. Thanks to @khichinho.
- Accessibility messaging uses one shared timeout floor instead of letting each feature overwrite it. Thanks to @PathGao.
- Super key keeps its modifiers active while you hold a key that does not autorepeat, such as Caps Lock remapped to F18. Thanks to @victoraraujo01.
- Super key restores its source key when the app is force quit, so Caps Lock or a right side modifier is never left inactive.
- Shortcut fields and key displays follow the active keyboard layout and resolve physical keycaps under input methods, so they show the keys you actually pressed. Thanks to @PathGao.
- The Command Bar search field supports Select All, Copy, Cut and Paste, and its shortcuts follow alternate keyboard layouts. Thanks to @alexis-morain and @PathGao.
- The Command Bar capture card records Command Q instead of ignoring it. Thanks to @arsarsars1 and @jtprogru.
- Clipboard and snippet search fields yield to input method composition, so candidates can be navigated and confirmed in Chinese, Japanese and Korean. Thanks to @PathGao.
- Arrow keys in clipboard history no longer fight a hovering pointer, and large previews render without pauses. Thanks to @andreisuslov.
- Escape in the clipboard quick panel clears a selection or closes the panel instead of closing the preview first. Thanks to @naveenkrdy.
- Long clipboard previews in the menu panel stay inside their row instead of overflowing onto neighbors. Thanks to @andreisuslov.
- Clipboard history trims against the encoded file size before saving, so its store stays readable.
- Multi-line snippets paste every line in order, keep rich clipboard content and stay out of history. Thanks to @fermincasagrande.
- Text snippets keep their trigger buffer when typed on the Accessibility Keyboard. Thanks to @fermincasagrande.
- The docked shelf keeps its saved items and files when its list cannot be read completely, instead of clearing them. Thanks to @PathGao.
- Window capture includes sheets, alerts and dialogs stacked on a window, even partly off screen, and still captures windows that cross displays. Thanks to @iltonandrew.
- The screen capture selector keeps its guides, palette and hints readable over bright and mixed backgrounds. Thanks to @nik-2002.
- Switching capture modes keeps the selector stable and refreshes the source only when the new tool needs it.
- Screenshot quick preview no longer steals keyboard focus, so keystrokes stay in the active app until you click it. Thanks to @iltonandrew.
- The screenshot editor holds its minimum size, so the canvas and tools no longer compress into a narrow strip. Thanks to @iltonandrew.
- Temporary screenshot and recording links no longer stay listed as available after expiring while the Mac sleeps. Thanks to @PathGao.
- Volume Mixer attributes detached helper audio to its parent app, so browsers and sandboxed communication apps stay controllable.
- Volume Mixer silences unwritten frames so stale audio no longer stutters, and bounds cleanup so a stalled teardown cannot block other apps. Thanks to @PathGao.
- Music launch blocking fails open when its media key listener is unavailable.
- The radial menu's Now Playing card finds the playing track again on macOS 15.4 and later. Thanks to @PathGao.
- Radial Menu settings explain that its mouse trigger needs an extra button, and that trackpads without one use the keyboard shortcut. Thanks to @PathGao.
- Radial Menu icon downloads stay on the link's own origin and reject redirects, oversized payloads and unsafe dimensions.
- The Homebrew panel refreshes after a partly finished run, so one skipped package no longer leaves stale versions and updates on screen. Thanks to @PathGao.
- Restoring screen gamma checks the display's identity, so a dimmed curve no longer lands on another monitor after a reconnection. Thanks to @PathGao.
- CPU temperature and cooling curves use only mapped processor sensors, read M3 cores and tell an unavailable helper from unsupported hardware.
- Kill Process revalidates the exact process before ending it, so a recycled identifier never targets another one.
- Settings holds its minimum size through resizing and restore, so the sidebar and preferences no longer compress or clip.
- Scratchpad windows drag from anywhere in the top bar, keep generous resize borders and a minimum size, and each tab has a close button.
- Text heavy floating panels stay readable over bright windows when Liquid Glass is on.
- The menu bar battery icon keeps its shape when split into its own item. Thanks to @Yahddyyp.
- Cleaning Mode gives the Escape unlock gesture a 6 second window and resets the count when modifiers are pressed. Thanks to @iltonandrew.
- Mouse exceptions match plain executables and Java runtimes alongside regular apps. Thanks to @iltonandrew.
- Settings backups leave machine local paths out of the file and keep local exceptions across a restore. Thanks to @iltonandrew.
- Screen recording settings in Traditional Chinese for Taiwan use the standard microphone term 麥克風. Thanks to @watain666.
- The What's New video stops a download that never ends and releases it as soon as the window closes. Thanks to @PathGao.
- Feedback reports show readable beta and update channel diagnostics.
## [3.3.3-beta.3] - 2026-08-26

### Added
- General settings now include a Liquid Glass toggle on macOS 26 and later to control translucent glass visual effects across panels and controls.
- The video and GIF tools now include an option to compress directly to a target file size in megabytes, automatically deriving the resolution and frame rate to stay under the limit. Thanks to @FlowSync0.
- Shelf now shows real content thumbnails for dropped images and videos, covering more file types, and decodes saved image thumbnails asynchronously on launch. Thanks to @tenbux.
- The Command Bar now offers a compact mode where the bar opens as a field alone and shows results once you type, with Down arrow revealing the full list. Under Command Bar, off by default. Thanks to @kobebrylant.
- Command Bar script links can now be marked to run on their bare name without an argument, so scripts that work on the clipboard, selection, or files don't need a placeholder word typed after the name. Under Command Bar, off by default. Thanks to @rhukster.
- Monitor alerts can now warn you when the battery stays above a temperature you choose. Under Monitor alerts, off by default. Thanks to @ywu73.
- Radial Menu now supports custom profiles with distinct wheel layouts, color themes, shortcuts, mouse triggers and starter presets, and website links can fetch their actual website icons on demand.

### Changed
- Homebrew package rows can now be selected by clicking the unused space beside the name. Thanks to @pergioa.
- Clipboard history now displays image previews and thumbnails for image files copied from Finder in the quick panel, preview inspector and menu panel.
- Clipboard history now remembers whether you left the preview inspector open or closed across launches.
- New Scratchpad tabs now start at 1 instead of leaving the first tab unnumbered, while existing names stay unchanged. Thanks to @AB-boi and @JashRashne.
- Every screen capture tool now carries its own keyboard shortcut to open directly into screenshot, recording, text copy or color picking, with the active tool shortcut edited at the top of the Screen capture settings page. Thanks to @RecoilGaming.
- The Keyboard Shortcuts page now lists every capture shortcut under one Screen capture group, and expandable shortcut groups are toggled by their whole row, with the chevron moved to the trailing edge. Thanks to @RecoilGaming.

### Fixed
- Fan Control now updates manual and curve cooling speeds during an active session without verification timeouts.
- The Homebrew panel now closes when you click outside it while browsing or searching, and stays open for a confirmation or a running job. Thanks to @pergioa.
- Settings opened from the menu panel no longer stay covered when the two windows cannot fit side by side. Thanks to @FloatingPegasus.
- Muting the microphone from Quick toggles no longer moves the menu panel. Thanks to @FloatingPegasus.
- Fan Control can no longer be installed on a Mac with no controllable fan, including from Install all and first-run setup. Thanks to @PathGao and @Yahddyyp.
- Quit on close no longer causes elevated background CPU usage in watched applications. Thanks to @iltonandrew.
- The Displays section no longer freezes when switching off the built-in display while an external monitor is connected. Thanks to @iltonandrew.
- Subprocess sampling and window enumeration no longer exhaust background dispatch threads or deadlock the main thread. Thanks to @PathGao, @iltonandrew and @SudhanshuBhogal.
- Quick tool confirmation panels and scrolling capture banners now keep long copied text or parameter lists bounded on screen instead of overflowing the display. Thanks to @rhukster.
- App Switcher now keeps walking backwards when you hold Shift and tap Tab again. Thanks to @iltonandrew and @justin-chiam.
- The window-scoped App Switcher (⌘`) no longer collapses into a single tile when one entry per app is enabled. Thanks to @iltonandrew, @AB-boi and @PathGao.
- The screen capture loupe now rings the pixel under the pointer instead of drawing a crosshair across it, and that pixel sits in the middle of the loupe, so the Color picker shows the color it is about to copy. Thanks to @I-Have-No-Idea-What-Im-Doing-Right-Now and @PathGao.
- Screenshot editor crop now snaps selection and resize edges to pixel boundaries, keeping the loupe cross and the final cut aligned to the exact source pixel. Thanks to @PathGao.
- Media settings now keep the title and tool picker in place when More options expands, and matching disclosure rows across Settings toggle from the full label. Thanks to @ruvelro.
- Saved image profiles now restore max-side values up to 20,000 pixels without silently shrinking them. Thanks to @ruvelro.
- Menu bar icon recovery no longer overlaps or hides the item under macOS system items like the battery icon.
- Command Bar and quick tools no longer freeze when copying, opening links, or expanding snippets while the clipboard holds stalled content. Thanks to @PathGao and @atomsbaza.
- Keep going with lid closed no longer fails to set up on accounts whose username contains @ or other non-alphanumeric characters, granting the rule by user ID instead. Thanks to @iltonandrew and @dhruvsaxena1998.
- Uninstallation via script or inside the app now fully clears the Fan Control helper daemon registration, stored application data, caches and ByHost preferences. Thanks to @mugurc.
- The menu bar panel keeps its arrow under the icon when the bar hides itself and the panel content changes height. Thanks to @pergioa.
- Homebrew formulas installed from another tap now show their update on the row. Thanks to @pergioa.
- Super key now shows why it could not remap Caps Lock, instead of staying on with a key that still only toggles capitals. Thanks to @PathGao.
- Holding Super key now also moves and resizes windows by dragging. Thanks to @iltonandrew and @felixblaschke.
- Shelf drop zone and menu bar icon hit testing no longer use off-screen coordinates when the menu bar is hidden in full screen. Thanks to @iltonandrew.
- Settings backup import now coordinates file reading for cloud files and accepts XML backup files.

## [3.3.3-beta.2] - 2026-08-22

### Added
- The app icon has been redesigned and now supports adaptive system appearance modes for light, dark, tinted, or clear icon styles on macOS 26 and later, while macOS 14 and 15 keep the classic icon. Thanks to @divisionseven.
- A new Bluetooth on sleep feature switches Bluetooth off while the Mac sleeps, so a closed laptop stops connecting to headphones it should leave alone. Bluetooth that was already off before sleep stays off, and only what Vorssaint switched off is put back on wake. Thanks to @marcfusch.
- App Switcher now lets you place minimized windows at the end of the list or hide them, and toggle fullscreen window visibility. Thanks to @itsofirk.
- The radial menu now includes a Now Playing media action with a floating track card and direct app access. Thanks to @ruvelro.
- The radial menu editor now includes a broader built-in SF Symbol catalog with runtime availability filtering. Thanks to @ruvelro.
- Sound Mixer now includes an option to hide inactive applications while keeping custom volume and output selections visible. Thanks to @ruvelro.
- Sound Mixer now includes an option to use finer volume steps with keyboard volume keys and rollers. Thanks to @ruvelro.
- Finder Cut & Paste now includes an option in Settings to show or hide the floating panel for staged files, and automatically hides the panel when Finder is in the background.

### Changed
- Command Bar settings no longer put a command key glyph in front of "Open the bar now", read as one paragraph rather than four separate cards, and name what the shortcut opens. Thanks to @PathGao.
- Sound Mixer panel now groups audio devices and organizes preferences in a collapsible Options section.
- Embedded utilities in the Quick Launcher now provide distinct Back and Close buttons. Thanks to @ruvelro.

### Fixed
- System metrics now accurately report used memory by including hardware-reserved tagged memory on supported hardware. Thanks to @pergioa and @PathGao.
- App Switcher now steps one icon at a time when hovering the edge of an overflowing icon row instead of scrolling continuously. Thanks to @BenjaminD2023.
- App Switcher now scales windowless app icons and labels proportionally when preview size is set to small. Thanks to @Yahddyyp.
- Screenshot editor now opens the full-resolution image when editing a file copied in Finder instead of its preview icon. Thanks to @iltonandrew.
- App Switcher now shows an application's user-selected alternate icon instead of the default bundled icon. Thanks to @iltonandrew and @EugeneCarldotme.
- App Switcher and Dock previews no longer show stale previews for windows that were closed or apps that quit. Thanks to @atomsbaza.
- Beta releases now automatically turn on the beta update channel on first launch, ensuring seamless delivery of subsequent beta updates.
- Keep Awake now preserves the order of asynchronous closed-lid sleep requests when rapidly toggled. Thanks to @Tr1meputiNe.
- The Uninstaller now names the items a removal could not move, and offers Full Disk Access on the spot when that permission is what stopped it. Sandboxed app data used to be left behind under a success tick. Thanks to @PathGao.
- Rebuilding the display list after a hotplug, a wake or opening the panel no
  longer reads the screen names from a background thread. The names the sliders
  carry are unchanged. Thanks to @PathGao.
- App Switcher now sizes its window and icon rows from a single shared width, preventing clipping when fewer than three apps are open. Thanks to @iltonandrew.
- Opening Energy settings or the brightness panel no longer dims displays that were already at that brightness. Thanks to @iltonandrew.
- Opening a Shelf tile's context menu now hides its hover tooltip, preventing the tooltip from covering menu items. Thanks to @tenbux.

## [3.3.3-beta.1] - 2026-08-22

### Summary
Vorssaint 3.3.3-beta.1 introduces the opt-in beta release channel and in-app feedback diagnostics alongside full manual and temperature-based Fan Control, directional pointer window layout, an opt-in Kill Process tool and native input-source switching for the Super key and drag-to-place Dock previews. It keeps grouped and windowless App Switcher labels clear, splits App Switcher rows evenly when they wrap, makes Scratchpad controls easier to click, keeps fixed page footers from repeating in scrolling screenshots, restores reliable trimming from the start of a recording, makes administrator approval for updates originate from Vorssaint, keeps messaging app cleanup in Cleaner hidden until you turn it on, keeps Separate metrics in Settings instead of the menu bar panel, lets you open Music yourself while the media-key blocker is on, and shows compressed memory and cached files in the System panel.

### Added
- Window Layout now offers an opt-in Shortcut + pointer layout mode that places the active window toward
  any of eight directions with a native glass-ring HUD. Thanks to @Bald-M.
- The Super key can now use a quick press to switch between enabled input sources
  while a press-and-hold toggles Caps Lock. Thanks to @BenjaminD2023.
- Dock Preview thumbnails can now be dragged to move any window to where they are
  dropped, keeping the size it already had. A minimized window is restored there
  and a window from another desktop is carried across. Thanks to @PathGao.
- Clean URL now removes the tracking parameters that YouTube, X, Instagram, Spotify,
  Reddit, TikTok, Bilibili and Xiaohongshu add to their own share links, while leaving
  the same parameter names alone on every other site. Thanks to @PathGao.
- Clean URL now lists every rule it applies in Settings, where any name can be switched off
  and names of your own can be added to one site or to every site. A whole site's rules can
  be turned off at once, and the list says what the names are for. Cleaning now also names
  the parameters it removed. Thanks to @PathGao.

- The Clean URL switch now says when it acts: it cleans a link as it reaches the
  clipboard, rather than reading as a name for the page it sits on.
- An opt-in Kill Process feature searches running processes to force quit, restart or terminate
  process trees from Settings and the Command Bar. It ships uninstalled. Thanks to @naveenkrdy.
- The System panel now shows compressed memory and cached files next to swap.
- Middle-clicking a window card in the App Switcher now closes that window directly.
- Settings now lets you opt in to receive beta and pre-release updates alongside stable versions.

### Changed
- The App Switcher now splits windows evenly across rows when they wrap, so a
  leftover pair no longer stretches the panel to a full first row. Thanks to @kzenmatthias.
- Separate metrics into their own items now lives only in Settings › Monitor,
  not in the menu bar panel.
- Fan Control now offers System, continuous Manual control from 0% to 100% and
  editable temperature curves with multiple SoC, CPU and GPU rules. It also shows
  current and target RPM for every fan.
- The Cleaner's messaging app downloads tools stay hidden until you turn them on
  in Cleaner. Setups that already use that cleanup keep it.

- Clicking a Dock icon now only restores the windows that Click Dock icon to minimize
  put away. Windows minimized any other way keep the Dock's own restore. Thanks to @PathGao.

- A Dock Preview now opens after 200 ms of rest on an icon instead of 400 ms, and
  Settings carries that wait as an adjustable Open delay. Handing an open preview to
  the next icon takes 100 ms instead of 250 ms. Thanks to @PathGao.

### Fixed
- Super key input-source switching no longer waits on Accessibility marked text
  or a pause after every tap, so a language change takes effect before the next
  keystroke. Thanks to @BenjaminD2023.
- Scrolling screenshots now keep fixed page footers once at the end instead of
  repeating them after every scroll.
- Settings now lists Dock Preview and Dock click as separate named sections, and
  opening Dock click from the Features hub lands on its own controls rather than on
  the Dock Preview block. Thanks to @PathGao.
- Scratchpad tabs and the pin, close, new pad and pad actions buttons now respond
  across their whole area. Thanks to @AB-boi and @PathGao.
- The Scratchpad tab strip now takes the width its row has free, so widening the
  pad shows more of each tab name instead of leaving the space beside the pad
  actions button empty. Thanks to @AB-boi.
- Dock Preview cards now carry the App Switcher's look: the app's icon and the window's
  state along the bottom of a 16:10 picture, the name and its subtitle underneath, and the
  close and minimize buttons in that band rather than over the picture. Thanks to @PathGao.

- Dock Preview cards keep a full title band at every preview size rather than scaling it
  with the card, and the app icon standing in for a thumbnail that has not arrived follows
  the preview size as a watermark. Thanks to @PathGao.

- A Dock Preview beside a Dock on the left or right now runs its cards down the screen
  instead of across it, a hovered panel draws no header, and pinning one is a named item
  in a card's menu. Thanks to @PathGao.

- A window name too long for its band now scrolls while the pointer is on that card, in
  the App Switcher as well as a Dock Preview. Thanks to @PathGao.
- Fan Control now prepares stopped fans before taking manual control and keeps a
  failed attempt visible instead of silently returning to Automatic.
- The Clean URL settings fields now take a click anywhere across their row. Their
  hint used to render as a row label beside a short strip of field, so clicking the
  words did nothing. The parameter list also gained a Save button and shows the
  names as the cleaner reads them, instead of applying each keystroke as it is
  typed. Thanks to @PathGao.
- The grouped simple App Switcher now keeps every window title fully visible and lets
  the window shortcut reach each window, even when showing one entry per app.
- Windowless apps no longer repeat or misplace their name in the App Switcher's Small
  size. Thanks to @Yahddyyp.
- App Switcher grid cards now give their thumbnail the 14 points their chrome
  was reserving and not using, and their title band holds a subtitle without
  clipping its descenders. Thanks to @PathGao.
- Clicking the Dock icon of a background app to restore its minimized windows now
  brings that app forward, instead of leaving its windows behind whichever app was
  already in front. Thanks to @PathGao.
- The recording editor now trims reliably from the beginning of a video when
  dragging the left handle. Thanks to @lmilojevicc.

- A test run no longer leaves a preference file behind in `~/Library/Preferences`
  for every defaults suite it uses. Thanks to @PathGao.
- Screen recorder, Copy text from screen and Color picker can each take a shortcut
  of their own again, opening screen capture already on that mode. Their Settings
  rows no longer record a combination that does nothing. Thanks to @wiidede and
  @PathGao.
- App Switcher window preview warm-up no longer crashes right after startup when
  the system returns duplicate window identifiers. Thanks to @james-rose.
- Clipboard history, its copied images, shelf files, recordings and temporary share
  records are now stored so only your own account can read them. Folders an earlier
  version left readable by other accounts on the Mac are corrected on the next
  write. Thanks to @ThomasWaldmann.
- Administrator approval for updates now originates from Vorssaint instead of a
  system script. Thanks to @dbhorst.
- Switching a display back on from Displays no longer freezes the app. The
  change is now made on the main thread, where macOS expects it, instead of on
  the queue that also carries monitor probing, and the record of which displays
  are off is written with that queue's lock released. Thanks to @ozimosko and
  @bayujo.
- Stopping Music from opening on its own no longer blocks opening it from the
  Dock, Spotlight or Applications. Media keys still cannot launch it.
- The recording editor now reads composition duration directly without background
  queries. Thanks to @Bald-M.
- Launch at login now names System Settings › General › Login Items & Extensions
  when the login item is registered but switched off there, instead of springing
  back with nothing said. Thanks to @PathGao and @wenujacodes.

## [3.3.2] - 2026-08-20

### Summary
Vorssaint 3.3.2 brings one place for screen capture, batch image conversion,
local Command Bar scripts, recent captures, imported video editing, formatted
Scratchpad previews, swap use and window focus that follows the pointer. It also
opens a new Discord community, cuts background energy use and improves
scrolling screenshots, Clipboard, Shelf, Switcher, window controls, audio, displays,
Fan Control, Settings and app maintenance.

### Added
- An optional Focus follows mouse feature brings the window under the pointer to
  the front after an adjustable pause. It ships uninstalled. Thanks to @Bald-M.
- One screen capture shortcut now opens a floating palette for screenshots,
  recordings, screen text and colors, with sound controls and each mode's settings
  kept nearby.
- Media now converts images in batches with resizing, watermarks, renaming and
  reusable profiles. Thanks to @ruvelro.
- Saved Command Bar shortcuts can now run local scripts and show their results as
  you type. Thanks to @tenbux.
- Screenshot and screen recording now open recent captures from the panel, their
  editors and the Command Bar. Thanks to @lmilojevicc.
- Media can now open any video in the recording editor to trim, cut and crop it
  before export.
- Scratchpad can now preview Markdown formatting while every note remains editable
  plain text.
- Command Bar can now search chosen folders, open system settings, reveal saved
  items and assign a direct shortcut to Emoji. Thanks to @ruvelro and
  @MaximilianMauroner.
- The clipboard can now clear itself after a delay, and when the Mac sleeps, the
  display sleeps or the screen locks.
- The quick panel and Radial Menu can now control recording, and the Radial Menu
  can open maintenance tools directly.
- The System panel now shows swap memory in use below the memory reading.
  Thanks to @veniaminMedanov.
- A new Discord community brings help, shared workflows, bug reports, feedback,
  early previews and release news together while the community takes shape.

### Changed
- Monitor settings no longer leave system sensors sampling after the window closes.
  Hidden metric histories and temporary overlays now release work and memory when
  they are no longer visible.
- Clipboard history now opens as a compact palette with uncluttered rows and a
  preview on demand for reading or editing the full item.
- Command Bar now learns result choices for the current session, finds alternate
  and localized app names, supports Control P and Control N, moves by dragging and
  formats feet more naturally. Thanks to @ruvelro, @tingke, @theafox and @tenbux.
- Recording can now pause and resume without gaps, keep an area guide visible and
  start without automatic zooms. Copied screenshots now also work as image files.
  Thanks to @monfxx and @lmilojevicc.
- Shelf now supports range selection, opens from a screen edge, groups compatible
  drops and shows clearer details. Thanks to @cimu233 and @tenbux.
- App Updates now searches more places and offers source controls, while installed
  feature rows lead directly to the relevant Settings controls. Thanks to @ruvelro,
  @PathGao and @dorlugasigal.
- App removal now recognizes when managed apps belong to a package manager. Thanks to
  @MineraleYT.
- Settings now better separates Clipboard controls, explains Full Disk Access and
  keeps inactive or list controls clearer. Thanks to @PathGao.
- The simple App Switcher now cycles individual windows, marks other desktops and
  keeps hidden apps visible. Super key combinations are now customizable.
  Thanks to @AB-boi.
- Menu bar icons now match surrounding items, Volume Mixer accepts exact percentages
  and source builds support older development tools. Thanks to @bambidotexe,
  @KSI-cell and @Bald-M.

### Fixed
- Scrolling screenshots now keep moving content aligned without repeating fixed
  page areas.
- Display controls now keep extra brightness steady, restore the internal display
  after the last external one disconnects and stop retrying unsupported brightness
  checks after wake. Thanks to @stevenyang406, @mayaanhafeez and @danilo-alm.
- Light taps with three fingers no longer trigger a middle click while typing.
- Window tools now center windows with a fixed size, cancel stale placements and handle
  duplicate running processes without quitting the app.
- Capture now supports drawing a fresh crop, preserves translucent window content and
  animates the recording countdown smoothly. Thanks to @lmilojevicc.
- Clipboard keeps large documents, while Shelf refreshes pile counts and controls as
  soon as another item is added. Thanks to @tenbux.
- Command Bar now opens immediately, finds apps outside standard folders and can
  search for keyboard light controls. Screen text recognition now follows the interface
  language. Thanks to @MaximilianMauroner and @PathGao.
- Switcher now survives wake, restores minimized windows, keeps selection aligned,
  reaches Settings, closes windows on other desktops, switches between full screen
  instances across desktops and retains full screen video windows. Its labels now
  follow the saved shortcut without crashing while typing. Thanks to @liuxxxu,
  @AB-boi, @danpalmer and @eioz.
- Quit on close now covers separate guest app windows. Thanks to @danno71.
- Dock Preview focus no longer overwhelms its controls, and Super key works when
  Caps Lock is disabled without leaving it on after a mapping repair.
- Audio boost now smooths loud peaks and Volume Mixer restores sound after a failed
  adjustment. Network, power and accessory battery readings now avoid stale or missing
  values. Thanks to @AB-boi and @subhamayd2.
- Scratchpad resizing, Cleaning Mode display changes and Back and Forward mouse buttons
  now remain stable and responsive. Thanks to @AB-boi, @Polovinkin, @originalspec and
  @jbleuzen.
- App Updates no longer matches store updates to the wrong app, and stale package
  details clear after removal. Thanks to @PathGao and @MineraleYT.
- Setup alignment, configuration from the command line, menu panel focus and initial Fan
  Control approval now behave correctly. Thanks to @danpalmer and @CALLmeDOMIN.
- Fan Control now keeps maximum cooling engaged when the system could reclaim
  automatic mode between control writes. Thanks to @augustoFranke.

## [3.3.1] - 2026-08-09

### Summary
Vorssaint 3.3.1 adds editable recording audio, temporary recording links, one-click app installs,
Fan Control and more configurable window tools. It also improves Settings backups, Keep Awake,
input controls, the menu bar, Switcher, displays, app management, capture, the file shelf and cleaning.

### Added
- Screen recordings can capture Mac sound and microphone separately. Choose them while
  selecting, then adjust or remove each track in the editor.
- Finished recordings can create 1-hour or 6-hour links after local compression to under
  100 MB. Disable under Screen recording.
- A mounted disk image with one app can install it into Applications, eject itself and
  move its download to the Trash. Off by default in Features.
- A configurable shortcut opens a copied image directly in the screenshot editor.
  Under Screenshot, off by default. Thanks to @neon443.
- Window Layout can preview and place a window dragged to any screen edge or corner.
  Off by default.
- Per-app Switcher rules can include apps without windows, keep them window-only,
  or hide them from the Switcher. Under Switcher. Thanks to @Yahddyyp.
- Dock clicks can hide the active app instead of minimizing its windows, off by
  default under Switcher. Thanks to @sidbena.
- Screenshots can include ordinary Vorssaint windows, and recordings can select them
  like other windows, while capture controls stay out. Off by default under Screenshot.
  Thanks to @PathGao.

### Changed
- The App Switcher can hide the shortcut hints below its large icon row.
  Under Switcher.
- Screenshot previews can be dragged directly into folders or other apps as
  full-resolution PNG files.
- Mouse wheel direction can now be inverted separately for vertical and horizontal
  scrolling, including horizontal scrolling with Shift. Thanks to @Jadens-arc.
- Keyboard Shortcuts now groups installed features, shows which shortcuts are active
  and edits them in place, including Super key alternatives.
- App Switcher search can stay open after pressing S, letting you release the shortcut
  while typing. Off by default under Switcher. Thanks to @liuxxxu.
- Dock Preview shows slightly larger thumbnails and gives every window title a clear,
  prominent line beneath its preview.
- Quick toggles can turn the keyboard light on or off from Settings or the menu bar
  panel.
- Simplified Chinese wording now follows system terms and uses native punctuation
  throughout. Thanks to @xueyang-dev.
- Clean URL can remove additional parameter names you choose under its Settings page.
  Thanks to @lmilojevicc.
- Temporary screenshot links can be disabled under Screenshot, removing the sharing
  controls from the preview and editor.
- The radial menu can run Quick toggle actions such as appearance, screen lock
  and hidden files.
- The Command Bar opens a web address typed directly into it. Thanks to @tingke.
- Clipboard history shows each item in full beside the list. Text is selectable and
  editable there. Thanks to @notdanna and @ghostman-git.
- Memory readouts can focus on memory held by apps instead of total memory in use.
  Under Monitor. Thanks to @WazZro.
- Mouse feature exceptions can now choose apps from anywhere on the Mac.
  Thanks to @kyteidev.
- The radial menu can now open from any extra mouse button, not only Back and Forward.
  Thanks to @MineraleYT.
- The optional Fan Control beta shows live fan speed in the panel and menu bar.
  It can cool at maximum for 15 minutes, then returns to automatic control.
- Window Layout can move the active window to the previous display, with an optional
  shortcut. Thanks to @owen-vromans.
- Window Layout can maximize with a 5% margin around the usable screen, with an optional
  shortcut. Thanks to @UnbrokenMango21.
- The screenshot preview can stay near the capture or appear in any screen corner.
  Under Screenshot. Thanks to @lmilojevicc.
- Keep Awake can let displays sleep while the Mac stays awake.
  Under Energy and Options. Thanks to @wenujacodes.
- Keep Awake can optionally toggle with a right click on the menu bar icon.
  Under Energy. Thanks to @yspreen.
- The window shortcut now opens the switcher for the app in front, without
  opening the app list first. Thanks to @mrevanzak.
- The Uninstaller now finds more configuration, cache and helper files owned by
  the selected app. Thanks to @lmilojevicc.
- Scratchpad can keep several named notes in tabs, including their order and
  current selection in Settings backups.
- Clipboard History settings now follow its main switch, while saved items remain
  searchable, reusable and clearable when new capture is off. Thanks to @PathGao.

### Fixed
- The Shelf drop zone now disappears after a drag finishes in another app.
- The menu bar panel now closes when you press Escape.
- The App Switcher can change windows while the screenshot or screen recording editor is open.
- Keyboard input stays responsive in demanding apps when file shortcuts, text
  snippets or Super key are enabled.
- Quick panel is now named consistently in Settings. Thanks to @lgfmartins.
- Newly connected monitors now appear promptly in Displays while their brightness
  controls finish getting ready.
- Quit on close now keeps browser-hosted apps open while their window remains.
  Thanks to @ChaotikTiger.
- App update checks no longer list command-line packages or records left behind after
  their apps have been removed.
- The App Switcher opens quickly when apps run many helper processes. Clicking another
  app now cancels the switch cleanly.
- Scrolling screenshots now let you scroll the chosen area yourself, then finish
  with Enter or Done.
- Copy text from screen retries with a different recognition path when the first
  pass finds nothing.
- Screen recording now freezes the display while an area is chosen. Escape cancels
  selection even if another app took focus.
- Cleaning Mode stays locked until you click Unlock or press Escape five times.
  Trackpad gestures no longer move the screen while cleaning.
- Windowless apps now keep their labels aligned in the App Switcher's Small size.
  Thanks to @Yahddyyp.
- Small app icons now keep the correct artwork in Finder. Thanks to @slrgt.
- Main windows from supported professional media apps now appear in App Switcher,
  Command Tab and Dock Preview.
- Newly placed screenshot annotations can be moved, resized or edited immediately
  while their selection remains active.
- The menu bar panel no longer leaves a focus outline on a different section than
  the one being shown.
- The menu bar panel now opens on the first visible section in your chosen order
  after Vorssaint starts.
- The System panel no longer shows battery readings on Macs without a battery.
- The package manager page and Settings sidebar now keep their tops visible and
  scroll normally.
- Package manager actions now stop cleanly if an underlying command becomes
  unresponsive. Thanks to @PathGao.
- Settings backup imports now reject values of the wrong type instead of applying
  them to unrelated options. Thanks to @PathGao.
- Apps listed under Apps to leave alone now also keep scrolling they generate
  themselves.
- Dock Preview cards now leave your current app in front while you browse.
  A window opens only when you click its card.
- Side-wheel directions can now carry separate mouse shortcuts. Thanks to @JoeMo-GenX.
- Shortcut fields now reject combinations already used by macOS, avoiding both
  actions running together. Thanks to @PathGao.
- In-app updates now stop downloads that exceed the release's expected size.
  Thanks to @PathGao.
- The Uninstaller now stops an app's background parts before moving it to the Trash.
  Thanks to @SeoliteQ.

## [3.3.0] - 2026-08-04

### Summary
Vorssaint 3.3.0 records the screen, captures and shares screenshots, and improves
annotation order. Finder and Window Layout gain new tools and refinements, while
setup and the Command Bar make features, feedback and saved searches easier to use.

### Added
- Screen recording with automatic zooms for clicks and typing, reusable presets,
  direct copy, and video or GIF export. Off by default.
- Screenshots can create temporary links for 1, 6 or 24 hours from the preview or
  editor, with clear privacy details.
- Scrolling screenshots join long pages into one image and stop exactly where
  you choose. From Screenshot or the Command Bar. Thanks to @ruvelro.
- Bug reports and feature ideas can be sent from General or the Command Bar,
  with optional technical details shown before sending.
- A slider for how solid the Dock preview panel looks. Under Switcher, with
  Dock Preview on. Thanks to @ruvelro.
- Window thumbnail capture can pause while chosen apps are in front. Under
  Switcher, thanks to @KDarto.
- Apps the clipboard history skips, so nothing copied in them is saved. Under
  Clipboard. Thanks to @CSkjolden.
- A configurable shortcut renames selected files and folders in Finder. It
  starts on F2, off by default. Thanks to @Mito450.
- Copied images can become PNG files with ⌘V in Finder, off by default under
  Clipboard. Thanks to @AsphaltDemon.
- Separate shortcuts capture the whole screen or reopen your latest screenshot.
  Under Screenshot, both off by default. Thanks to @Yahddyyp.
- A slider makes the Scratchpad background more solid, up to fully opaque.
  Under Quick Tools. Thanks to @hash00.

### Changed
- First setup now asks what you want before requesting only the permissions
  those choices need. Features remain available later in Settings.
- The Command Bar can quit, restart, force quit or send an app to the
  Uninstaller. Newly installed apps appear when the bar reopens.
- Screenshot annotations can move forward or backward through the drawing
  order, with undo support. Thanks to @hash00.
- The System panel can open the Mac's full process inspector from its usage
  list. Thanks to @hash00.
- The Volume Mixer adjusts overall volume directly and can send system sounds
  to a separate output. Thanks to @vkplayz0 and @p3P4.
- Mute microphone now lives in Quick toggles in the menu bar panel. Thanks to
  @AB-boi.
- The Scratchpad now has a pin that keeps the current note open until you close
  it. Thanks to @hash00.
- Window Layout's Restore action now steps back through recent placements.
- App Switcher and Dock Preview now have a Small size that reduces previews and
  the space between them. Thanks to @CSkjolden.
- Selecting an app with no open window in the App Switcher now asks it to open
  one. Thanks to @Yahddyyp.
- The App Switcher now appears immediately, without a pop-in animation. Thanks
  to @CSkjolden.
- The clipboard history no longer saves a copy that an app marks as a
  password, whatever the other options are set to.
- The remaining-time menu bar option now lives with Keep Awake session settings
  under Energy. Thanks to @hash00.

### Fixed
- Quit on close now protects every part of an excepted app, including windows
  run through bundled components.
- Window Layout shortcuts now arrange the active Settings window too. Thanks to
  @vraravam.
- Menu bar readings now dim with the rest of the bar on displays that are not
  active. Thanks to @JaffryGao.
- The App Switcher's initial selection no longer loses part of its border when
  only two apps are available. Thanks to @WiLuX-Source.
- CPU and GPU temperatures no longer drop to impossible single-digit readings
  when a sensor briefly reports bad data. Thanks to @georgo.
- The App Switcher no longer adds a blank duplicate for a window on another
  desktop. Thanks to @CSkjolden.
- App Updates no longer lists Vorssaint itself or versions that need a newer
  macOS. Thanks to @AB-boi.
- A disabled feature no longer blocks its saved shortcut from being used
  elsewhere. Thanks to @AB-boi.
- Three-finger middle clicks now stay reliable when macOS initially reads the
  press as a secondary click. Thanks to @justareported-blip.
- The App Switcher no longer stalls when certain apps are open. Thanks to
  @Sirtx.
- Radial menu submenus now open their action list after creation and keep it
  easy to find later. Thanks to @z76k.
- The radial menu now stays open while the Super Key is held and follows the
  pointer until the key is released. Thanks to @AB-boi.
- The permissions page now explains the App Management access needed before
  updating installed apps. Thanks to @AB-boi.
- The clipboard history no longer drops plain identifier codes when it is set
  to skip text that looks sensitive.
- Picking a window on another desktop now switches over right away, instead of
  stalling for a couple of seconds. Thanks to @CSkjolden.
- The mouse side buttons now go back and forward on keyboard layouts such as
  German and French, where they did nothing at all. Thanks to @thomas-goerlich.
- Extra brightness now holds while you swipe between desktops, instead of
  dropping out until the animation ends. Thanks to @stevenyang406.
- A mouse button set to a shortcut with an arrow or an F key now presses it
  everywhere, including the window shortcuts. Thanks to @hash00.
- A saved search in the Command Bar stays in the list while you type what to
  look for after its name. Thanks to @tenbux.
- Saved Command Bar searches now work with spaces produced by Chinese input
  methods. Thanks to @tingke.

## [3.2.0] - 2026-07-31

### Summary
Vorssaint 3.2.0 adds the Command Bar, one field that finds and runs anything on
your Mac, plus app updates in one list, a searchable snippet menu, a super key
on Caps Lock and mouse button shortcuts.

### Added
- The Command Bar. One shortcut opens a field that finds and runs anything,
  including the menu commands of the app in front. Under Command Bar, off by
  default.
- App updates. One list of the apps with a newer version, ticked the way you
  want, updated together. Under App updates.
- A snippet menu. A shortcut opens your snippets in a searchable list and
  picking one types it at the cursor. Under Text snippets.
- A super key. Hold Caps Lock and it becomes Shift, Control, Option and
  Command together, for shortcuts nothing else uses. Under Super key.
- Mouse button shortcuts. Any extra mouse button can press a key
  combination for you. Under Mouse.
- Full Screen joins the window layouts, the same one the green button gives.
  Under Window layout.
- Screenshots can copy themselves to the clipboard the moment they are
  taken. Under Screenshot. Thanks to @kingstyles.
- Screenshots can run the action you choose right after each capture.
  Thanks to @403Denied.
- Screenshot saves can go into dated subfolders and follow a file name
  pattern you set. Thanks to @403Denied.
- The radial menu gained slices for the Shelf, Cleaning Mode, Keep Awake
  and window layouts. Thanks to @ruvelro.
- You choose how the radial menu opens, by a press or by holding it.
  Thanks to @ruvelro.
- The Cleaner can clear the media a messaging app leaves in your downloads,
  always to the Trash and off by default. An optional organizer files new
  ones into a folder you pick. Thanks to @ruvelro.
- The last capture outline in the screenshot selector can be hidden.
  Thanks to @ruvelro.
- W closes the highlighted window in the app switcher, leaving the app
  running.
- The app switcher can list apps that are running with no window open, the
  way the system one does. Under Switcher, still set to the Finder alone.
- Hide apps from the volume mixer with a right click. The same menu brings
  them back.
- Each removable drive in the Drives tab now has its own eject button.
- Snippet triggers can ignore capitalization, and date variables can follow
  the format you want.
- Each mouse feature can name apps to leave alone, for apps that use the
  wheel and the buttons their own way. Under Mouse.
- The app can stay light or dark on its own, apart from the Mac. Under
  General.

### Changed
- Settings groups App updates, Cleaner, Homebrew and Uninstaller under App
  management.
- Recording a shortcut keeps the keys to itself instead of triggering the
  app or the system.
- "Open the editor right after capturing" became the Edit after-capture
  action, and existing setups keep working unchanged.
- The scratchpad now closes when you click outside it. A toggle under Quick
  tools keeps it floating instead.
- The app switcher now closes when you click outside it.

### Fixed
- Eject all disks now finds every external drive, not only the ones with
  media that comes out, like a memory card. On most Macs it used to say no
  external disk was ready.
- The app switcher now lists windows in the order you really used them. It
  follows the windows you pick with the mouse, and windows of the same app.
- The hot CPU alert no longer fires on a momentary spike. The temperature
  now has to stay above the limit for a few seconds.
- Quit on close no longer leaves apps running after their last window is
  closed, including apps that hide the window instead of closing it.
- The red dot in the panel is gone. It marked the Cleaner as new since an
  older version and could stay on screen for good.
- Showing the menu bar icon again waits for macOS to place it before
  reporting a problem.
- Brightness keys step from where the monitor actually is. After a pause the
  monitor is asked first, so a screen at 80% no longer drops to one step.
- Brightness keys and sliders reach an external monitor again after the Mac
  has slept. The connection is looked up fresh on waking.
- Copy text from screen works again. The area is now picked with the app's
  own selector, the same one screenshots use.
- Muting the microphone now cuts every microphone, not only the one macOS
  is set to. An app pointed at a headset of its own goes quiet too.
- The app pickers list every app again, including the ones macOS keeps
  outside the applications folder.
- The App Switcher and Dock previews now show windows from other desktops
  too, and an option keeps everything to the current one.
- Q in the app switcher quits from the Q on your keyboard, on layouts that
  put the letter somewhere else.
- Undo works in the screenshot editor, and clicking an annotation selects
  it instead of drawing on top. Thanks to @ruvelro.
- The Homebrew settings page no longer breaks in narrow windows.
  Thanks to @ruvelro.
- Opening the Cleaner page no longer blanks the Settings sidebar on the
  newest macOS, and its tool switcher shows again.
- Restoring the panel's quick controls also brings back a hidden Text
  snippets toggle.
- Boosting an app's volume above 100% no longer crackles at loud moments.
- The green button and window layout tools now resize slow browsers
  properly instead of leaving them small or misplaced.
- Volume levels for some games and tools were not saved since 3.1.15. They
  are saved again and old ones come back.
- The mixer repairs its audio path by itself after the Mac wakes, instead
  of leaving an adjusted app silent.
- An app you turned down no longer plays slowed down, or falls silent, on
  earbuds during a call and on some other outputs. Thanks to @danilo-alm.
- Paste as plain text no longer leaves the pasted style on what you type
  next in some rich text apps.
- Shelf items now follow their files across moves and renames. Only a file
  that is really gone steps aside, with a note instead of a drag nothing
  accepts.
- The Drives tab no longer shows a drive's format and location twice.
- External monitors no longer go dark while adjusting brightness, and a
  reconnected screen always comes back visible.
- Minimizing several windows from the Dock icon animates them together
  again, and restoring them ends with the right window on top and
  focused. Thanks to @Zvzdov.
- Monitor blocks in the menu bar sit centered again on macOS 26 and
  earlier. Thanks to @wzxu.

## [3.1.15] - 2026-07-21

### Summary
Vorssaint 3.1.15 fixes starts that could leave the app with no menu bar icon
or quit it right away, freezes where the app stopped responding, a crash
while choosing a screenshot area, and an external display that could go dark
and stay dark. It also gives back the clicks that moving windows by dragging
was taking from other apps, repairs smooth scrolling, the brightness keys and
the shortcut recorder, and brings the window switcher back on the first
press.

### Fixed
- Moving and resizing windows by dragging no longer takes the modifier click
  away from other apps. A click that does not move now goes to the app as
  usual, and the window only follows the pointer once you actually drag.
- The window switcher opens on the first press again after you close every
  window of an app or move to another desktop. With nothing left to switch to,
  the shortcut now stays quiet instead of falling back to the system switcher.
- Smooth scrolling moves the right distance on mice that report the wheel
  continuously, and the speed setting now works on them.
- Smooth scrolling no longer reverses the scroll direction on its own.
  Inverting the direction works alongside it, and so does Shift to scroll
  sideways.
- The app could start with no menu bar icon and quit a few seconds later.
  It now starts reliably, including on a Mac whose display was still waking
  up.
- The app could quit at startup right after an update, while the tour of the
  new features was opening. The tour now keeps the same size on every page.
- The app could stop responding for a while at a time, often right when
  headphones or another audio device connected. It no longer waits on the
  audio system, on other apps that are busy, or on commands that never
  answer, and it stops watching audio properly when the mixer or the mic
  mute is switched off instead of leaving watchers behind.
- An external display could go dark while its brightness was adjusted and
  stay dark until it was unplugged. It recovers now, and a screen switched
  off here comes back at the next start.
- Choosing a screenshot area no longer quits the app when the drag ends with
  more than one finger leaving the trackpad. Cancelling with Escape is safe
  too. Thanks to @lei1024.
- Window Switcher previews show the whole window. A window pushed over the
  edge of the screen used to appear as a thin strip.
- Brightness keys follow the pointer on keyboards other than the built-in
  one, including with the lid closed.
- Per-app volume no longer jumps loud or quiet when an app changes what it
  is playing. Quitting or switching the mixer off puts back the input
  device and the volume it changed.
- The panel stays under its icon when the menu bar is set to hide itself.
  Switching tabs no longer moves it to the edge of the screen.
- Recording a shortcut captures it instead of running it. Delete clears the
  shortcut, more keys can be recorded, and the field no longer overlaps the
  text beside it while it listens.
- The radial menu settings now say whether the app can see the mouse button
  you picked, so a button the mouse itself has taken over is obvious.

## [3.1.14] - 2026-07-18

### Summary
Vorssaint 3.1.14 adds a radial menu that puts your favorite actions on a
wheel around the pointer, Camera preview, a floating mirror for video
calls, and a scratchpad that keeps quick notes in a floating window and
saves as you type. A short tour presents the highlights once after the
update. Screenshots gain a pixel loupe, QR code reading and
solid color blocks, the clipboard history can keep up to 1000 items, and a
long round of fixes covers typing lag with the App Switcher on, brightness
keys on external monitors, Launch at Login, the Volume Mixer and more.

### Added
- A new radial menu puts your favorite actions on a wheel around the
  pointer, from apps and links to media controls. Hold the shortcut or an
  optional side mouse button, point and release. Off by default in Settings
  under Radial menu.
- Camera preview opens a small floating mirror with your webcam from the
  panel, the quick panel or a shortcut. It picks between cameras when more
  than one is connected and closes when you click away.
- A scratchpad keeps quick notes in a small floating window that saves as
  you type. It opens from the panel, the quick panel or a shortcut, and can
  clear itself after days unused.
- The optional brightness overlay shows the percentage after brightness
  changes on the Mac screen and external monitors. Off by default in
  Settings under Energy.
- Screenshots can skip the floating preview and open straight in the
  annotation editor. Off by default in Settings under Screenshot.
- The screenshot selection now has a pixel loupe for precise captures.
  Press Z to show or hide it and scroll to zoom. Thanks to @ruvelro.
- Copy text from screen now reads QR codes and shows their content so you
  can copy it or open the link. The same works from a screenshot's preview
  and editor. You can turn it off in Settings.
- The Disks panel now shows each drive's file system format, like APFS or
  exFAT, next to the drive name.
- The clipboard history can now keep up to 1000 items. Pick the size in
  Settings under Clipboard. Thanks to @ruvelro.
- A short tour opens once after the update, showing the new features with
  a button to set up or try each one right away.

### Changed
- Dock Preview now works with Dock magnification enabled, so the zoom effect
  no longer needs to be turned off.
- The black bar in the screenshot editor is now a solid block that can use
  any of the palette colors.
- Window Switcher now moves to the last item in a shorter next row when the
  down arrow has no item directly below.

### Fixed
- Typing no longer lags in demanding apps while the App Switcher is on.
  Under heavy load, key presses could arrive late and then land all at
  once.
- Brightness keys now really follow the pointer on external monitors that
  macOS drives natively, including with the lid closed. Presses used to
  land only on the built-in display.
- Vorssaint no longer crashes right after launch when macOS returns no power
  source data for the battery readings.
- Closed lid mode no longer asks for the administrator password on every
  toggle. The one-time setup is now verified for real and repaired with a
  single prompt when it stops working.
- Smooth scrolling now works with mice that report the wheel as continuous
  scrolling. Their events were mistaken for a trackpad and skipped.
- Apps that run through a compatibility layer now show up in the Window
  Switcher. Focusing one no longer makes the shortcut fall back to the
  system switcher.
- Browsers that play sound through helper processes now show up in the
  Volume Mixer. macOS does not credit that sound to the app, so the mixer
  traces it back on its own.
- Back/Forward mouse buttons now reach apps that handle them natively, like
  browsers, virtual machines and remote screens, instead of being captured.
  Finder and other apps keep the converted navigation.
- The Shelf area under the menu bar icon no longer appears while a window is
  being moved or resized. It only opens for a real file or content drag.
- Launch at Login no longer turns itself off after the app restarts. The app
  restores the setting when macOS drops it and now explains when it runs from
  a place that cannot open at login.
- Extra Brightness no longer drops briefly as video enters or leaves fullscreen.
- Monitor blocks in the menu bar, including the usage bars, no longer sit a
  couple of pixels above the other status icons on macOS 26 (Tahoe).
- Settings sidebar rows no longer slide over the search field while
  scrolling on macOS 26 (Tahoe).
- The macOS permission prompts now appear in the language the app speaks
  instead of English only.

## [3.1.13] - 2026-07-15

### Summary
Vorssaint 3.1.13 adds a screenshot tool with a quick preview and optional
editor, brightness and power controls for
all your displays, a Quick toggles tab, automatic Keep Awake rules and compact
usage bars in the menu bar. It also keeps Extra Brightness steady around
fullscreen video and returns Finder to the Volume Mixer.

### Added
- Screenshot captures an area, window or screen. A compact
  preview offers copy, save, delete and editing, with stickers, annotations,
  precise crop, optional shadows and backgrounds in the editor.
- Display controls for the Mac screen and external monitors in the menu bar
  panel and Settings. Adjust brightness, turn a display on or off and
  optionally let the keyboard brightness keys follow the pointer. Enable
  Displays under Energy settings.
- A new Quick toggles tab offers one-click actions such as switching between
  light and dark mode, emptying the Trash, ejecting all disks and hiding
  desktop icons. It appears in the menu bar panel and in the quick panel.
- The battery's estimated time remaining can appear in the menu bar and the
  Power panel. The menu bar reading is off by default and can be enabled in
  Settings.
- Keep Awake can start with an external display or while connected to power.
  Combine both conditions in Options or Energy settings.
- Keep Awake can use the Vorssaint, coffee, eye, moon or lightbulb icon while
  active. Choose the icon and its color in Options or Energy settings.
- Window Layout moves and resizes windows from any point with a trackpad or
  mouse. Drag with chosen modifiers to move, add Shift to resize, or use the
  mouse's right button. It is off by default in the panel and Settings.
- CPU, GPU, memory and disk use can appear as compact bars in the menu bar.
  Choose Values or Bars and adjust their colors and medium and high limits in
  Monitor settings.
- Cleaning Mode now blacks out every display while the keyboard is locked.
- Korean is now available throughout the app and can be selected in Settings.
  Thanks to hyo.c (@pshyomin) for the translation.

### Changed
- Package updates now stay at the top of the installed list, with clearly
  labeled controls in the panel.
- Monitor alerts now explain when limits trigger a notification, when short CPU
  spikes are ignored and that the time setting only delays repeated alerts.

### Fixed
- ⌘Tab now falls back to the system switcher when a fullscreen app does not
  expose a switchable window.
- Smooth Scrolling now moves horizontally while Shift is held.
- Dock click to minimize now reacts immediately in more apps and no longer
  opens unrelated windows.
- Closed lid mode now asks for the administrator password only once.
- Extra Brightness no longer flashes when video enters or leaves fullscreen.
- App Switcher now includes apps that draw their windows separately, with
  working previews.
- Finder stays available in the Volume Mixer for Quick Look audio. A switch
  at the bottom can hide it.
- Clipboard History no longer crashes when automatic URL cleaning inspects the
  same copy.

## [3.1.12] - 2026-07-11

### Highlight
Vorssaint is massively optimized, with up to 95 percent less CPU and
energy use than 3.1.11. Cooler, quieter and easier on your battery.

### Summary
Vorssaint 3.1.12 adds a Features hub with one click bundles and honest
energy badges, an onboarding that sets the app up from one answer, a
floating permission guide, text snippets, settings backup and a cleaner
that reaches the storage macOS calls Other. It is also far lighter on
CPU and fixes extra brightness during HDR video, Dock icon dragging and
Dock clicks on Java apps.

### Added
- A Features hub in Settings installs and uninstalls whole features.
  What you uninstall disappears from the entire app and stops loading,
  so it uses no CPU, memory or energy. Nothing is deleted and installing
  brings it back as it was. Its Permissions tab shows which features use
  each permission and flags granted ones nothing is using.
- Start with a bundle. Three one click packs in the hub shape the app
  for volume, windows or battery, and every feature now wears an honest
  energy badge telling what it keeps alive while on.
- Onboarding now ends asking what brought you here. One answer applies
  the matching bundle and setup finishes already shaped for it.
- A small floating guide appears when a permission needs a trip to
  System Settings. It shows the three steps and notices the grant by
  itself.
- Text snippets turn a short trigger into your text, right away or
  after a space, with date, time and clipboard variables. Off by
  default, in the panel's keyboard controls and in Settings.
- The cleaner now reaches the storage macOS calls Other. Old iPhone and
  iPad backups appear with device and date, never preselected, and
  stale Xcode DeviceSupport caches join the developer junk.
- Settings backup exports your whole setup to a file and imports it on
  another Mac. In the Advanced settings.

### Changed
- Deep energy work across the app. Mouse movement, typing, menu bar
  metrics and permission checks stop repeating work they had already
  done. Everything looks and behaves exactly the same, just cooler.

### Fixed
- Extra brightness no longer flickers or drops out while HDR video plays
  or goes fullscreen. The boost now holds steady and follows the panel
  smoothly.
- Clicking the Dock icon to minimize now works with Java apps such as
  DBeaver. Windows the system reports slowly or not at all get a second
  look, and apps without a Minimize All menu use their plain Minimize.
- Dock icons can be dragged and reordered again while Dock clicks are
  on. The click now acts when the button lifts, so press and hold turns
  into a normal drag.
- The side buttons option no longer shows the invert scrolling text
  while active.
- The menu bar panel opens centered under the app icon again. Newer
  macOS builds could strand it against the screen edge until the tabs
  changed.
- Hovering a Dock preview can no longer pull a minimized window back
  out. A window whose state cannot be verified now stays untouched, and
  a Dock that restarts while previews are blocked is picked up again.

## [3.1.11] - 2026-07-10

### Summary
Vorssaint 3.1.11 adds Cleaner, a simpler switcher, more useful Shelf
controls, sixth screen layouts and mouse side button navigation. It also
keeps extra brightness steady, blocks unwanted Music launches and lets
paste as plain text use Command V.

### Added
- The Cleaner finds leftovers from uninstalled apps, caches and logs.
  You review everything first, removed items go
  to the Trash, and the safe part can also run on its own daily or
  weekly. In the quick panel and the menu bar panel.
- Stop Music from opening on its own. With the option on, pressing a
  media key no longer brings up the Music app, and another app of your
  choice can open instead. Off by default, in the General settings.
- The app switcher has a simple app layout with window titles but no
  previews or screen capture, while still restoring minimized windows.
  Off by default in the App Switcher settings.
- Window Layout can place the active window in any cell of a six part
  grid. Each action can receive its own shortcut in Settings.
- Mouse side buttons can navigate back and forward in Finder, browsers
  and compatible apps. Off by default in Mouse settings and the panel.

### Changed
- The Shelf can close and remove items after a successful drop, stay open
  when pinned and ignore automatic opening in chosen apps. File tiles also
  offer Open With and AirDrop from the right click menu.

### Fixed
- Extra brightness no longer fades back a moment after turning on. The
  boost now holds steady and adapts to what the display can sustain.
- Paste as plain text now works when its shortcut is set to Command V.

## [3.1.10] - 2026-07-09

### Summary
Vorssaint 3.1.10 fixes extra brightness, which showed as unavailable on
the MacBook Pro models it was made for.

### Fixed
- Extra brightness is now available on every MacBook Pro with an XDR
  display. It stayed marked as unavailable on those Macs.

## [3.1.9] - 2026-07-08

### Summary
Vorssaint 3.1.9 gives the shelf a home under the menu bar icon, adds
smooth mouse scrolling and extra brightness for XDR displays, and makes
the Settings window resizable. It also fixes typing freezes while a
password prompt is open.

### Added
- Drag a file toward the menu bar and the shelf opens under the app icon
  to catch it. Dropped items stay in a small mark there that opens with a
  click and leaves once the shelf is empty. On when the shelf is on, with
  a switch in the shelf settings.
- The XDR display of MacBook Pro models can now go past its maximum
  brightness, using the reserve the panel saves for HDR. Off by default,
  in the Energy settings, with an intensity slider.
- Mouse wheel scrolling can glide smoothly instead of jumping line by
  line. Off by default, in the Mouse settings, with an adjustable step.
- The dock click to cycle windows option now has a toggle in the menu bar
  panel too, next to the other quick controls.

### Changed
- The Settings window is now resizable, opens tall enough to show the
  whole sidebar and remembers the size you choose.
- Holding the switcher key now stops at the end of the list instead of
  wrapping around, like the system switcher.

### Fixed
- Typing no longer freezes for a few seconds while an app shows a password
  prompt, such as an unsigned app asking for the Keychain.
- The switcher shortcut for windows now works in the plain grid too,
  jumping between the selected app's windows while the switcher is open.
- The extra key on ISO keyboards, such as the caret key on German ones,
  can now be recorded as a shortcut.
- Paste as plain text now asks for the Accessibility permission it needs
  instead of silently swallowing the shortcut when it is missing, and the
  paste lands more reliably once the shortcut keys are released.
- Sidebar items no longer show through the Settings search field while
  scrolling.
- Updating Homebrew packages from a third party tap no longer fails
  silently, offering a one click step to trust the tap and continue.
- Finder no longer shows up in the Volume Mixer.

## [3.1.8] - 2026-07-07

### Summary
Vorssaint 3.1.8 polishes the whole app. The Settings window gains a search
field and clearer groups, the menu bar metrics learn a compact spacing and
can stand alone without the app icon, and the image converter now produces
PDFs. Community requests came along: an optional mute indicator beside the
menu bar icon, a progress bar when files move to another disk, and HEX
colors copied without the # sign. Under the hood, in app updates now
install reliably and show download progress, the shelf keeps its items
across restarts and updates, the quick panel works properly with file
dialogs and drag and drop, and the menu bar panel no longer flickers on
the Volume Mixer page on Macs with busy audio activity.

### Added
- The quick panel now has a close button, so it can be dismissed with the
  mouse as well as with Esc. The first nine tiles also show a small number
  badge, since pressing 1 to 9 launches them straight from the keyboard.
- The quick panel's edit mode now adjusts tools in place: tiles with a gear
  badge (Keep awake, Mute microphone, Color picker and Clipboard) open a
  small card with their closest options, like keeping the Mac going with
  the lid closed, the default duration, the muted mic indicator in the menu
  bar, the copied color format and the clipboard history limit, with no
  trip to the Settings window.
- The window layout grid can now hide the arrangements you never use: a
  tune button in its header switches the buttons to visibility toggles, and
  hidden actions leave the grid while their keyboard shortcuts keep
  working. Most people use a handful of layouts; now the grid can look
  like it.
- Clicking the Dock icon of the app you are using can now cycle through
  its open windows, like the Command backtick shortcut but with the mouse,
  thanks to a community contribution. Off by default, next to the Dock
  click to minimize option; with both turned on, apps with several windows
  cycle and apps with a single window still minimize.
- Middle click can now also fire from a light trackpad tap, without
  pressing: choose three or four fingers next to the middle click option in
  the Mouse settings. Off by default; sliding touches never count, and the
  four-finger choice sidesteps the macOS three-finger drag gesture entirely.
- The menu bar icon now shows when the microphone is muted: a red
  crossed-out mic appears beside it while the mute is on, so a live call
  never catches you guessing. On by default and invisible until you
  actually mute; the switch lives next to the Mute microphone option in
  the Quick Tools settings.
- Cut and paste in Finder now shows progress when files move to a different
  disk: the floating card gains a progress bar with the file name and the
  position in the batch while the copy is still running. Moves inside the
  same disk stay instant and skip the bar.
- The Color Picker can copy HEX values without the leading # sign, for
  design tools that reject it. The option appears under the format choice in
  the Quick Tools settings whenever HEX is selected.
- The image converter can now turn any image into a PDF, following a user
  request: PDF joins JPEG, HEIC and PNG in the format choice, handy when a
  form or service only accepts PDF documents. The quality and maximum size
  controls keep working, so a photo can be shrunk into a small PDF before
  it is submitted. With PDF chosen the start button says Convert to PDF,
  and whenever a result comes out bigger than the original the done card
  says so, since growth is normal for a small photo wrapped in a document.
- The Settings window gained a search field at the top of the sidebar:
  type a few letters and only the matching pages remain, accents and case
  ignored. It also searches by what lives inside each page, so "lid" finds
  Energy and "quick panel" finds Quick tools. With over twenty pages,
  finding the right one no longer depends on remembering which group it
  lives in.
- In app updates now show download progress: the panel banner gets a real
  progress bar with a percentage while the new version downloads, and the
  About page shows the same percentage, so a slow connection no longer
  looks like a stuck update.
- Window layout shortcuts can now be removed one by one, following user
  feedback: most people use a handful of layouts, and every assigned
  shortcut occupies a system-wide key combo other apps then cannot use. A
  new remove button next to each layout clears its shortcut (the button
  shows None), Reset brings the original back, and cleared shortcuts are
  simply never registered.
- Monitor alerts can now fire as often as every 2 minutes, following user
  feedback that 5 minutes was too long to wait for a memory pressure
  warning. And when notifications for Vorssaint are turned off in System
  Settings, the alerts section now says so, instead of leaving enabled
  alerts silently dead.
- A new Keyboard shortcuts page in Settings lists every global shortcut
  currently active in one place, including the window layout combos, so
  nobody has to remember which feature page holds which one. Each shortcut
  keeps being configured where its feature lives.
- The app icon can now step aside while metrics are in the menu bar,
  following user feedback: a new option in the Monitor settings hides the
  icon so only your readings take up space, whether they sit next to the
  icon or as separate items. The icon comes back by itself whenever it is
  needed, when metrics leave the bar and when there is something to show
  you, like a ready update or the muted microphone indicator.
- Menu bar metrics gained a spacing choice, following user feedback that
  the gaps between readings looked too wide. The new Compact look is the
  default: it hugs the numbers, making the whole strip about a quarter
  narrower while still holding enough room that readings can move between
  one and two digits without the bar wobbling. The Standard option in the
  Monitor settings keeps the old behavior of reserving room for each
  metric's largest value.

### Changed
- The app reads much better with VoiceOver: the quick panel tiles, the
  edit badges, the inline option switches and the window layout controls
  now carry proper spoken labels instead of announcing only "button".
- Esc in the quick panel now steps back one layer at a time, closing the
  open options card first, then leaving edit mode, then hiding the panel.
  And a quick panel with every tool hidden now explains how to bring them
  back instead of showing an unrelated hint.
- Panel rows now show their feature's keyboard shortcut in a quiet badge
  when one is active, so the quick panel, Clipboard, Copy text from screen,
  Color picker and Mute microphone remind you of the faster way in. The
  quick panel row also moved to the top of the Utilities section by
  default; a custom order stays as you arranged it.
- The Settings sidebar got clearer groups: a new Files section gathers the
  Clipboard, Cut and paste, Shelf and Media pages, window features stay
  together under Window controls, and Utilities keeps the quick tools. The
  same pages, in places that are easier to guess.
- The introduction now presents the quick panel on its own page, with the
  shortcut and a button to open it right away. It is the fastest way into
  the app's tools and used to be easy to miss.
- The introduction was tightened from sixteen pages to ten: the separate
  tour pages for Cut and paste, Quit on close, the Uninstaller and the
  Temporary area became simple switches on the Optional features page, and
  each feature's own Settings page keeps the full explanation. Installing
  the app should take half a minute, not a slideshow.
- The memory pressure dot option now sits directly under the Memory row in
  the Monitor settings, next to the metric it controls, matching the
  Network row's inline option. Contributed by Games55k.
- App icons in the Volume Mixer are much bigger now, sitting beside each
  app's name and volume slider, so rows are easier to recognize at a glance.
- Selecting several clipboard items now works the Finder way, following
  user feedback: ⌘-click or ⇧-click select rows (an empty checkbox appears
  on hover), and with a selection active the window shows Paste and Copy
  buttons with the count. ⌘C copies the selection without pasting, ready
  for ⌘V wherever you are; Enter and a plain click still paste directly,
  ⌘A selects all visible results and Esc clears the selection first.
  Copied files and images can join a selection too: a files-only selection
  pastes the files themselves, a selection with images pastes as rich text
  with the images embedded (Notes, Mail and TextEdit take everything
  together, plain apps receive the text), and text with file paths combines
  as text.
  Modifier clicks on rows also work reliably now: the window used to treat
  ⌘-click as a window-drag grab, so it never reached the row.

### Removed
- The List navigation mode of the panel is gone: the panel always navigates
  by sections now. Sections were the default and where all the attention
  goes; keeping a second layout of the same panel doubled the ways it
  could break.

### Fixed
- The introduction could get stuck on the menu bar metrics page: the list
  of metrics outgrew the window and pushed the Continue button out of it.
  Every introduction page now scrolls when needed, and the navigation
  buttons always stay visible.
- Per app memory in the Monitor now matches Activity Monitor: it shows the
  same physical footprint figure Activity Monitor uses, instead of a raw
  measure that counts shared memory twice and reads far too high for many
  apps.
- Zoom and music production apps now appear in the Volume Mixer again as
  informational rows saying the app manages its own audio, instead of
  silently missing from the list. They are still never touched by the
  mixer, which is what keeps their calls and sessions working.
- The switcher could miss many apps on busy Macs, including the app in
  front of you and freshly opened ones. The switcher keeps at most 24
  entries, but the cut used to happen in the window server's raw order,
  which puts windows parked on other Spaces before visible ones; now every
  window is collected first, sorted by most recent use, and only then
  trimmed, so the apps you actually use always make the list.
- Routing a music production app through the Volume Mixer could leave it
  producing no sound at all: apps like Logic Pro, Ableton Live, Cubase,
  Studio One, Pro Tools, REAPER and other DAWs drive their own audio device
  and clock, which the mixer's tap cannot do for them. The mixer now leaves
  these apps untouched, the same way it already does for Zoom, so their
  audio always keeps playing; use the DAW's own output settings to route
  them.
- Memory use now stays flat over long sessions, answering reports of the
  app growing to several gigabytes after days of heavy use. Window
  thumbnails for the switcher and Dock Preview are copied into the app's
  own memory instead of holding on to system graphics surfaces, respect a
  memory budget besides the entry count, and are released automatically
  when the Mac runs low on memory; clipboard image previews and the menu
  bar metric renders got hard memory ceilings; and the Volume Mixer lets
  go of its per app audio listeners when apps quit.
- The Show menu bar icon button now places the rebuilt icon beside the
  clock, the last spot macOS hides when the menu bar runs out of room. It
  used to put the icon back at the end near the notch, the first spot to be
  hidden, so on crowded menu bars the button looked like it did nothing. And
  when the icon still cannot appear, the app now explains why (a full menu
  bar, or a menu bar manager like Ice or Bartender keeping it in its hidden
  section) instead of staying silent.
- A drawing bug made icons render at half their intended size across the
  app, in the Volume Mixer, in the Monitor process rows and in shelf tiles.
  Icons now draw at their full size.
- Updating from inside the app could close it without applying the new
  version and without any explanation. Now, when your user account cannot
  write to the Applications folder, the app asks for an administrator
  password instead of failing silently; with Gatekeeper turned off, the
  update no longer fails its safety check by mistake; running from the disk
  image, the app explains it needs to be moved to Applications first; and if
  an update still cannot be applied, the app tells you why after it
  restarts, brings the offer right back, and routes the next attempt
  through the administrator password when the failure looked like a
  permission problem, instead of leaving you on the old version without a
  word.
- Choosing a file from a tool in the quick panel now works. The file dialog
  used to come up unresponsive (folders would not open, files could not be
  selected and only Cancel reacted), and any click inside it could close the
  quick panel in the middle of the selection.
- The quick panel no longer closes on its own while a tool is open inside
  it. Clicking another app to drag a file into Media, answering a system
  prompt from the Uninstaller, or leaving Homebrew working no longer
  dismisses the panel. With just the launcher grid showing, clicking outside
  still closes it, as before.
- Items placed on the shelf (files, images, text and links) were erased
  whenever the app restarted, including on every update. The shelf now
  remembers its items: they are saved as you add and remove them and come
  back after a restart or an update. Images and GIFs pasted straight into
  the shelf are stored safely for this too, and an item whose file no longer
  exists on disk is skipped instead of coming back as a broken tile.
- The menu bar panel no longer flickers repeatedly while the Volume Mixer
  page is open. The panel used to redraw for every audio system event, even
  when nothing visible changed, so on Macs with busy audio activity (wireless
  audio devices renegotiating, apps opening and closing audio connections)
  it flickered constantly while open. The mixer now updates only when
  something on screen actually changes, and bursts of audio events are
  folded into a single update.
- Two apps with the same name in the Volume Mixer, or two audio devices with
  the same name in the output and microphone lists, could swap places with
  each other whenever the list refreshed. Rows now keep a stable order.

## [3.1.7] - 2026-07-04

### Summary
Vorssaint 3.1.7 adds the quick panel, a floating hub that opens anywhere with
one shortcut and holds your favorite tools, lets a click on the Dock icon
minimize an app's windows, adds a real middle click for the trackpad, saves
copied images and files in Clipboard History, and adds four new tools: copy
text from screen, color picker, mute microphone and paste as plain text. It
also adds Russian and Traditional Chinese (Hong Kong and Taiwan), completes
the window layout shortcuts, organizes the panel Controls into categories,
improves Debounce, keeps Monitor lighter on battery, steadies the RAM menu
bar metric, makes Quit on close safer when switching Desktop spaces, makes
mouse scroll inversion more reliable and improves Dock Preview, menu bar icon
recovery and App Switcher previews.

### Added
- The quick panel: press the shortcut (^⌘V) anywhere and a small floating
  panel appears with your favorite tools, one click or key away: Keep Awake,
  mute microphone, copy text from screen, color picker, Clipboard, window
  layout, Cleaning Mode, Homebrew, Media, Clean URL and the Uninstaller.
  Every tool opens and runs inside the panel itself. Fully customizable in
  place: hide, bring back and drag tools around, with arrow-key navigation
  and 1 to 9 opening items directly.
- Clicking the Dock icon of the app you are using can now minimize its
  windows, like traditional taskbars. Off by default, next to Dock Preview in
  Settings.
- Middle click on the trackpad: pressing with three fingers now works like a
  mouse wheel click. Only a real press counts, so taps, swipes and resting
  fingers never trigger it, and accidental double clicks from tap-to-click
  are filtered out. While the macOS three-finger drag gesture is enabled it
  owns three-finger touches, so the middle click waits and Settings explains
  how to free the gesture. Off by default, in the Mouse tab in Settings.
- Clipboard history now saves copied images and files alongside text. Images
  show a thumbnail and paste back as images; files are remembered as links to
  their location and paste back as the files themselves. Both can be pinned,
  searched and reordered like any text item, and a new toggle in the Clipboard
  settings turns this off.
- Copy text from screen: select any area and the text in it is recognized
  offline and copied, ready to paste. In the panel and in the new Quick tools
  page in Settings, with an optional global shortcut.
- Color picker: grab the color of any pixel with the system loupe and copy it
  as HEX, RGB, HSL or SwiftUI code. In the panel and in Quick tools.
- Mute microphone: one click or a global shortcut cuts the Mac's input in
  every app, and the muted state survives switching input devices.
- Paste as plain text: an optional shortcut pastes what you copied without
  colors, fonts or formatting, and the original formatting stays on the
  clipboard for later pastes. In the Clipboard settings.
- Window layout shortcuts now cover every action. Next Display, thirds and
  two-thirds join the existing halves, quarters, maximize, center and restore,
  and each action row in Settings has its own shortcut recorder.
- Russian is now available throughout the app, thanks to Artur.
- Traditional Chinese (Hong Kong and Taiwan) is now available throughout the
  app, thanks to Jensen.

### Changed
- Vorssaint now updates on a weekly rhythm so every feature arrives better
  tested and more polished; critical fixes still ship right away. The short
  note shown after updating explains it and links to where previews of
  upcoming features are posted.
- The menu panel is cleaner and keeps layout options in Settings.
- The Controls section in the panel is now organized into collapsible
  categories with an at-a-glance count of what is on, so it stays short as
  features grow. Dock click to minimize and the trackpad middle click are now
  right there too, next to everything else.

### Fixed
- Debounce is more responsive while filtering duplicate key presses.
- Monitor uses much less energy while showing live menu bar metrics.
- The RAM metric in the menu bar no longer blinks during brief monitor refresh gaps.
- Quit on close no longer treats Desktop space switching as closing an app window.
- Mouse scroll inversion now works with more external mouse wheels, and no
  longer cancels itself out on mice that report smooth, pixel-precise
  scrolling. Toggling it now visibly changes direction for those mice too.
- Monitor now wakes only when the next reading is due while the panel is
  closed and only slow metrics are shown, instead of waking every refresh
  just to skip the work.
- The menu bar icon recovery can bring the icon back after macOS keeps it hidden.
- App Switcher window thumbnails no longer look skewed while Stage Manager is
  on. Windows parked in the Stage Manager strip get an upright preview right
  away and a sharper one as soon as they become active.
- Longer descriptions in the panel and in Settings are no longer cut off
  mid-sentence, in every language.

## [3.1.6] - 2026-06-30

### Summary
Vorssaint 3.1.6 adds Turkish, makes Clipboard History quicker to use from the quick window, lets Mixer choose how low speaker volume goes after headphones disconnect, adds faster App Switcher back navigation, adds a Network menu bar order option, steadies the Network menu bar metric, cleans up the in app update preview and corrects the menu bar monitor layout so pinned metrics sit centered beside the app icon.

### Added
- Turkish is now available throughout the app, thanks to Abdurrahman.

### Changed
- Clipboard History quick window rows can now be clicked to paste that item into
  the previous app, with Command click copying only.
- Mixer can now choose the volume used after wired or Bluetooth headphones
  disconnect.
- App Switcher can now move backward with Shift while the switcher is open.
- Monitor can now place upload above download in the Network menu bar metric.

### Fixed
- The update preview no longer shows install instructions meant for the download
  page.
- Network speed in the menu bar no longer changes the item width as live traffic
  updates.
- Menu bar monitor metrics now sit centered beside the app icon.

## [3.1.5] - 2026-06-29

### Summary
Vorssaint 3.1.5 adds multi-item paste to Clipboard History, makes Quit on close exceptions easier to set up from installed apps, adds per-app network activity and optional peripheral battery status to Monitor, adds keyboard debounce for duplicate key presses, improves Mixer compatibility with Zoom calls, improves localized feature labels, and improves App Switcher order and shortcuts.

### Added
- Clipboard History can now mark multiple items in the quick window and paste or
  copy them together as one stack.
- Monitor can now show recent per-app network traffic, with download and upload
  activity in the Network panel and the Network detail view.
- Monitor can now show connected keyboard, mouse, trackpad and Bluetooth audio
  device battery in the menu bar and System panel when enabled, with updates
  within a few seconds as devices connect or disconnect.
- Debounce can now filter very fast duplicate keyboard presses, with a 10 ms
  global window adjustable from the panel and optional per-key windows in
  milliseconds.
- The large-icon App Switcher now has a separate configurable shortcut for
  moving between windows of the selected app.

### Changed
- Quit on close exceptions can now be added from installed apps instead of only
  apps that are currently running.

### Fixed
- Clipboard History now preserves the full scheme when a copied web address is
  also provided as a structured URL by the source app.
- Zoom is kept on the normal system audio path so joining calls no longer hangs
  when Mixer boost settings are active.
- The Disk selector in Monitor no longer stops vertical panel scrolling when
  the pointer is over it.
- The large-icon App Switcher now keeps the selected app's window previews
  aligned with the selected icon.
- The App Switcher now reliably returns to the previous app when used twice in
  a row.
- Apps that were running but missing from the old running-app picker, such as
  Signal, can now be added to Quit on close exceptions.
- Feature names, Clipboard controls, Window Layout labels and Monitor alert
  labels now stay localized across all supported app languages instead of
  falling back to English.

## [3.1.4] - 2026-06-27

### Summary
Vorssaint 3.1.4 makes Homebrew in Settings more stable and easier to browse, adds package updates from Homebrew, adds a large-icon ⌘Tab view with visible shortcuts, adds finer Window Layout placement options, improves App Switcher and Dock Preview navigation, expands Monitor menu bar metrics and makes Clipboard History faster to use from the keyboard.

### Added
- Window Layout can now place the active window into left, center and right
  thirds, left or right two-thirds layouts, and the next display.
- Dock Preview can now pin the current preview panel, show position when an app
  has multiple windows, and reliably minimize or restore windows directly from
  each preview card or its context menu. Multi-window previews can also move to
  the previous or next window from the preview header, and pinned previews can
  be dragged to a better position on screen. Multiple pinned previews can stay
  on screen at once while you keep using other apps. The selected preview stays
  visible while navigating long rows of windows, and pinned previews stay open
  until you close or unpin them from the header.
- App Switcher can now show a large icon row with one entry per app, with the
  selected app's window previews above it so a specific window can still be
  chosen directly.
- Monitor can now show disk usage and live disk activity in the menu bar, if
  enabled.

### Changed
- Homebrew now shows package counts in filters and sections, making long
  installed lists easier to scan.
- Homebrew now marks installed packages that have updates available, shows a
  compact update count, can refresh Homebrew itself and can update one package
  directly from the list, the context menu, the detail view or all available
  updates at once. Operation logs and fallback commands can also be copied.
- Clipboard History's quick window now targets the previous item first when no
  items are pinned, supports arrow-key selection, copy-without-paste, keyboard
  pin/delete actions, full-text tooltips and multi-word search.
- App Switcher now filters windows as you type while switching, and App Switcher
  plus Dock Preview show the app name under titles when it helps distinguish
  similar windows.
- The large-icon App Switcher now shows the current app-switching shortcut and
  the shortcut for moving between windows of the selected app.
- What's New and the update preview now show the short summary at the top of the
  release notes.
- Monitor's per-app CPU, GPU, memory and energy lists can now bring a listed app
  forward directly.

### Fixed
- Homebrew in Settings no longer destabilizes the Settings navigation when it
  loads many installed packages.

## [3.1.3] - 2026-06-25

### Summary
Vorssaint 3.1.3 makes Cleaning Mode, Keep Awake, Monitor, Clipboard History and the Window Switcher more reliable, improves readability in the panel and adds optional pointer movement for Keep Awake sessions.

### Added
- Keep Awake can now move the pointer slightly at a chosen interval during
  active sessions, if enabled.

### Fixed
- Cleaning Mode now blocks brightness, media, volume and lock keys while the
  keyboard is locked.
- Keep Awake option text no longer gets cut off in the panel or Energy settings.
- Keep Awake closed-lid mode now handles failed password-free setup more clearly
  and can fall back to the macOS password prompt when needed.
- Battery health now follows the same maximum capacity value shown by macOS when
  that value is available.
- Monitor text in the panel now has better contrast, with steadier alignment for
  power and battery rows.
- Monitor Alerts controls now live in Settings instead of appearing both in
  Settings and the main panel.
- Clipboard History's shortcut toggle can now be turned off even when Clipboard
  History itself is currently disabled.
- The Network menu bar metric is now better centered and easier to read.
- The Window Switcher now focuses only the selected browser profile window,
  including when that selected window is minimized afterward.

## [3.1.2] - 2026-06-24

### Summary
Vorssaint 3.1.2 improves GIF handling in Media and Shelf, adds more Keep Awake control in the panel, lets Monitor metrics use separate menu bar items with focused detail views and expands the Volume Mixer with speaker protection and shortcut-based output switching.

### Added
- Keep Awake can now choose the active menu bar icon color directly from the
  panel, including an option to keep the normal adaptive icon with no active
  color.
- Keep Awake can now start automatically when Vorssaint opens, if enabled from
  the panel or Energy settings.
- Monitor metrics can now use separate menu bar items, so each active metric can
  be positioned independently on crowded or notched menu bars. Clicking a metric
  opens a focused detail view for CPU, GPU, RAM, network, battery or power.
- Volume Mixer can now lower speaker volume automatically when wired or
  Bluetooth headphones disconnect, if enabled.
- Volume Mixer can now cycle through selected system outputs with a global
  shortcut, if enabled.

### Changed
- Monitor and Shelf now use lighter thumbnails and temporary caches, reducing
  memory use while browsing metrics and dragging items.

### Fixed
- GIFs created by Media now stay visible in Finder, including outputs from
  source files whose names start with a dot.
- Panel sections and folded controls now open instantly without extra transition
  animations.
- Folded panel setup sections now open when clicking either the arrow or the
  section title.
- The System panel now shows the separate menu bar items control only when at
  least one menu bar metric is active.
- Shelf now preserves animated GIF data when macOS provides a GIF file or GIF
  data, instead of flattening it into a still image.

## [3.1.1] - 2026-06-23

### Summary
Vorssaint 3.1.1 makes Homebrew package loading more reliable, keeps Clipboard History from disrupting the app you are pasting into and adds direct window closing in App Switcher.

### Added
- App Switcher cards now show a close button on hover, so you can close a
  specific window without leaving the switcher.

### Fixed
- Clipboard History no longer activates Vorssaint when opening the quick history
  window, so paste actions keep their target in apps like Excel.
- Closing a window from Dock Preview or App Switcher now triggers Quit on Close
  when that was the app's last window.
- Homebrew now keeps loading installed packages when Homebrew prints warnings
  before or after its package list.

## [3.1.0] - 2026-06-23

### Summary
Vorssaint 3.1.0 adds three optional tools: Clipboard History for saving and reusing copied text locally, Window Layout for arranging the active window with shortcuts, and Monitor Alerts for notifying you when selected system limits need attention. It also makes Settings easier to browse and improves menu bar metric readability on light and dark wallpapers.

### Added
- Clipboard History, with local text history, pinned items, search, manual order,
  clear controls, sensitive-text skip and quick paste shortcuts.
- Window Layout, with actions for halves, corners, center, maximize, restore and
  optional global shortcuts.
- Monitor Alerts, with optional notifications for high CPU, CPU temperature,
  memory pressure, disk space and battery, configurable from Settings and the
  System panel.

### Changed
- Settings are now grouped into clearer categories.
- Homebrew and Dock Preview no longer show beta labels in the app.
- Clipboard and Window Layout are available in the Utilities panel and can be
  hidden or reordered.
- Menu bar metric text now adapts better to light and dark wallpapers.
- What's New no longer opens again after installing an update, because the
  update flow already shows the changelog before download.

## [3.0.10] - 2026-06-21

### Summary
- This update adds disk monitoring to the System Monitor, with per-disk storage,
  activity, SMART details when available and safe eject controls for external
  drives.
- App Switcher is steadier with multiple windows and fullscreen apps, including
  games.
- App Switcher now has a Finder visibility option for users who prefer not to
  show Finder when it has no open windows.

### Added
- System Monitor now has a Disks section with storage usage, live read/write
  activity, session totals, SMART details when macOS exposes them, per-disk
  selection and Finder-style decimal storage values.
- Disks can now be selected individually, with per-disk details, an Eject action,
  an Eject all action for external drives and safety guards that block eject
  actions for the internal system disk.
- App Switcher can now hide Finder when it has no open windows, while keeping
  Finder windows visible when they exist.

### Fixed
- App Switcher now returns to the exact window you last used in apps with
  multiple windows, instead of letting the app choose a different window.
- App Switcher now switches more reliably when entering or leaving fullscreen
  apps and games.

## [3.0.9] - 2026-06-20

### Summary
- This update focuses on making Vorssaint feel lighter, steadier and more
  reliable during everyday use.
- Menu bar readings for CPU, GPU, RAM and temperatures stay visible through
  brief refresh gaps, while the monitor does less background work when the panel
  is closed or only a few metrics are visible.
- The Volume Mixer is easier to control with one output selection for the system
  and apps, while per-app volume, mute and boost settings stay intact.
- Media tools are more responsive with larger videos and more reliable when
  reading video details or creating GIFs.

### Changed
- The Volume Mixer can now send the whole system and apps to one audio output at
  once.
- The system monitor and menu bar now do less background work, especially when
  the panel is closed or only a few metrics are visible.
- Live monitor updates are smoother and avoid unnecessary redraws while values
  are refreshing.
- Media tools are more responsive with large videos and handle video details and
  GIF creation more reliably.

### Fixed
- GPU temperature, RAM and CPU readings in the menu bar now stay visible through
  quick moments when a value is unavailable instead of disappearing and coming
  back.
- The Network panel now starts measuring correctly when opened directly on
  Network.
- GPU usage in the menu bar now avoids brief spikes when opening the panel,
  while still showing real sustained activity.

## [3.0.8] - 2026-06-20

### Added
- CPU, GPU and battery temperatures can now be pinned to the menu bar as
  metrics, using the selected Celsius or Fahrenheit setting.
- Menu bar temperatures now combine with matching usage or battery charge by
  default, with a setting to split them into separate CPU°C, GPU°C and BAT°C
  blocks.

![Menu bar temperature metrics](https://raw.githubusercontent.com/vorssaint/vorssaint-utils/main/Resources/Images/menu-bar-temperature-metrics.png)

## [3.0.7] - 2026-06-20

### Added
- Utilities now includes Media for local video compression, GIF creation, image
  compression and text extraction from images, with drag and drop, simple
  controls and local-only processing.
- Dock Preview cards now include a red close button on the left for closing the
  real window directly from its preview, and the panel stays correctly sized as
  windows are closed.
- Pending Finder cut operations now include a close button to cancel the cut and
  dismiss the floating HUD.

### Changed
- Menu bar metrics now use a cleaner compact layout with clearer CPU, GPU, RAM,
  battery, power and network readings, custom ordering, persisted choices and
  steadier widths.
- The menu panel uses a subtler glass surface so text and controls stay readable
  across different backgrounds.

## [3.0.6] - 2026-06-20

### Added
- Global shortcuts for Keep Awake, Shelf and App Switcher can now be changed or
  turned off.

### Fixed
- Closed Vorssaint Settings windows no longer linger in App Switcher.
- Minimized windows now stay open and remain available in App Switcher and Dock
  Preview.

## [3.0.5] - 2026-06-19

### Added
- When installing an update, a preview of the new version's changelog is shown
  first, so you can decide whether the update is worth it before downloading.
- After updating, a What's New window summarizes everything since your previous
  version. You can turn it off in Settings > What's New, or with "Don't show
  again".
- The app switcher and Dock previews now have a size option (Normal, Large or
  Extra large) so windows stay easy to identify on large displays.

### Fixed
- Closed-lid mode now reliably brings up the administrator password prompt when
  it is being set up on a Mac that has not granted permission yet, and no longer
  becomes unstable when the request is retried.
- "Clear all permissions" could freeze the Mac's input; it now stops the app's
  event taps before resetting permissions, and feature event taps no longer
  block when Accessibility is revoked.
- Cut & paste for files in Finder (⌘X) shows its on-screen confirmation again:
  Finder Automation is now requested in-process and re-requested if it was lost
  after an update, instead of failing silently.
- When closed-lid mode cannot be turned on, the message now clearly says to
  switch it off and on again to try, instead of a confusing note that pointed at
  your password even when no password was involved.

## [3.0.4] - 2026-06-18

### Added
- Utilities now includes a Homebrew manager for searching, installing and
  uninstalling formulae and casks from the menu panel, with popularity-sorted
  search results and a guided setup flow when Homebrew is not installed.
- The Volume Mixer can now route each app to the system default output or a
  specific speaker, display or audio device.
- The Volume Mixer now includes a global microphone picker that remembers a
  preferred input and restores it when the device reconnects.
- Dock Preview can now show window previews when hovering over open apps in the
  Dock, with a temporary peek before selecting a window.
- This update includes a one-time Dock Preview intro with a short demo and beta
  note.

### Changed
- Panel edit mode now has a clearer OK button, reset control and drag handles
  for reordering items.
- Utilities now defaults to Homebrew first, followed by Uninstaller, Clean URL
  and Cleaning Mode.

### Fixed
- App Switcher now keeps fullscreen windows available when they are on another
  Space.
- App Switcher thumbnails now try a secondary ScreenCaptureKit match for native
  fullscreen windows on another Space.
- Green-button maximization now avoids falling through to native fullscreen when
  the custom resize path cannot run.
- Quit on close now ignores stale AX windows after a real close-button request
  when WindowServer confirms there is no visible app window left.
- Quit on close now follows explicit close-button clicks in apps that do not
  always emit standard window-close callbacks.
- Settings now opens beside the menu panel instead of starting underneath it.

## [3.0.3] - 2026-06-18

### Changed
- The Shelf is easier to grab and move from the header and empty space, while
  still accepting dropped items in the empty area.
- Shelf close and clear controls now have larger hit areas, clearer spacing and
  a danger hover state for clearing items.
- The menu panel footer now uses full button hit areas and handles longer
  translations without overlapping.
- Settings now uses a shorter What's New sidebar label, and update controls live
  in About with the other app details.

### Fixed
- The custom green-button maximize option now animates window resizing instead
  of jumping instantly.
- Window-control click monitoring now avoids slow accessibility checks unless a
  click is actually on a window control, reducing stalls in other apps.

## [3.0.2] - 2026-06-18

### Fixed
- Opening Clean URL or Uninstaller from the menu panel is now more stable on
  macOS 15.

## [3.0.1] - 2026-06-18

### Fixed
- Quit on close now handles apps that keep delayed window records after the last
  standard window is closed, including Spotify and Discord.
- The app switcher no longer shows recently closed Ghostty terminal windows.
- Finder can now be selected from the app switcher even when no Finder window is
  open.
- Finder stays locked in Quit on close exceptions and cannot be quit from the app
  switcher.

## [3.0.0] - 2026-06-18

### Added
- Clean URL is now available in Utilities and Settings, with optional automatic
  cleaning for copied links.
- Panel sections can now be customized inline from the panel: the edit control
  keeps the real panel visible, shows hidden items as muted rows and lets them
  be restored from the same place.
- Utilities now includes an optional green-button window maximizer that keeps
  windows in the current Space and restores the previous size on the next click.
- The menu panel now has a Controls section next to Utilities for quickly
  turning feature-style options on or off.

### Changed
- Menu bar metrics now use a more compact layout with short labels, tighter
  values, a steadier reserved width and an automatic two-line stack when several
  metrics are enabled.
- Menu bar metric labels can now be switched between compact and classic styles
  from Monitor settings.
- Updates no longer open a What's New window for existing users. Release notes
  are available in Settings.
- The Buy Me a Coffee shortcut was removed from the menu panel and first-run
  introduction. It remains in Settings > Support.
- Monitor graphs now include a zero baseline so current levels are easier to
  read.

### Fixed
- The Uninstaller app chooser now stays inside Vorssaint instead of opening the
  system file picker, avoiding unexpected language changes.

## [2.17.3] - 2026-06-17

### Website
- Official site: [vorssaint.com](https://vorssaint.com).

### Added
- Every update now opens a What's New window with the latest release notes and a
  discreet vorssaint.com link.
- The Uninstaller is now available directly in the menu panel's Utilities
  section, with drag-and-drop and Choose app support.
- The menu panel header now includes a Buy Me a Coffee shortcut.

### Changed
- Settings and What's New windows can now be focused from the window switcher.
- The menu bar icon no longer bounces when opening the panel.
- The README now uses focused screenshots and GIFs for each feature.

### Fixed
- Quit on close now detects the last-window close more reliably for apps like
  Safari and WhatsApp.
- The post-update What's New window now opens centered on screen.

## [2.17.2] - 2026-06-17

### Fixed
- Shelf and Cut & Paste HUDs no longer use the native rectangular panel shadow,
  avoiding extra outlines on some macOS display/window configurations.

## [2.17.1] - 2026-06-17

### Fixed
- The release build now uses the macOS 26 runner so the Volume Mixer slider uses
  the same Liquid Glass effect as the Developer build on macOS 26 and later.

## [2.17.0] - 2026-06-17

### Added
- The Battery section now shows apps with significant current energy use.
- The Volume Mixer uses a compact Liquid Glass slider on macOS 26 and later,
  while older macOS versions keep the standard slider.

### Changed
- The Keep Awake status under the app name is now a clearer state indicator.
- Panel metric colors now adapt between Light Mode and Dark Mode for better
  contrast.

### Fixed
- Update notices in section navigation mode now count toward the panel height
  instead of cutting off the content.
- The Settings window now opens in a normal centered position after relaunch,
  instead of appearing under the menu panel.
- Volume Mixer sliders now track system accent color changes more reliably.
- The menu panel no longer opens with its header clipped during first-launch
  layout timing.

## [2.16.1] - 2026-06-16

### Fixed
- Memory usage now matches Activity Monitor's Memory Used total more closely.
- Network readings now ignore another local virtual interface so totals stay focused on real network traffic.

## [2.16.0] - 2026-06-16

### Added
- The menu panel now has an optional section navigation mode, with section icons
  placed below the app header and a centered List/Sections switch in the footer.
- The section navigation mode is introduced during the update flow and is enabled
  by default so existing users can try it right away.
- Shelf drops can now be kept as batches, and loose items can be added into an
  existing stack by dropping them onto it.
- Battery can now be shown as an optional menu bar metric.
- A Fan Control beta entry can be enabled in Monitor settings. Manual control
  remains disabled until Mac models are validated.

### Changed
- Cleaning Mode now lives in a dedicated Utilities section inside the panel.
- The menu panel now fades and slides when opening or closing.
- The section navigation panel now grows only as much as the active section needs,
  instead of reserving a large empty area for shorter sections.

### Fixed
- The Shelf stays visible while it contains files, instead of auto-hiding while
  the user is still collecting items.
- The app switcher now handles apps on other Spaces more reliably when focusing a
  selected window.

## [2.15.2] - 2026-06-16

### Fixed
- The menu panel now resizes smoothly as sections collapse and expand, without
  stale empty space or unnecessary scrolling.
- The Settings window now stays open when clicking outside it, and only closes
  when the user closes it intentionally.
- Clicking the Settings window now hides the menu panel only when the panel is
  overlapping it, while still allowing Settings and the panel to stay open side
  by side for live layout changes.
- App updates no longer open the language chooser or Buy Me a Coffee support
  prompt automatically.

## [2.15.1] - 2026-06-16

### Fixed
- The menu panel opens fully expanded again after updating, instead of restoring
  an old collapsed layout that made it look unexpectedly tiny.

## [2.15.0] - 2026-06-16

### Added
- **Shelf now gets out of the way.** After it appears, it fades away on its own
  after a few seconds if you are not interacting with it.
- **Shelf feels more balanced.** The panel is more square, with a comfortable
  three-column grid instead of a tight horizontal strip.

### Changed
- The menu bar icon now stays full strength while idle, turns amber while Keep
  Awake is active, and still turns blue when an update is available.

### Fixed
- Shaking a file dragged from a Dock stack now opens the Shelf, matching the
  behavior of files dragged from Finder.

## [2.14.0] - 2026-06-15

### Added
- **Now in eight languages.** The interface is available in English, Português,
  Español, Deutsch, Français, Italiano, 日本語 and 简体中文. Choose yours in
  Settings › General; a one-time chooser also appears after updating.

### Fixed
- The Battery label in the system monitor no longer wraps onto a second line.
- The menu bar panel now stays centered with even margins instead of leaving a gap
  on the right when macOS is set to always show scroll bars.

## [2.13.1] - 2026-06-15

### Fixed
- The System monitor step in the welcome tour now scrolls, so its content is never
  clipped at the bottom on shorter windows.

## [2.13.0] - 2026-06-15

### Added
- **Make the panel yours.** Collapse any section you don't use with a tap on its
  header, and drag to reorder the sections from Settings › Monitor. The panel shows
  what matters to you first, with less scrolling.

### Changed
- Cleaning Mode moved into the panel's footer, alongside Settings and Quit.

### Fixed
- **Keyboard shortcuts work in the Settings window.** Cmd+W, Cmd+M, Cmd+H and Cmd+Q,
  plus cut, copy, paste and select all in text fields, now respond as expected.
- Removed an occasional extra outline around the Shelf, and evened out the panel's
  spacing so it no longer sits closer to one edge.

## [2.12.0] - 2026-06-15

### Added
- **Support the project.** A new Support tab in Settings, and a brief one-time note
  when you update, let you back Vorssaint with a coffee if you'd like. It stays
  free, with no subscription, always.

### Fixed
- **Battery health matches macOS.** The health percentage now lines up with the
  "Maximum Capacity" shown in System Information.
- **The menu bar icon is recoverable.** macOS can hide menu bar icons when the bar
  runs out of room, common on Macs with a notch. Now reopening Vorssaint from
  Applications brings the icon back, a new "Show menu bar icon" button in Settings
  rebuilds it, and the icon remembers its position.
- Fixed the Support tab hiding the rest of the Settings sidebar.

## [2.11.0] - 2026-06-15

### Added
- **Cleaning Mode.** Locks the keyboard so you can wipe it down without typing
  anything by accident. Unlock by pressing the same key five times in a row, by
  clicking Unlock on the overlay, or just by waiting, since it releases on its own
  after a minute. Start it from the panel or the icon's menu.

### Fixed
- **Battery health now matches macOS.** The health percentage lines up with the
  "Maximum Capacity" shown in System Information.
- **Removing the menu bar icon no longer locks you out.** The icon can't be dragged
  off the bar by accident, it always comes back on launch, and reopening the app
  from Finder or Spotlight restores it and opens the panel.
- The icon's right-click menu now opens reliably even when the panel is already open.

## [2.10.0] - 2026-06-15

### Added
- **System monitor, expanded.** The panel now shows live network speed (download
  and upload) with session totals; power draw, broken into what the Mac consumes,
  what it pulls from the adapter, and the battery's flow, health, charge and cycle
  count; and history graphs for CPU, GPU, memory, network, power and battery. A
  system uptime line is included too.
- **Metrics in the menu bar.** Pin any of CPU, GPU, RAM, Network or Power next to
  the icon, updated live. Memory can show as a colored pressure dot, a percentage,
  or both. Everything is opt-in, and the text keeps a fixed width so the icon
  never shifts as the numbers change.
- **Internet speed test.** Measure download, upload and latency on demand from the
  Network block.
- **Pick exactly what you see.** Choose which blocks appear in the panel and which
  items appear inside each block, both in Settings and during setup. New options
  default to on, so nothing changes until you tune it.
- **Update notifications.** When a new version is available the menu bar icon turns
  blue and a banner offers it at the top of the panel. Automatic checks are more
  frequent and also run when you reopen the app, so updates surface on their own.

### Fixed
- Fixed two mach port leaks in the CPU and memory sampling that could slowly
  accumulate while the panel was open.

## [2.9.1] - 2026-06-14

### Changed
- The switcher's grouping option now shows **one entry per app**, collapsing all
  of an app's windows into a single entry instead of one per window. Turn it on
  for an app-level switcher rather than a window-level one.

## [2.9.0] - 2026-06-14

### Added
- **Switcher option to merge an app's tabs.** A new setting makes the window
  switcher treat the tabs of one window as a single entry, so apps like Finder
  and Terminal with many tabs no longer flood the switcher. It is off by default;
  when on, only the active tab of each tabbed window is shown.

## [2.8.1] - 2026-06-14

### Fixed
- The mixer slider no longer stays amber after a boosted app returns to 100% or
  below. It goes back to the normal color as soon as the volume is no longer
  above 100%.

## [2.8.0] - 2026-06-14

### Added
- **Volume boost in the mixer.** Each app's volume now goes up to 200%, for when a
  video or call plays too quietly. Above 100% the slider and the percentage turn
  amber so a boost is never mistaken for normal volume, and a one-tap reset button
  returns that app to 100%. At 100% the audio stays bit-perfect passthrough.

## [2.7.3] - 2026-06-14

### Fixed
- The ⌃⌥⌘K shortcut toggles "Keep awake" reliably again. When the temporary shelf
  was also enabled, its global shortcut could swallow the ⌃⌥⌘K key press, so
  nothing happened; the two shortcuts no longer interfere.

## [2.7.2] - 2026-06-14

### Fixed
- On the "Quit on last window close" onboarding illustration, the red close
  button now sits aligned with the other window buttons, instead of off in the
  corner of the window.

## [2.7.1] - 2026-06-14

### Changed
- **The brand badge now sits on a solid black background** instead of the
  previous purple-tinted one, for a cleaner, more neutral look. It affects the
  menu bar panel header, the About tab and the onboarding screens.

## [2.7.0] - 2026-06-14

### Fixed
- **Quit on last window close** no longer quits an app when you leave full screen
  with the green button. Exiting full screen briefly leaves the app without a
  window for a moment, which was being read as the last window closing; it now
  confirms the app is really window-less, after the transition settles, before
  quitting it.

### Added
- **Advanced settings page** with two clean-up tools, each behind a confirmation:
  - **Clear all permissions** resets every permission you granted Vorssaint
    (Accessibility, Screen Recording, Full Disk Access and the rest) and removes
    its login item and closed-lid rule, leaving the app in place. Good for a fresh
    start or before uninstalling.
  - **Uninstall Vorssaint completely** does all of that, removes the preferences,
    moves the app to the Trash and quits, leaving nothing behind. You can
    reinstall anytime.

## [2.6.0] - 2026-06-14

### Changed
- **Vorssaint is now signed with an Apple Developer ID and notarized.** The
  first-launch security warning is gone: downloads open normally, with nothing to
  click around. Releases are notarized and stapled automatically.

### Migration
- **You will grant permissions once on this update.** Notarization requires a
  different signing certificate, which changes the app's code identity, so macOS
  asks you to re-allow Accessibility, Screen Recording and the like a single
  time. After this update the identity is stable again (now an Apple-issued one),
  so future updates keep your permissions as before. Your settings and data are
  untouched.

## [2.5.4] - 2026-06-13

### Changed
- **Less idle background work.** The Full Disk Access check no longer runs on the
  recurring permission poll. That access cannot change while the app is running
  (only across a relaunch), so it is now checked at launch and when the app is
  reactivated instead. This removes a steady stream of denied file accesses for
  anyone who has not granted it, with no change in behavior

## [2.5.3] - 2026-06-13

### Fixed
- **The uninstaller no longer keeps asking for Full Disk Access after you grant
  it.** The app detected access by reading the TCC database, but that file does
  not exist on every macOS version, so the check always failed and the banner
  stayed even with access granted and the app reopened. It now also confirms
  access by listing a protected folder that exists (Safari, Mail, Messages and
  the like), which is reliable across versions. No need to re-grant: the banner
  clears on its own once you are on this version

## [2.5.2] - 2026-06-13

### Fixed
- **Granting Full Disk Access from the uninstaller is reliable now.** The app
  registered itself with the system and opened the settings pane in the same
  instant, so it was often missing from the list. It now reads the always-present
  TCC database (the dependable trigger) and waits for the system to record the
  request before opening the pane. The hint also explains the sure path: if the
  app is not listed, add it with the list's "+" button from Applications

## [2.5.1] - 2026-06-13

### Fixed
- **A 2.5.0 install updated from an older version could move itself to the
  Trash on first launch.** The startup cleanup compared bundle locations too
  strictly and mistook the just-updated app (still at the old path, because the
  previous updater installs in place) for a leftover copy. It now renames that
  bundle to `Vorssaint.app` through a helper that runs only after the app quits,
  always reopening the app, and the leftover cleanup only runs for a bundle that
  is provably not the one running. Recover a trashed copy by reinstalling from
  the DMG: the bundle id is unchanged, so permissions and settings return intact

## [2.5.0] - 2026-06-13

### Changed
- **The app is now "Vorssaint" everywhere the system shows it.** The app file is
  renamed to `Vorssaint.app` and its executable to `Vorssaint`, so Spotlight, the
  Applications list, Login Items, notifications, the permission panes and system
  dialogs all read "Vorssaint", with no trace of the old name
- Internal names follow suit (the audio mixer device, the closed-lid rule file,
  the diagnostics binary) and the source tree moved to `Sources/Vorssaint`

### Migration
- **Updating keeps your permissions, settings and data, with nothing to do.** The
  bundle identifier is unchanged, so every granted permission (Accessibility,
  Screen Recording, Full Disk Access, Automation), your preferences and the login
  item carry over untouched. The update installs `Vorssaint.app` and removes the
  old `Vorssaint Utils.app`; if a copy is ever left behind (for example after a
  manual install), the app moves it to the Trash on its next launch. The
  closed-lid rule file is renamed the next time that toggle is used

## [2.4.7] - 2026-06-13

### Changed
- **The switcher is window-based.** ⌘Tab now moves between windows, including
  multiple windows of the same app, and a quick flick returns to the last window
  you used. The browser-tabs entries were removed

### Fixed
- **Full Disk Access banner** no longer lingers after you grant it: the app
  re-checks when it regains focus and offers a Relaunch button (the access only
  applies to a freshly launched app)
- **Onboarding**: shortcut keys no longer overlap their description text

## [2.4.6] - 2026-06-12

### Changed
- The app is now called simply **Vorssaint** everywhere you see it (menu bar,
  About, onboarding, notifications). The bundle id, signing identity and app
  filename are unchanged, so this update keeps your granted permissions
- README rewritten around what each feature gets you, with the free, local,
  no-account stance up front

## [2.4.5] - 2026-06-12

### Fixed
- **Uninstaller**: apps the system protects (root-owned, installer-based) are
  now removed through Finder, which asks for the administrator password and
  moves them to the Trash like a drag would. The scan also hardens against
  hostile bundle ids and never lists anything outside ~/Library, /Library or
  the picked app

### Changed
- The uninstaller lives directly inside Settings: drop an app on the page, no
  separate window, no enable toggle
- The display now always stays on while a keep-awake session is active; the
  separate toggle is gone
- Cleaner wording across the app and the documentation

## [2.4.4] - 2026-06-12

Stability pass over the whole project: same behavior, fewer ways to fail.

### Fixed
- **Self-update is fail-safe**: the new version is fully copied next to the app
  before the old one is removed, so a failed download/copy can never leave you
  without an app
- **Uninstaller**: scan results landing after you picked a different app are
  discarded (files of app A can no longer be listed under app B); display names
  only strip a trailing ".app"
- **Cut & paste**: an unexpected Accessibility value can no longer crash the
  app from inside the keyboard tap, and a cut superseded by a copy elsewhere
  now dismisses its HUD instead of lingering
- **Shelf**: an image dragged from a web page is kept as an image, not as a
  link to the page

### Changed
- Periodic timers gained tolerances so macOS can coalesce wakeups (less power)
- Internal dedup: one screen-under-mouse helper and one HUD backdrop shared by
  all floating panels; CI workflows moved to the actions' Node 24 lines

## [2.4.3] - 2026-06-12

### Changed
- **Shelf**: tiles are now AppKit-backed so you can select several items (click
  to select) and drag them all out in a single drag

### Fixed
- **Shelf**: you can move the panel again: drag its top bar to reposition it,
  while grabbing a tile still drags the item
- **Shelf**: dropping item(s) somewhere now removes them from the shelf
  automatically (a cancelled drag keeps them)

## [2.4.2] - 2026-06-12

### Fixed
- **Uninstaller**: granting Full Disk Access now actually works. The app
  registers itself with the system first, so it appears (with a toggle) in the
  System Settings list instead of opening to a list it isn't in, and a short
  hint explains how to enable it

## [2.4.1] - 2026-06-12

### Fixed
- **Shelf**: dragging an item out of the shelf now works. The panel no longer
  moves with the pointer, so grabbing a tile starts an item drag instead of
  dragging the whole window
- **Shelf**: shaking the mouse while *moving a window* no longer summons the
  shelf; it appears only when something droppable (a file, image, text or link)
  is actually being dragged

## [2.4.0] - 2026-06-12

### Added
- **Cut & paste files in Finder**: ⌘X cuts the current selection and ⌘V moves it
  into the folder you're viewing, with a floating HUD showing the held items.
  Text fields keep their normal shortcuts. Opt-in
- **Quit on last window close**: when an app that had a window closes its last
  one, it quits, with a per-app exception list (Finder excepted by default).
  Opt-in
- **Complete app uninstaller**: drag an app (or pick one) to find the caches,
  preferences, logs, containers and other files it leaves behind, each with its
  size, then move the selected ones to the Trash and see the space recovered.
  Opt-in
- **Temporary shelf**: a floating area, summoned at the cursor with ⌃⌥⌘D or by
  shaking the mouse mid-drag, that holds files, images, text and links to drag
  back out into any app later; needs no permissions. Opt-in
- A visual onboarding page for each new feature; people updating from an earlier
  version see a one-time "what's new" pass to discover and configure them

### Changed
- Settings moved from a tab bar to a System-Settings-style sidebar, giving every
  feature its own page with room for examples and options

## [2.3.0] - 2026-06-12

### Added
- **Per-app volume mixer** in the panel: set the volume of each app holding an
  audio connection (CoreAudio process taps, macOS 14.4+). A live indicator marks
  apps playing now; volumes persist per app; 100% is untouched passthrough
- **Browser tabs are first-class in the switcher**: each Safari/Chrome/Edge/
  Brave/Vivaldi tab is its own entry

### Changed
- **Switcher is instant**: a browser tab now raises its window immediately
  instead of waiting on the tab-select script, and the panel only appears after
  a short delay so quick flicks switch with no UI
- **Tab-granular toggle**: the switcher tracks a most-recently-used order of
  individual items, so ⌘Tab toggles between two tabs of the same browser just
  like between two apps
- The CPU/GPU/memory breakdown consolidates helper processes under their app
  (one Safari row, not a dozen Web Content rows)

### Removed
- The quick-utilities panel section (hide desktop icons, show hidden files, turn
  off display, eject disks, empty Trash)

## [2.1.0] - 2026-06-12

### Added
- **Per-app resource breakdown**: tapping CPU, GPU or Memory in the panel's
  System section expands the top consumers of that resource. CPU and memory
  come from the process table; per-app GPU% is computed from the accelerator's
  per-process GPU-time counters, sampled as deltas
- **Browser tabs in the switcher**: every Safari/Chrome/Edge/Brave/Vivaldi tab
  appears as its own ⌘Tab entry (the active tab keeps the window thumbnail);
  selecting one focuses that exact tab. Toggleable in Settings › Switcher;
  macOS asks for Automation consent once per browser

## [2.0.2] - 2026-06-12

### Fixed
- **Permissions now survive updates.** Builds are signed with a stable
  self-signed identity (`Tools/setup-signing.sh` locally, shared certificate in
  CI), giving the bundle a constant designated requirement, so macOS keeps
  granted Accessibility and Screen Recording permissions across updates instead
  of dropping them. Falls back to ad-hoc signing on a fresh clone.

### Changed
- The installer **DMG is styled**: a window with the app icon, an arrow and the
  Applications folder for a proper drag-and-drop install.

### Docs
- README/switcher wording updated to ⌘Tab-only (the ⌥Tab option is gone).

## [2.0.1] - 2026-06-12

### Added
- **Automatic updates**: the app checks GitHub Releases (toggle in Settings ›
  General, plus a "Check for updates" menu item), and can download the new DMG
  and self-install with a single click

### Changed
- The window switcher now **always replaces ⌘Tab** (the ⌥Tab option was removed)
- Switcher selection follows a real most-recently-used app order, so a quick
  ⌘Tab→release toggles back to the previous app, matching the system switcher

### Added (switcher)
- Press **Q** while the switcher is open to quit the highlighted app

## [2.0.0] - 2026-06-12

The app was renamed from **Vorss** to **Vorssaint Utils** and prepared for
open source distribution.

### Added
- **System monitor**: CPU/GPU/battery temperatures (SMC), CPU/GPU usage and a
  traffic-light memory pressure indicator in the panel
- **Inverted mouse scrolling**: invert the mouse wheel only, trackpad untouched,
  live toggle (Accessibility)
- **Window switcher**: ⌥Tab (or ⌘Tab takeover) with real window thumbnails
  (ScreenCaptureKit), multi-window support, Spaces/Mission Control friendly
- **Onboarding** in 7 steps: language, Accessibility, Screen Recording,
  monitor tour, optional features, status verification, summary
- **Bilingual interface** (pt-BR / en-US) with live language switching
- New black hole identity: app icon and menu bar glyph with distinct
  active/inactive states and a click micro-interaction
- `--sensors` diagnostic flag (SMC dump for porting to new chips)
- `--uninstall` flag and `Tools/uninstall.sh` for a clean removal (login item,
  TCC permissions, preferences, sudoers rule, no dead entries left behind)
- CI build workflow and automated DMG releases

### Changed
- Renamed to **Vorssaint Utils** (`com.vorssaint.utils`); legacy `Vorss.app`
  is removed by `./build.sh --install`
- The System section now shows only temperatures, usage and memory pressure
- Settings reorganized into General / Energy / Mouse / Switcher / About
- Project restructured into App / Core / Services / UI / Support layers

### Removed
- Clipboard history (and its settings)
- "Sleep now" quick action

## [1.1] - 2026-06-11

Initial internal release as **Vorss**: keep-awake sessions with closed-lid
mode, battery protection, clipboard history, quick utilities and system info.
